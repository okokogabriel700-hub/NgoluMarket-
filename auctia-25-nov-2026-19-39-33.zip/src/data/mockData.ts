import {
  AuctionItem,
  AuditLog,
  Bid,
  FinancialSettlement,
  NotificationItem,
  PlatformSettings,
  SellerProfile,
  User,
} from '../types';
import { ALL_CATEGORIES } from '../utils/formatters';

export const INITIAL_USERS: User[] = [
  {
    id: 'user_admin_1',
    name: 'Administration NgoluMarket',
    phone: '+243 89 000 0001',
    email: 'admin@ngolumarket.cd',
    role: 'super_admin',
    status: 'active',
    city: 'Kinshasa',
    country: 'RDC',
    isPremium: true,
    createdAt: '2025-10-01T00:00:00Z',
  },
];

export const INITIAL_SELLER_PROFILES: SellerProfile[] = [];

export const INITIAL_SETTINGS: PlatformSettings = {
  fixedListingFee: 0, // Publication gratuite (Fiche Technique Sections 6 & 7)
  fixedPriceBuyerFeeUsd: 1, // Frais plateforme 1 USD payés par l'acheteur sur prix fixe (Section 6)
  commissionRatePercent: 5, // Commission 5% sur prix final d'enchère payée par le vendeur (Section 7)
  premiumSubscriptionPriceUsd: 50, // Abonnement Vendeur Premium 50 USD / trimestre (Section 8)
  adMonthlyPriceUsd: 1, // Publicité 1 USD / mois (Section 9)
  sponsoredProductPriceUsd: 1, // Produit sponsorisé 1 USD / produit (Section 9)
  fixedFeePayer: 'buyer', // Frais plateforme payés par l'acheteur sur prix fixe
  antiSnipingMinutes: 2, // +2 min si offre reçue dans les 2 dernières min
  antiSnipingEnabled: true,
  autoApproveSellers: true,
  minBidStepMode: 'tiered',
  targetCity: 'Kinshasa',
  contactVisibility: 'hidden_until_won',
  currencyRateCdf: 2850,
  enabledCategories: ALL_CATEGORIES,
  activeCountries: ['RDC (Kinshasa)', 'Kenya (Nairobi)', 'Sénégal (Dakar)', 'Maroc (Casablanca)'],
};

export const INITIAL_AUCTIONS: AuctionItem[] = [];

export const INITIAL_BIDS: Bid[] = [];

export const INITIAL_SETTLEMENTS: FinancialSettlement[] = [];

export const INITIAL_AUDIT_LOGS: AuditLog[] = [];

export const INITIAL_NOTIFICATIONS: NotificationItem[] = [];
