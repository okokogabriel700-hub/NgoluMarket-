import React, { useEffect, useState } from 'react';
import {
  Building,
  Car,
  CheckCircle2,
  Dumbbell,
  PlugZap,
  PlusCircle,
  Search,
  ShieldCheck,
  Smartphone,
  Sofa,
  Sparkles,
  Utensils,
  Watch,
  X,
} from 'lucide-react';
import { AdminDashboard } from './components/AdminDashboard';
import { AuctionCard } from './components/AuctionCard';
import { AuctionDetailModal } from './components/AuctionDetailModal';
import { AuthModal } from './components/AuthModal';
import { BuyerDashboard } from './components/BuyerDashboard';
import { DecisionsModal } from './components/DecisionsModal';
import { Footer } from './components/Footer';
import { Navbar } from './components/Navbar';
import { NewAuctionModal } from './components/NewAuctionModal';
import { NotificationsDrawer } from './components/NotificationsDrawer';
import { PremiumSubscriptionModal } from './components/PremiumSubscriptionModal';
import { SellerDashboard } from './components/SellerDashboard';
import { SellerVerificationModal } from './components/SellerVerificationModal';
import { AuctiaProvider, useAuctia } from './context/AuctiaContext';
import { AuctionItem, Category, SaleType } from './types';
import { ALL_CATEGORIES, formatUsd, getCategoryLabel } from './utils/formatters';
import { t } from './utils/i18n';

const CATEGORY_ICONS: Record<Category, React.FC<{ className?: string }>> = {
  immobilier: Building,
  automobile: Car,
  mode: Watch,
  sport: Dumbbell,
  cosmetiques: Sparkles,
  alimentaire: Utensils,
  meuble: Sofa,
  electronique: Smartphone,
  electromenager: PlugZap,
};

function NgoluMarketApp() {
  const { currentUser, auctions, settings, language, recordProductView } = useAuctia();

  // Navigation & View state
  const [activeView, setActiveView] = useState<'home' | 'buyer' | 'seller' | 'admin'>('home');
  const [selectedCategory, setSelectedCategory] = useState<Category | 'all'>('all');
  const [selectedSaleType, setSelectedSaleType] = useState<SaleType | 'all'>('all');
  const [selectedCommune, setSelectedCommune] = useState<string>('all');
  const [minPriceFilter, setMinPriceFilter] = useState<string>('');
  const [maxPriceFilter, setMaxPriceFilter] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'ending_soon' | 'price_asc' | 'price_desc' | 'popular'>(
    'ending_soon'
  );

  // Modals state
  const [selectedAuction, setSelectedAuction] = useState<AuctionItem | null>(null);
  const [showNewAuctionModal, setShowNewAuctionModal] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authModalMode, setAuthModalMode] = useState<'signin' | 'register'>('register');
  const [pendingActionAfterAuth, setPendingActionAfterAuth] = useState<'new_auction' | null>(null);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showDecisions, setShowDecisions] = useState(false);
  const [showSellerVerification, setShowSellerVerification] = useState(false);
  const [showPremiumModal, setShowPremiumModal] = useState(false);
  const [publishSuccessMessage, setPublishSuccessMessage] = useState<string | null>(null);

  const enabledCategories = settings.enabledCategories?.length ? settings.enabledCategories : ALL_CATEGORIES;
  const isAdmin = currentUser?.role === 'admin' || currentUser?.role === 'super_admin';

  useEffect(() => {
    if (currentUser && pendingActionAfterAuth === 'new_auction') {
      setShowNewAuctionModal(true);
      setPendingActionAfterAuth(null);
    }
  }, [currentUser, pendingActionAfterAuth]);

  const handleOpenNewAuction = () => {
    if (!currentUser) {
      setAuthModalMode('register');
      setPendingActionAfterAuth('new_auction');
      setShowAuthModal(true);
    } else {
      setShowNewAuctionModal(true);
    }
  };

  const handleOpenAuth = (mode: 'signin' | 'register' = 'register') => {
    setAuthModalMode(mode);
    setShowAuthModal(true);
  };

  const handleSelectProduct = (item: AuctionItem) => {
    recordProductView(item.id);
    setSelectedAuction(item);
  };

  // Filtered & sorted listings (Sponsored items prioritized, strictly requires Document Verification === 'verified')
  const filteredAuctions = auctions
    .filter((item) => {
      if (item.documentVerificationStatus !== 'verified') return false;
      if (!['en_cours', 'programmee', 'terminee'].includes(item.status)) return false;
      if (selectedSaleType !== 'all') {
        const itemSaleType = item.saleType || 'enchere';
        if (itemSaleType !== selectedSaleType) return false;
      }
      if (selectedCategory !== 'all' && item.category !== selectedCategory) return false;
      if (selectedCommune !== 'all' && item.location.commune !== selectedCommune) return false;

      const itemPrice = item.saleType === 'prix_fixe' && item.fixedPrice ? item.fixedPrice : item.currentPrice;
      if (minPriceFilter && !isNaN(Number(minPriceFilter)) && itemPrice < Number(minPriceFilter)) {
        return false;
      }
      if (maxPriceFilter && !isNaN(Number(maxPriceFilter)) && itemPrice > Number(maxPriceFilter)) {
        return false;
      }

      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesTitle = item.title.toLowerCase().includes(query);
        const matchesDesc = item.description.toLowerCase().includes(query);
        const matchesCommune = item.location.commune.toLowerCase().includes(query);
        const matchesSeller = item.sellerName.toLowerCase().includes(query);
        if (!matchesTitle && !matchesDesc && !matchesCommune && !matchesSeller) return false;
      }
      return true;
    })
    .sort((a, b) => {
      // Sponsored items always prioritized
      if (Boolean(a.isSponsored) !== Boolean(b.isSponsored)) {
        return a.isSponsored ? -1 : 1;
      }
      if (sortBy === 'ending_soon') {
        return new Date(a.endDate).getTime() - new Date(b.endDate).getTime();
      }
      if (sortBy === 'price_asc') {
        const priceA = a.saleType === 'prix_fixe' && a.fixedPrice ? a.fixedPrice : a.currentPrice;
        const priceB = b.saleType === 'prix_fixe' && b.fixedPrice ? b.fixedPrice : b.currentPrice;
        return priceA - priceB;
      }
      if (sortBy === 'price_desc') {
        const priceA = a.saleType === 'prix_fixe' && a.fixedPrice ? a.fixedPrice : a.currentPrice;
        const priceB = b.saleType === 'prix_fixe' && b.fixedPrice ? b.fixedPrice : b.currentPrice;
        return priceB - priceA;
      }
      return b.viewsCount - a.viewsCount;
    });

  const heroAuction =
    auctions.find((a) => a.status === 'en_cours' && a.documentVerificationStatus === 'verified') ||
    null;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col text-slate-900 selection:bg-amber-200">
      {/* Top Navbar */}
      <Navbar
        currentCategory={selectedCategory}
        onSelectCategory={(cat) => {
          setSelectedCategory(cat);
          setActiveView('home');
        }}
        activeView={activeView}
        setActiveView={setActiveView}
        onOpenNewAuction={handleOpenNewAuction}
        onOpenAuth={handleOpenAuth}
        onOpenNotifications={() => setShowNotifications(true)}
        onOpenDecisions={() => setShowDecisions(true)}
        onOpenPremium={() => setShowPremiumModal(true)}
      />

      {/* Success Notification Banner */}
      {publishSuccessMessage && (
        <div className="bg-emerald-600 text-white px-4 py-3 shadow-md flex items-center justify-between z-30">
          <div className="max-w-7xl mx-auto flex items-center gap-2 text-xs font-semibold">
            <CheckCircle2 className="w-5 h-5 shrink-0 text-white" />
            <span>{publishSuccessMessage}</span>
          </div>
          <button
            type="button"
            onClick={() => setPublishSuccessMessage(null)}
            className="text-white hover:text-emerald-100 p-1 cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Main View Router */}
      <main className="flex-1">
        {activeView === 'admin' && isAdmin ? (
          <AdminDashboard onSelectAuction={handleSelectProduct} />
        ) : activeView === 'seller' && currentUser ? (
          <SellerDashboard
            onOpenNewAuction={handleOpenNewAuction}
            onSelectAuction={handleSelectProduct}
            onOpenVerification={() => setShowSellerVerification(true)}
            onOpenPremium={() => setShowPremiumModal(true)}
          />
        ) : activeView === 'buyer' ? (
          <BuyerDashboard
            onSelectAuction={handleSelectProduct}
            onOpenNewAuction={handleOpenNewAuction}
            onOpenPremium={() => setShowPremiumModal(true)}
          />
        ) : (
          /* HOME & PUBLIC MARKETPLACE CATALOG */
          <div>
            {/* Hero Section (Bleu Marine #0B1F3A - Section 15) */}
            <section className="relative bg-[#0B1F3A] text-white overflow-hidden border-b border-[#163254]">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 lg:py-16">
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
                  {/* Left Column: Brand Statement */}
                  <div className="lg:col-span-7 space-y-6">
                    <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 uppercase tracking-widest flex-wrap">
                      <span>{t(language, 'heroBadge')}</span>
                      <span aria-hidden="true">·</span>
                      <span>{t(language, 'heroSubtitleBadge')}</span>
                    </div>

                    <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight leading-tight text-white font-serif-display">
                      {t(language, 'heroTitle')}
                    </h1>

                    <p className="text-sm sm:text-base text-slate-200 max-w-2xl leading-relaxed">
                      {t(language, 'heroDesc')}
                    </p>

                    <div className="flex flex-wrap items-center gap-4 pt-2">
                      <button
                        type="button"
                        onClick={() => {
                          const catalog = document.getElementById('catalog-section');
                          catalog?.scrollIntoView({ behavior: 'smooth' });
                        }}
                        className="px-6 py-3 bg-amber-400 hover:bg-amber-300 text-[#0B1F3A] font-bold text-xs rounded-lg transition-colors shadow-lg cursor-pointer"
                      >
                        {t(language, 'exploreCta')} ({auctions.filter((a) => a.status === 'en_cours').length})
                      </button>

                      <button
                        type="button"
                        onClick={handleOpenNewAuction}
                        className="px-5 py-3 bg-[#14325C] hover:bg-[#1B4075] text-white font-bold text-xs rounded-lg border border-amber-400/40 hover:border-amber-300 transition-colors flex items-center gap-2 shadow-sm cursor-pointer"
                      >
                        <PlusCircle className="w-4 h-4 text-amber-400" />
                        <span>{t(language, 'sellCta')}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => setShowDecisions(true)}
                        className="px-4 py-3 text-slate-300 hover:text-white text-xs font-semibold transition-colors cursor-pointer"
                      >
                        {t(language, 'techSheetRates')}
                      </button>
                    </div>
                  </div>

                  {/* Right Column: Hero Spotlight Card */}
                  <div className="lg:col-span-5">
                    {heroAuction ? (
                      <div
                        onClick={() => handleSelectProduct(heroAuction)}
                        className="group relative bg-[#102A4C] border border-[#244B82] rounded-2xl overflow-hidden shadow-2xl cursor-pointer hover:border-amber-400/60 transition-all duration-300"
                      >
                        <div className="relative aspect-[16/10] overflow-hidden">
                          <img
                            src={heroAuction.images[0]}
                            alt={heroAuction.title}
                            referrerPolicy="no-referrer"
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                          />
                          <div className="absolute top-3 left-3 bg-[#0B1F3A]/85 backdrop-blur-md text-amber-400 text-[11px] px-3 py-1 rounded font-bold uppercase tracking-wider">
                            {t(language, 'featuredTag')}
                          </div>
                        </div>

                        <div className="p-5 space-y-3">
                          <div className="flex items-center gap-2 text-xs text-slate-300">
                            <span className="text-white font-medium">
                              {getCategoryLabel(heroAuction.category, language)}
                            </span>
                            <span aria-hidden="true">·</span>
                            <span>{heroAuction.location.commune}, Kinshasa</span>
                            <span aria-hidden="true">·</span>
                            <span className="text-emerald-400 font-medium flex items-center gap-0.5">
                              <ShieldCheck className="w-3.5 h-3.5" />
                              {t(language, 'verifiedBadge')}
                            </span>
                          </div>

                          <h3 className="text-base font-bold text-white group-hover:text-amber-300 transition-colors line-clamp-2">
                            {heroAuction.title}
                          </h3>

                          <div className="flex items-end justify-between pt-2 border-t border-[#1D3E6D]">
                            <div>
                              <span className="text-[11px] text-slate-300 block">
                                {heroAuction.saleType === 'prix_fixe'
                                  ? t(language, 'fixedPriceLabel')
                                  : t(language, 'currentBidLabel')}
                              </span>
                              <span className="text-xl font-bold text-amber-400 font-mono">
                                {formatUsd(
                                  heroAuction.saleType === 'prix_fixe' && heroAuction.fixedPrice
                                    ? heroAuction.fixedPrice
                                    : heroAuction.currentPrice
                                )}
                              </span>
                            </div>

                            <span className="px-3 py-1.5 bg-[#1B4075] hover:bg-[#244B82] text-white rounded text-xs font-semibold">
                              {t(language, 'consultArrow')}
                            </span>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="bg-[#102A4C] border border-amber-400/30 rounded-2xl p-6 sm:p-8 text-center space-y-5 shadow-2xl">
                        <div className="w-14 h-14 bg-amber-400/15 border border-amber-400/30 rounded-2xl flex items-center justify-center mx-auto text-amber-400">
                          <PlusCircle className="w-7 h-7" />
                        </div>
                        <div className="space-y-2">
                          <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-400/20 text-amber-300 uppercase tracking-wider inline-block">
                            {t(language, 'heroEmptyBadge')}
                          </span>
                          <h3 className="text-lg font-bold text-white">
                            {t(language, 'heroEmptyTitle')}
                          </h3>
                          <p className="text-xs text-slate-200 max-w-sm mx-auto leading-relaxed">
                            {t(language, 'heroEmptyDesc')}
                          </p>
                        </div>
                        <button
                          type="button"
                          onClick={handleOpenNewAuction}
                          className="w-full py-3 bg-amber-400 hover:bg-amber-300 text-[#0B1F3A] font-bold text-xs rounded-xl transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
                        >
                          <PlusCircle className="w-4 h-4" />
                          <span>{t(language, 'sellCta')}</span>
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* Proof strip below hero */}
                <div className="mt-12 pt-8 border-t border-[#163254] grid grid-cols-2 md:grid-cols-4 gap-6 text-xs text-slate-300">
                  <div className="space-y-1">
                    <span className="font-bold text-white block">{t(language, 'proofFixedTitle')}</span>
                    <p className="text-[11px] text-slate-300">
                      {t(language, 'proofFixedDesc', { fee: settings.fixedPriceBuyerFeeUsd ?? 1 })}
                    </p>
                  </div>
                  <div className="space-y-1">
                    <span className="font-bold text-white block">{t(language, 'proofAuctionTitle')}</span>
                    <p className="text-[11px] text-slate-300">
                      {t(language, 'proofAuctionDesc', { price: settings.premiumSubscriptionPriceUsd ?? 50 })}
                    </p>
                  </div>
                  <div className="space-y-1">
                    <span className="font-bold text-white block">{t(language, 'proofAggregatorTitle')}</span>
                    <p className="text-[11px] text-slate-300">
                      {t(language, 'proofAggregatorDesc')}
                    </p>
                  </div>
                  <div className="space-y-1">
                    <span className="font-bold text-white block">{t(language, 'proofAdsTitle')}</span>
                    <p className="text-[11px] text-slate-300">
                      {t(language, 'proofAdsDesc')}
                    </p>
                  </div>
                </div>
              </div>
            </section>

            {/* Filter & Search Bar */}
            <section
              id="catalog-section"
              className="sticky top-16 z-30 bg-white border-b border-slate-200 shadow-xs"
            >
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 space-y-2.5">
                {/* Row 1: Category Pills (All 9 Categories) */}
                <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
                  <button
                    type="button"
                    onClick={() => setSelectedCategory('all')}
                    className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap cursor-pointer shrink-0 ${
                      selectedCategory === 'all'
                        ? 'bg-[#0B1F3A] text-white shadow-xs'
                        : 'bg-slate-100 text-slate-600 hover:text-[#0B1F3A]'
                    }`}
                  >
                    {t(language, 'allCategories')} ({auctions.length})
                  </button>

                  {enabledCategories.map((cat) => {
                    const IconComp = CATEGORY_ICONS[cat] || Building;
                    const count = auctions.filter((a) => a.category === cat).length;
                    return (
                      <button
                        key={cat}
                        type="button"
                        onClick={() => setSelectedCategory(cat)}
                        className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap flex items-center gap-1.5 cursor-pointer shrink-0 ${
                          selectedCategory === cat
                            ? 'bg-[#0B1F3A] text-white shadow-xs'
                            : 'bg-slate-100 text-slate-600 hover:text-[#0B1F3A]'
                        }`}
                      >
                        <IconComp className="w-3.5 h-3.5" />
                        <span>{getCategoryLabel(cat, language)}</span>
                        {count > 0 && (
                          <span className="text-[10px] opacity-80 font-mono">({count})</span>
                        )}
                      </button>
                    );
                  })}
                </div>

                {/* Row 2: Sale Type, Price Range, Commune, Search & Sort */}
                <div className="flex flex-wrap items-center justify-between gap-2">
                  {/* Sale Type Pills */}
                  <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
                    <button
                      type="button"
                      onClick={() => setSelectedSaleType('all')}
                      className={`px-2.5 py-1 text-xs font-bold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                        selectedSaleType === 'all'
                          ? 'bg-amber-400 text-[#0B1F3A] shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      {t(language, 'allFormats')}
                    </button>
                    <button
                      type="button"
                      onClick={() => setSelectedSaleType('prix_fixe')}
                      className={`px-2.5 py-1 text-xs font-bold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                        selectedSaleType === 'prix_fixe'
                          ? 'bg-emerald-600 text-white shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      {t(language, 'fixedPriceOnly')}
                    </button>
                    <button
                      type="button"
                      onClick={() => setSelectedSaleType('enchere')}
                      className={`px-2.5 py-1 text-xs font-bold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                        selectedSaleType === 'enchere'
                          ? 'bg-[#0B1F3A] text-amber-300 shadow-xs'
                          : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      {t(language, 'auctionsOnly')}
                    </button>
                  </div>

                  {/* Price range, Location, Search & Sort */}
                  <div className="flex flex-wrap items-center gap-2 flex-1 justify-end">
                    {/* Price Min/Max (Section 10) */}
                    <div className="flex items-center gap-1">
                      <input
                        type="number"
                        min={0}
                        placeholder="Min $"
                        value={minPriceFilter}
                        onChange={(e) => setMinPriceFilter(e.target.value)}
                        className="w-20 h-9 px-2 text-xs font-mono bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#0B1F3A]"
                      />
                      <span className="text-slate-400 text-xs">-</span>
                      <input
                        type="number"
                        min={0}
                        placeholder="Max $"
                        value={maxPriceFilter}
                        onChange={(e) => setMaxPriceFilter(e.target.value)}
                        className="w-20 h-9 px-2 text-xs font-mono bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#0B1F3A]"
                      />
                    </div>

                    {/* Commune Selector */}
                    <div className="relative">
                      <select
                        value={selectedCommune}
                        onChange={(e) => setSelectedCommune(e.target.value)}
                        className="h-9 pl-3 pr-7 text-xs font-medium bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#0B1F3A] appearance-none text-slate-700"
                      >
                        <option value="all">{t(language, 'allCommunes')}</option>
                        <option value="Gombe">Gombe</option>
                        <option value="Ngaliema">Ngaliema</option>
                        <option value="Limete">Limete</option>
                        <option value="Kintambo">Kintambo</option>
                        <option value="Bandalungwa">Bandalungwa</option>
                        <option value="Mont-Ngafula">Mont-Ngafula</option>
                        <option value="Barumbu">Barumbu</option>
                        <option value="Lingwala">Lingwala</option>
                        <option value="Lemba">Lemba</option>
                      </select>
                      <span className="absolute right-2.5 top-2.5 text-slate-400 pointer-events-none text-[10px]">
                        ▼
                      </span>
                    </div>

                    {/* Search Bar */}
                    <div className="relative min-w-[190px] flex-1 sm:flex-initial">
                      <Search className="absolute left-2.5 top-2.5 w-4 h-4 text-slate-400" />
                      <input
                        type="text"
                        placeholder={t(language, 'searchPlaceholder')}
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="w-full h-9 pl-8 pr-7 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#0B1F3A]"
                      />
                      {searchQuery && (
                        <button
                          type="button"
                          onClick={() => setSearchQuery('')}
                          className="absolute right-2 top-2.5 text-slate-400 hover:text-slate-600 cursor-pointer"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      )}
                    </div>

                    {/* Sorting */}
                    <div className="relative">
                      <select
                        value={sortBy}
                        onChange={(e) => setSortBy(e.target.value as any)}
                        className="h-9 pl-3 pr-7 text-xs font-medium bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#0B1F3A] appearance-none text-slate-700"
                      >
                        <option value="ending_soon">{t(language, 'sortEndingSoon')}</option>
                        <option value="price_asc">{t(language, 'sortPriceAsc')}</option>
                        <option value="price_desc">{t(language, 'sortPriceDesc')}</option>
                        <option value="popular">{t(language, 'sortPopular')}</option>
                      </select>
                      <span className="absolute right-2.5 top-2.5 text-slate-400 pointer-events-none text-[10px]">
                        ▼
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* Catalog Grid Section */}
            <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
              {/* Seller Callout */}
              <div className="mb-8 p-6 bg-[#0B1F3A] text-white rounded-2xl shadow-xl border border-[#163254] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-400 text-[#0B1F3A] uppercase tracking-wider">
                      {t(language, 'sellerCalloutTag')}
                    </span>
                    <span className="text-xs text-amber-200">{t(language, 'sellerCalloutSub')}</span>
                  </div>
                  <h3 className="text-base sm:text-lg font-bold text-white font-serif-display">
                    {t(language, 'sellerCalloutTitle')}
                  </h3>
                  <p className="text-xs text-slate-200 max-w-2xl leading-relaxed">
                    {t(language, 'sellerCalloutDesc')}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={handleOpenNewAuction}
                  className="px-5 py-3 bg-amber-400 hover:bg-amber-300 text-[#0B1F3A] font-bold text-xs rounded-xl transition-all shadow-md flex items-center gap-2 shrink-0 self-start sm:self-auto cursor-pointer"
                >
                  <PlusCircle className="w-4 h-4" />
                  <span>{t(language, 'publishCta')}</span>
                </button>
              </div>

              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-xl font-bold text-[#0B1F3A]">
                    {t(language, 'catalogTitle')}
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {t(language, 'catalogCount', { count: filteredAuctions.length })}
                  </p>
                </div>

                <div className="flex items-center gap-2 text-xs text-slate-500">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                  <span className="font-mono">{t(language, 'liveEngineLabel')}</span>
                </div>
              </div>

              {filteredAuctions.length === 0 ? (
                <div className="text-center py-16 px-4 bg-white rounded-2xl border border-slate-200">
                  <div className="w-16 h-16 bg-blue-50 border border-blue-200 rounded-2xl flex items-center justify-center mx-auto text-[#0B1F3A] mb-4">
                    <PlusCircle className="w-8 h-8" />
                  </div>
                  {auctions.length === 0 ? (
                    <div className="max-w-md mx-auto space-y-3">
                      <h3 className="text-lg font-bold text-slate-800">
                        {t(language, 'noUserListingsTitle')}
                      </h3>
                      <p className="text-xs text-slate-500 leading-relaxed">
                        {t(language, 'noUserListingsDesc')}
                      </p>
                      <div className="pt-2">
                        <button
                          type="button"
                          onClick={handleOpenNewAuction}
                          className="px-5 py-3 bg-amber-400 hover:bg-amber-300 text-[#0B1F3A] font-bold text-xs rounded-xl shadow-md inline-flex items-center gap-2 cursor-pointer transition-all"
                        >
                          <PlusCircle className="w-4 h-4" />
                          <span>{t(language, 'publishFirstBtn')}</span>
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div>
                      <h3 className="text-base font-bold text-slate-800">{t(language, 'noFilterMatchTitle')}</h3>
                      <p className="text-xs text-slate-500 max-w-md mx-auto mt-1 mb-4">
                        {t(language, 'noFilterMatchDesc')}
                      </p>
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedCategory('all');
                          setSelectedSaleType('all');
                          setSelectedCommune('all');
                          setMinPriceFilter('');
                          setMaxPriceFilter('');
                          setSearchQuery('');
                        }}
                        className="px-4 py-2 bg-[#0B1F3A] text-white text-xs font-semibold rounded-lg cursor-pointer"
                      >
                        {t(language, 'resetFiltersBtn')}
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
                  {filteredAuctions.map((item) => (
                    <AuctionCard
                      key={item.id}
                      item={item}
                      onSelect={handleSelectProduct}
                    />
                  ))}
                </div>
              )}
            </section>
          </div>
        )}
      </main>

      {/* Footer */}
      <Footer
        onSelectCategory={(cat) => {
          setSelectedCategory(cat);
          setActiveView('home');
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onOpenDecisions={() => setShowDecisions(true)}
      />

      {/* Modals Container */}
      {selectedAuction && (
        <AuctionDetailModal
          item={selectedAuction}
          onClose={() => setSelectedAuction(null)}
          onOpenAuth={() => handleOpenAuth('register')}
        />
      )}

      {showNewAuctionModal && (
        <NewAuctionModal
          onClose={() => setShowNewAuctionModal(false)}
          onSuccess={(title) => {
            setShowNewAuctionModal(false);
            setPublishSuccessMessage(
              `Annonce "${title}" soumise ! Statut Document Verification : Pending — elle sera publiée dès validation (Verified) par un administrateur.`
            );
            setActiveView('seller');
            setTimeout(() => setPublishSuccessMessage(null), 9000);
          }}
        />
      )}

      {showAuthModal && (
        <AuthModal
          defaultMode={authModalMode}
          onClose={() => setShowAuthModal(false)}
        />
      )}

      {showNotifications && (
        <NotificationsDrawer
          onClose={() => setShowNotifications(false)}
          onSelectAuctionId={(id) => {
            const found = auctions.find((a) => a.id === id);
            if (found) handleSelectProduct(found);
          }}
        />
      )}

      {showDecisions && (
        <DecisionsModal
          onClose={() => setShowDecisions(false)}
          onGoToSettings={() => {
            setActiveView('admin');
          }}
        />
      )}

      {showSellerVerification && (
        <SellerVerificationModal onClose={() => setShowSellerVerification(false)} />
      )}

      {showPremiumModal && (
        <PremiumSubscriptionModal
          onClose={() => setShowPremiumModal(false)}
          onOpenAuth={() => handleOpenAuth('register')}
        />
      )}
    </div>
  );
}

export default function App() {
  return (
    <AuctiaProvider>
      <NgoluMarketApp />
    </AuctiaProvider>
  );
}
