import { AuctionStatus, Category, Language, OrderStatus } from '../types';

export const ALL_CATEGORIES: Category[] = [
  'immobilier',
  'automobile',
  'mode',
  'sport',
  'cosmetiques',
  'alimentaire',
  'meuble',
  'electronique',
  'electromenager',
];

export const formatUsd = (amount: number): string => {
  return new Intl.NumberFormat('fr-CD', {
    style: 'currency',
    currency: 'USD',
    maximumFractionDigits: 0,
  }).format(amount);
};

export const formatCdf = (usdAmount: number, rate: number = 2850): string => {
  const cdf = usdAmount * rate;
  if (cdf >= 1000000000) {
    return `${(cdf / 1000000000).toFixed(2)} Mds CDF`;
  }
  if (cdf >= 1000000) {
    return `${(cdf / 1000000).toFixed(1)} M CDF`;
  }
  return `${new Intl.NumberFormat('fr-CD').format(cdf)} CDF`;
};

export const getCategoryLabel = (cat: Category, lang: Language = 'fr'): string => {
  const labels: Record<Language, Record<Category, string>> = {
    fr: {
      immobilier: 'Immobilier',
      automobile: 'Automobile',
      mode: 'Mode & Horlogerie',
      sport: 'Sport',
      cosmetiques: 'Cosmétiques',
      alimentaire: 'Alimentaire',
      meuble: 'Meuble',
      electronique: 'Électronique',
      electromenager: 'Électroménager',
    },
    en: {
      immobilier: 'Real Estate',
      automobile: 'Automotive',
      mode: 'Fashion & Watches',
      sport: 'Sports',
      cosmetiques: 'Cosmetics',
      alimentaire: 'Food & Groceries',
      meuble: 'Furniture',
      electronique: 'Electronics',
      electromenager: 'Home Appliances',
    },
    ln: {
      immobilier: 'Bandako & Mabele',
      automobile: 'Mituka',
      mode: 'Bilamba & Montre',
      sport: 'Masano (Sport)',
      cosmetiques: 'Mafuta & Kitoko',
      alimentaire: 'Biloko ya Kolia',
      meuble: 'Biloko ya Ndako',
      electronique: 'Électronique & Telefoni',
      electromenager: 'Biloko ya Kura na Ndako',
    },
  };
  return labels[lang]?.[cat] || labels.fr[cat] || cat;
};

export const getCategoryDefaultImage = (cat: Category): string => {
  switch (cat) {
    case 'immobilier':
      return '/src/assets/images/villa_gombe_kinshasa_1792177623548.jpg';
    case 'automobile':
      return '/src/assets/images/toyota_landcruiser_v8_1792177623866.jpg';
    case 'mode':
      return '/src/assets/images/montre_rolex_submariner_1792177623672.jpg';
    default:
      return '/src/assets/images/appartement_ngaliema_1792177624266.jpg';
  }
};

export const getStatusLabel = (
  status: AuctionStatus,
  lang: Language = 'fr'
): { label: string; textClass: string; isEnded: boolean } => {
  const dict: Record<Language, Record<AuctionStatus, string>> = {
    fr: {
      en_cours: 'En cours',
      programmee: 'Programmée',
      terminee: 'Clôturée / Vendue',
      en_attente: 'En attente de validation',
      suspendue: 'Suspendue par modération',
      annulee: 'Annulée',
      brouillon: 'Brouillon',
    },
    en: {
      en_cours: 'Live',
      programmee: 'Scheduled',
      terminee: 'Closed / Sold',
      en_attente: 'Pending review',
      suspendue: 'Suspended',
      annulee: 'Cancelled',
      brouillon: 'Draft',
    },
    ln: {
      en_cours: 'Ezali kosalema',
      programmee: 'Etiami na progamme',
      terminee: 'Esili / Etekami',
      en_attente: 'Ezali kozela ndingisa',
      suspendue: 'Ekangami na boyangeli',
      annulee: 'Ebwakami',
      brouillon: 'Brouillon',
    },
  };

  const label = dict[lang]?.[status] || dict.fr[status] || status;
  switch (status) {
    case 'en_cours':
      return { label, textClass: 'text-emerald-700 font-medium', isEnded: false };
    case 'programmee':
      return { label, textClass: 'text-blue-700 font-medium', isEnded: false };
    case 'terminee':
      return { label, textClass: 'text-slate-500 font-medium', isEnded: true };
    case 'en_attente':
      return { label, textClass: 'text-amber-700 font-medium', isEnded: false };
    case 'suspendue':
      return { label, textClass: 'text-rose-700 font-medium', isEnded: true };
    case 'annulee':
      return { label, textClass: 'text-rose-600 font-medium', isEnded: true };
    case 'brouillon':
      return { label, textClass: 'text-slate-400 font-medium', isEnded: false };
    default:
      return { label: status, textClass: 'text-slate-600', isEnded: false };
  }
};

export const getOrderStatusLabel = (
  status?: OrderStatus,
  lang: Language = 'fr'
): { label: string; badgeClass: string } => {
  const dict: Record<Language, Record<OrderStatus, string>> = {
    fr: {
      en_attente_paiement: 'En attente de paiement',
      paiement_confirme: 'Paiement confirmé',
      commande_acceptee: 'Commande acceptée',
      en_preparation: 'En préparation',
      expediee: 'Expédiée / Remise',
      terminee: 'Terminée',
      annulee: 'Annulée',
      litige: 'En litige',
    },
    en: {
      en_attente_paiement: 'Awaiting payment',
      paiement_confirme: 'Payment confirmed',
      commande_acceptee: 'Order accepted',
      en_preparation: 'Preparing',
      expediee: 'Shipped / Delivered',
      terminee: 'Completed',
      annulee: 'Cancelled',
      litige: 'In dispute',
    },
    ln: {
      en_attente_paiement: 'Ezali kozela lifuti',
      paiement_confirme: 'Lifuti endimami',
      commande_acceptee: 'Komande endimami',
      en_preparation: 'Bazali kobongisa',
      expediee: 'Etindami / Epesami',
      terminee: 'Esili malamu',
      annulee: 'Eboyami',
      litige: 'Matata na kati',
    },
  };

  const key: OrderStatus = status || 'en_attente_paiement';
  const label = dict[lang]?.[key] || dict.fr[key];

  switch (status) {
    case 'paiement_confirme':
      return { label, badgeClass: 'bg-blue-50 text-blue-700 border-blue-200' };
    case 'commande_acceptee':
      return { label, badgeClass: 'bg-indigo-50 text-indigo-700 border-indigo-200' };
    case 'en_preparation':
      return { label, badgeClass: 'bg-amber-50 text-amber-800 border-amber-200' };
    case 'expediee':
      return { label, badgeClass: 'bg-purple-50 text-purple-700 border-purple-200' };
    case 'terminee':
      return { label, badgeClass: 'bg-emerald-50 text-emerald-700 border-emerald-200' };
    case 'annulee':
      return { label, badgeClass: 'bg-slate-100 text-slate-600 border-slate-200' };
    case 'litige':
      return { label, badgeClass: 'bg-rose-50 text-rose-700 border-rose-200' };
    case 'en_attente_paiement':
    default:
      return { label, badgeClass: 'bg-amber-50 text-amber-700 border-amber-200' };
  }
};

export const calculateTimeRemaining = (
  endDateString: string,
  startDateString?: string,
  status?: AuctionStatus,
  lang: Language = 'fr'
): { text: string; isUrgent: boolean; isExpired: boolean; msRemaining: number } => {
  const now = new Date().getTime();
  const end = new Date(endDateString).getTime();

  if (status === 'programmee' && startDateString) {
    const start = new Date(startDateString).getTime();
    const diff = start - now;
    if (diff > 0) {
      const hours = Math.floor(diff / (1000 * 60 * 60));
      const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const prefix = lang === 'en' ? 'Starts in' : lang === 'ln' ? 'Ekobanda na' : 'Débute dans';
      return {
        text: `${prefix} ${hours}h ${mins}m`,
        isUrgent: false,
        isExpired: false,
        msRemaining: diff,
      };
    }
  }

  const diff = end - now;

  if (diff <= 0 || status === 'terminee' || status === 'annulee') {
    return {
      text: lang === 'en' ? 'Closed' : lang === 'ln' ? 'Esili' : 'Clôturée',
      isUrgent: false,
      isExpired: true,
      msRemaining: 0,
    };
  }

  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((diff % (1000 * 60)) / 1000);

  const isUrgent = diff <= 15 * 60 * 1000;
  const dayUnit = lang === 'en' ? 'd' : lang === 'ln' ? 'mik.' : 'j';
  const remainingLabel = lang === 'en' ? 'left' : lang === 'ln' ? 'etikali' : 'restants';

  if (days > 0) {
    return {
      text: `${days}${dayUnit} ${hours}h ${remainingLabel}`,
      isUrgent: false,
      isExpired: false,
      msRemaining: diff,
    };
  }

  if (hours > 0) {
    return {
      text: `${hours}h ${minutes}m ${remainingLabel}`,
      isUrgent: false,
      isExpired: false,
      msRemaining: diff,
    };
  }

  return {
    text: `${minutes}m ${seconds < 10 ? '0' : ''}${seconds}s`,
    isUrgent: true,
    isExpired: false,
    msRemaining: diff,
  };
};

export const getSaleTypeLabel = (
  saleType?: 'enchere' | 'prix_fixe',
  lang: Language = 'fr'
): { label: string; shortLabel: string; badgeClass: string } => {
  if (saleType === 'prix_fixe') {
    return {
      label:
        lang === 'en'
          ? 'Fixed-Price Sale (Instant Buy)'
          : lang === 'ln'
          ? 'Ntalo ya Libela (Kosomba mbala moko)'
          : 'Vente à Prix Fixe (Achat Immédiat)',
      shortLabel: lang === 'en' ? 'Fixed Price' : lang === 'ln' ? 'Ntalo ya Libela' : 'Prix Fixe',
      badgeClass: 'bg-emerald-50 text-emerald-700 border-emerald-300',
    };
  }
  return {
    label:
      lang === 'en'
        ? 'Online Live Auction'
        : lang === 'ln'
        ? 'Enchère na Internet'
        : 'Vente aux Enchères',
    shortLabel: lang === 'en' ? 'Auction' : 'Enchère',
    badgeClass: 'bg-amber-50 text-amber-800 border-amber-300',
  };
};
