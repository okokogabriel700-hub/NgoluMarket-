import React, { useRef, useState } from 'react';
import {
  AlertCircle,
  Award,
  Building,
  Calculator,
  Car,
  Check,
  CheckCircle2,
  Dumbbell,
  FileCheck,
  FileText,
  Gavel,
  PlugZap,
  ShieldCheck,
  ShoppingBag,
  Smartphone,
  Sofa,
  Sparkles,
  Trash2,
  Upload,
  Utensils,
  Watch,
  X,
} from 'lucide-react';
import { useAuctia } from '../context/AuctiaContext';
import {
  AssetVerificationDocument,
  AutomobileDetails,
  BankAggregatorId,
  Category,
  GeneralProductDetails,
  ImmobilierDetails,
  ModeDetails,
  PaymentMethod,
  PaymentProvider,
  SaleType,
} from '../types';
import { ALL_CATEGORIES, formatUsd, getCategoryDefaultImage, getCategoryLabel } from '../utils/formatters';

interface NewAuctionModalProps {
  onClose: () => void;
  onSuccess: (newAuctionId: string) => void;
}

const CATEGORY_METADATA: Record<
  Category,
  {
    subtitle: string;
    defaultPrice: number;
    defaultStep: number;
    icon: React.FC<{ className?: string }>;
  }
> = {
  immobilier: { subtitle: 'Villas, terrains, appartements', defaultPrice: 120000, defaultStep: 2500, icon: Building },
  automobile: { subtitle: 'Véhicules, SUV, utilitaires', defaultPrice: 45000, defaultStep: 1000, icon: Car },
  mode: { subtitle: 'Horlogerie, maroquinerie', defaultPrice: 3500, defaultStep: 100, icon: Watch },
  sport: { subtitle: 'Fitness, vélos, équipements', defaultPrice: 250, defaultStep: 10, icon: Dumbbell },
  cosmetiques: { subtitle: 'Parfums, soins, beauté', defaultPrice: 80, defaultStep: 5, icon: Sparkles },
  alimentaire: { subtitle: 'Épicerie fine, boissons, gros', defaultPrice: 50, defaultStep: 5, icon: Utensils },
  meuble: { subtitle: 'Salons, bureaux, literie', defaultPrice: 850, defaultStep: 25, icon: Sofa },
  electronique: { subtitle: 'Smartphones, PC, audio', defaultPrice: 650, defaultStep: 20, icon: Smartphone },
  electromenager: { subtitle: 'Frigos, clim, cuisine', defaultPrice: 480, defaultStep: 20, icon: PlugZap },
};

export const NewAuctionModal: React.FC<NewAuctionModalProps> = ({ onClose, onSuccess }) => {
  const { currentUser, submitAuction, settings, activatePremiumSubscription, submitAdCampaign, language } = useAuctia();

  const availableCategories = settings.enabledCategories?.length ? settings.enabledCategories : ALL_CATEGORIES;

  const [saleType, setSaleType] = useState<SaleType>('prix_fixe');
  const [category, setCategory] = useState<Category>(availableCategories[0] || 'immobilier');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [commune, setCommune] = useState('Gombe');
  const [neighborhood, setNeighborhood] = useState('');
  const [startPrice, setStartPrice] = useState(50);
  const [minBidStep, setMinBidStep] = useState(10);
  const [durationDays, setDurationDays] = useState(3);
  const [imageUrl, setImageUrl] = useState(getCategoryDefaultImage('immobilier'));
  const [sponsorOnPublish, setSponsorOnPublish] = useState(false);

  // Premium activation inline panel
  const [premiumAggregator, setPremiumAggregator] = useState<BankAggregatorId>('ngolupay_hub');
  const [premiumMethod, setPremiumMethod] = useState<PaymentMethod>('mobile_money');
  const [premiumPhone, setPremiumPhone] = useState(currentUser?.phone || '+243 ');
  const [premiumProvider, setPremiumProvider] = useState<PaymentProvider>('mpesa');
  const [isActivatingPremium, setIsActivatingPremium] = useState(false);
  const [premiumSuccess, setPremiumSuccess] = useState<string | null>(null);

  // Specific state: Immobilier
  const [propertyType, setPropertyType] = useState<ImmobilierDetails['propertyType']>('Villa');
  const [surfaceM2, setSurfaceM2] = useState(450);
  const [landTitleType, setLandTitleType] = useState<ImmobilierDetails['landTitleType']>('Certificat d’enregistrement');
  const [titleNumber, setTitleNumber] = useState('VOL. AL-90 FOLIO 44');
  const [visitSchedule, setVisitSchedule] = useState('Visites sur rendez-vous 48h à l’avance');

  // Specific state: Automobile
  const [brand, setBrand] = useState('Toyota');
  const [model, setModel] = useState('Land Cruiser Prado TXL');
  const [year, setYear] = useState(2021);
  const [mileageKm, setMileageKm] = useState(38000);
  const [transmission, setTransmission] = useState<'Automatique' | 'Manuelle'>('Automatique');
  const [fuel, setFuel] = useState<'Essence' | 'Diesel' | 'Hybride' | 'Électrique'>('Diesel');
  const [pinkCardOk] = useState(true);

  // Specific state: Mode
  const [modeBrand, setModeBrand] = useState('Rolex');
  const [modeModel, setModeModel] = useState('Submariner Date 41mm');
  const [condition] = useState<ModeDetails['condition']>('État impeccable');

  // Specific state: GeneralProductDetails (6 nouvelles catégories)
  const [productType, setProductType] = useState('');
  const [productBrand, setProductBrand] = useState('');
  const [productModel, setProductModel] = useState('');
  const [productCondition, setProductCondition] = useState<GeneralProductDetails['condition']>('Neuf scellé');
  const [productWarranty, setProductWarranty] = useState('Garantie 12 mois');
  const [deliveryMethod, setDeliveryMethod] = useState('Livraison Kinshasa ou retrait en boutique');

  // Asset Verification Documents (PDF / JPG)
  const [assetDocuments, setAssetDocuments] = useState<AssetVerificationDocument[]>([]);
  const [docLabel, setDocLabel] = useState('Titre de propriété / Certificat d’authenticité');
  const assetDocInputRef = useRef<HTMLInputElement>(null);

  const [error, setError] = useState<string | null>(null);

  const isUserPremium = Boolean(currentUser?.isPremium || currentUser?.role === 'admin' || currentUser?.role === 'super_admin');
  const buyerFeeUsd = settings.fixedPriceBuyerFeeUsd ?? 1;
  const premiumPriceUsd = settings.premiumSubscriptionPriceUsd ?? 50;
  const sponsoredPriceUsd = settings.sponsoredProductPriceUsd ?? 1;

  // Calcul financier selon Fiche Technique NgoluMarket (Sections 6 & 7)
  const projectedCommission =
    saleType === 'prix_fixe' ? 0 : (startPrice * settings.commissionRatePercent) / 100;
  const projectedNet = startPrice - projectedCommission;

  const handleSelectCategory = (cat: Category) => {
    setCategory(cat);
    const meta = CATEGORY_METADATA[cat];
    setImageUrl(getCategoryDefaultImage(cat));
    setStartPrice(meta.defaultPrice);
    setMinBidStep(meta.defaultStep);
    if (!['immobilier', 'automobile', 'mode'].includes(cat)) {
      setProductType(getCategoryLabel(cat, language));
    }
  };

  const handleActivatePremiumInline = async () => {
    setError(null);
    if (!premiumPhone.trim() || premiumPhone.trim().length < 6) {
      setError('Veuillez saisir un numéro Mobile Money ou une référence bancaire/carte valide.');
      return;
    }
    setIsActivatingPremium(true);
    const res = await activatePremiumSubscription({
      method: premiumMethod,
      provider: premiumProvider,
      aggregatorGateway: premiumAggregator,
      accountOrPhone: premiumPhone.trim(),
    });
    setIsActivatingPremium(false);
    if (res.success) {
      setPremiumSuccess(`Compte Premium activé pour 1 trimestre (${premiumPriceUsd} USD).`);
    } else {
      setError(res.error || "Impossible d'activer l'abonnement Premium.");
    }
  };

  const handleAssetDocsUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    setError(null);

    Array.from(files).forEach((file) => {
      const lower = file.name.toLowerCase();
      const isPdf = file.type === 'application/pdf' || lower.endsWith('.pdf');
      const isJpg =
        file.type === 'image/jpeg' ||
        file.type === 'image/jpg' ||
        lower.endsWith('.jpg') ||
        lower.endsWith('.jpeg');

      if (!isPdf && !isJpg) {
        setError(`Format non autorisé (${file.name}). Seuls les fichiers PDF et JPG/JPEG sont acceptés.`);
        return;
      }

      if (file.size > 5 * 1024 * 1024) {
        setError(`Le fichier ${file.name} dépasse la taille maximale autorisée de 5 Mo.`);
        return;
      }

      const reader = new FileReader();
      reader.onload = () => {
        const fileSizeStr =
          file.size >= 1024 * 1024
            ? `${(file.size / (1024 * 1024)).toFixed(2)} Mo`
            : `${Math.max(1, Math.round(file.size / 1024))} Ko`;

        const newDoc: AssetVerificationDocument = {
          id: `adoc-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          name: docLabel.trim() || file.name,
          fileName: file.name,
          fileType: isPdf ? 'application/pdf' : 'image/jpeg',
          fileSize: fileSizeStr,
          fileUrl: String(reader.result || ''),
          status: 'pending',
          uploadedAt: new Date().toISOString(),
        };
        setAssetDocuments((prev) => [...prev, newDoc]);
      };
      reader.readAsDataURL(file);
    });

    e.target.value = '';
  };

  const removeAssetDoc = (id: string) => {
    setAssetDocuments((prev) => prev.filter((d) => d.id !== id));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!title.trim()) {
      setError('Veuillez renseigner un titre pour votre annonce.');
      return;
    }
    if (startPrice <= 0) {
      setError('Le prix doit être supérieur à 0 USD.');
      return;
    }

    if (saleType === 'enchere' && !isUserPremium) {
      setError(
        `La publication d'une vente aux enchères est réservée aux Vendeurs Premium (${premiumPriceUsd} USD/trimestre). Activez votre abonnement ci-dessous ou choisissez la Vente à Prix Fixe (gratuite).`
      );
      return;
    }

    let specificDetails: any = {};
    if (category === 'immobilier') {
      specificDetails = {
        propertyType,
        surfaceM2: Number(surfaceM2),
        landTitleType,
        titleNumber,
        visitSchedule,
        documentsVerified: true,
      };
    } else if (category === 'automobile') {
      specificDetails = {
        brand,
        model,
        year: Number(year),
        mileageKm: Number(mileageKm),
        transmission,
        fuel,
        condition: 'Excellent',
        technicalInspectionOk: true,
        pinkCardOk,
        chassisVin: 'VIN-' + Math.floor(10000000 + Math.random() * 90000000),
      } as AutomobileDetails;
    } else if (category === 'mode') {
      specificDetails = {
        itemType: 'Montre de prestige',
        brand: modeBrand,
        model: modeModel,
        color: 'Acier / Noir',
        condition,
        authenticityCertificate: true,
        boxAndPapers: true,
        deliveryMethod: 'Retrait sécurisé à Gombe',
      };
    } else {
      specificDetails = {
        productType: productType.trim() || getCategoryLabel(category, language),
        brand: productBrand.trim() || 'Marque certifiée',
        model: productModel.trim() || undefined,
        condition: productCondition,
        warranty: productWarranty,
        deliveryMethod,
      } as GeneralProductDetails;
    }

    const endDate = new Date(Date.now() + durationDays * 24 * 60 * 60 * 1000).toISOString();

    const result = submitAuction({
      title,
      category,
      saleType,
      fixedPrice: saleType === 'prix_fixe' ? Number(startPrice) : undefined,
      description,
      images: [imageUrl],
      startPrice: Number(startPrice),
      minBidStep: saleType === 'prix_fixe' ? 0 : Number(minBidStep),
      startDate: new Date().toISOString(),
      endDate,
      isSponsored: sponsorOnPublish,
      location: {
        city: 'Kinshasa',
        commune,
        neighborhood: neighborhood || 'Kinshasa',
      },
      specificDetails,
      assetDocuments,
      documentVerificationStatus: 'pending',
    });

    if (result.success) {
      if (sponsorOnPublish && currentUser) {
        await submitAdCampaign({
          type: 'sponsored_product',
          title,
          provider: 'mpesa',
          accountOrPhone: currentUser.phone,
        });
      }
      onSuccess(title);
    } else {
      setError(result.error || 'Erreur lors de la soumission.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6">
      <div className="relative w-full max-w-3xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#163254] bg-[#0B1F3A] text-white">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-white">
              Publier un produit sur NgoluMarket
            </h2>
            <p className="text-xs text-slate-300">
              Vendeur : <strong className="text-amber-300">{currentUser?.name || 'Membre NgoluMarket'}</strong>
              {currentUser?.companyName ? ` (${currentUser.companyName})` : ''} · Kinshasa
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-6">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-rose-800 text-xs flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* 1. Type de vente */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-[#0B1F3A] mb-2">
              1. Mode de commercialisation
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setSaleType('prix_fixe')}
                className={`p-3.5 rounded-xl border text-left transition-all flex items-start gap-3 ${
                  saleType === 'prix_fixe'
                    ? 'border-emerald-500 bg-emerald-50/60 text-slate-900 ring-2 ring-emerald-500/30'
                    : 'border-slate-200 hover:border-slate-300 text-slate-600'
                }`}
              >
                <div className="p-2 rounded-lg bg-emerald-100 text-emerald-800 shrink-0 mt-0.5">
                  <ShoppingBag className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-900">Vente à Prix Fixe (Gratuit vendeur)</div>
                  <div className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
                    Publication gratuite. Frais plateforme de {buyerFeeUsd} USD payés par l’acheteur.
                  </div>
                </div>
              </button>

              <button
                type="button"
                onClick={() => setSaleType('enchere')}
                className={`p-3.5 rounded-xl border text-left transition-all flex items-start gap-3 ${
                  saleType === 'enchere'
                    ? 'border-amber-500 bg-amber-50/60 text-slate-900 ring-2 ring-amber-500/30'
                    : 'border-slate-200 hover:border-slate-300 text-slate-600'
                }`}
              >
                <div className="p-2 rounded-lg bg-amber-100 text-amber-800 shrink-0 mt-0.5">
                  <Gavel className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                    <span>Vente aux Enchères</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-[#0B1F3A] text-amber-300 font-bold">
                      Premium
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
                    Réservé aux Vendeurs Premium ({premiumPriceUsd} USD/trim). Commission {settings.commissionRatePercent}% sur prix final.
                  </div>
                </div>
              </button>
            </div>

            {/* Inline Premium Activation Banner when Enchères selected & not Premium */}
            {saleType === 'enchere' && !isUserPremium && (
              <div className="mt-3 p-4 bg-[#0B1F3A] text-white rounded-xl border border-amber-400/40 space-y-3 text-xs">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-2.5">
                    <Award className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-bold text-amber-300 block">
                        Abonnement Vendeur Premium requis ({premiumPriceUsd} USD / trimestre)
                      </span>
                      <p className="text-[11px] text-slate-300 mt-0.5">
                        Selon le règlement NgoluMarket (Section 7 & 8), la mise aux enchères est réservée aux vendeurs Premium. Activez votre statut maintenant :
                      </p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2">
                  <select
                    value={premiumAggregator}
                    onChange={(e) => setPremiumAggregator(e.target.value as BankAggregatorId)}
                    className="px-2.5 py-2 rounded-lg bg-slate-800 border border-slate-700 text-amber-300 font-semibold text-xs"
                  >
                    <option value="ngolupay_hub">NgoluPay Hub (Multi-Banques)</option>
                    <option value="rawbank_direct">Rawbank Direct & Illicocash</option>
                    <option value="cinetpay_rdc">CinetPay RDC</option>
                    <option value="flutterwave_africa">Flutterwave Africa</option>
                  </select>
                  <select
                    value={premiumMethod}
                    onChange={(e) => {
                      const m = e.target.value as PaymentMethod;
                      setPremiumMethod(m);
                      setPremiumProvider(
                        m === 'mobile_money'
                          ? 'mpesa'
                          : m === 'card'
                          ? 'visa_mastercard'
                          : 'rawbank_illicocash'
                      );
                    }}
                    className="px-2.5 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white text-xs"
                  >
                    <option value="mobile_money">Mobile Money</option>
                    <option value="card">Carte Bancaire</option>
                    <option value="bank_transfer">Banques RDC</option>
                  </select>
                  <select
                    value={premiumProvider}
                    onChange={(e) => setPremiumProvider(e.target.value as PaymentProvider)}
                    className="px-2.5 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white text-xs"
                  >
                    {premiumMethod === 'mobile_money' && (
                      <>
                        <option value="mpesa">M-Pesa Vodacom</option>
                        <option value="orange_money">Orange Money</option>
                        <option value="airtel_money">Airtel Money</option>
                        <option value="afrimoney">Afrimoney</option>
                      </>
                    )}
                    {premiumMethod === 'card' && (
                      <option value="visa_mastercard">Visa / Mastercard</option>
                    )}
                    {premiumMethod === 'bank_transfer' && (
                      <>
                        <option value="rawbank_illicocash">Rawbank Illicocash / RTGS</option>
                        <option value="rawbank_virement">Rawbank RIB (05100-...-44)</option>
                        <option value="equity_bcdc">Equity BCDC</option>
                        <option value="ecobank">Ecobank RDC</option>
                        <option value="tmb_pepele">TMB Pepele</option>
                        <option value="fbnbank_rdc">FBNBank DRC</option>
                        <option value="sofibanque">Sofibanque RDC</option>
                        <option value="access_bank_rdc">Access Bank RDC</option>
                      </>
                    )}
                  </select>
                  <input
                    type="text"
                    value={premiumPhone}
                    onChange={(e) => setPremiumPhone(e.target.value)}
                    placeholder={
                      premiumMethod === 'mobile_money'
                        ? '+243 81...'
                        : 'Réf. carte / RIB'
                    }
                    className="px-2.5 py-2 rounded-lg bg-slate-800 border border-slate-700 text-white font-mono text-xs"
                  />
                  <button
                    type="button"
                    disabled={isActivatingPremium}
                    onClick={handleActivatePremiumInline}
                    className="px-3 py-2 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold rounded-lg transition-colors text-xs cursor-pointer"
                  >
                    {isActivatingPremium ? 'Activation...' : `Activer Premium (${premiumPriceUsd}$)`}
                  </button>
                </div>
              </div>
            )}

            {premiumSuccess && (
              <div className="mt-3 p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs flex items-center gap-2 font-semibold">
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{premiumSuccess}</span>
              </div>
            )}
          </div>

          {/* 2. Category Selection (All 9 Categories) */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-[#0B1F3A] mb-2">
              2. Catégorie de produit ({availableCategories.length} disponibles)
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
              {availableCategories.map((cat) => {
                const meta = CATEGORY_METADATA[cat];
                const IconComp = meta.icon;
                const isSelected = category === cat;
                return (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => handleSelectCategory(cat)}
                    className={`p-3 rounded-xl border text-left transition-all flex flex-col gap-1 ${
                      isSelected
                        ? 'border-[#0B1F3A] bg-blue-50/60 text-slate-900 ring-1 ring-[#0B1F3A]'
                        : 'border-slate-200 hover:border-slate-300 text-slate-600'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <IconComp className={`w-4 h-4 ${isSelected ? 'text-[#0B1F3A]' : 'text-amber-600'}`} />
                      <span className="text-xs font-bold">{getCategoryLabel(cat, language)}</span>
                    </div>
                    <span className="text-[10px] text-slate-500">{meta.subtitle}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* 3. General Info */}
          <div className="space-y-4">
            <label className="block text-xs font-bold uppercase tracking-wider text-[#0B1F3A]">
              3. Informations principales
            </label>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Titre de l’annonce *
              </label>
              <input
                type="text"
                required
                placeholder="ex. iPhone 15 Pro Max 256Go / Salon 6 places / Villa à Gombe..."
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#0B1F3A]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Description détaillée & provenance du produit *
              </label>
              <textarea
                rows={3}
                required
                placeholder="Détaillez les caractéristiques, l’état, les accessoires inclus et les modalités de remise à Kinshasa."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#0B1F3A]"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Commune de Kinshasa *
                </label>
                <select
                  value={commune}
                  onChange={(e) => setCommune(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#0B1F3A] bg-white"
                >
                  <option value="Gombe">Gombe</option>
                  <option value="Ngaliema">Ngaliema (Macampagne, Binza)</option>
                  <option value="Limete">Limete (Résidentiel / Industriel)</option>
                  <option value="Kintambo">Kintambo</option>
                  <option value="Mont-Ngafula">Mont-Ngafula</option>
                  <option value="Bandalungwa">Bandalungwa</option>
                  <option value="Barumbu">Barumbu</option>
                  <option value="Lingwala">Lingwala</option>
                  <option value="Lemba">Lemba</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Quartier / Repère
                </label>
                <input
                  type="text"
                  placeholder="ex. Quartier du Golf, Boulevard du 30 Juin"
                  value={neighborhood}
                  onChange={(e) => setNeighborhood(e.target.value)}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#0B1F3A]"
                />
              </div>
            </div>
          </div>

          {/* 4. Category Specific Details */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-4">
            <span className="text-xs font-bold text-[#0B1F3A] uppercase tracking-wide block">
              4. Détails techniques ({getCategoryLabel(category, language)})
            </span>

            {category === 'immobilier' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Type de bien</label>
                  <select
                    value={propertyType}
                    onChange={(e) => setPropertyType(e.target.value as any)}
                    className="w-full p-2 border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="Villa">Villa</option>
                    <option value="Appartement">Appartement</option>
                    <option value="Duplex">Duplex / Penthouse</option>
                    <option value="Terrain">Terrain viabilisé</option>
                    <option value="Immeuble commercial">Immeuble de rapport</option>
                  </select>
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">Superficie (m²)</label>
                  <input
                    type="number"
                    value={surfaceM2}
                    onChange={(e) => setSurfaceM2(Number(e.target.value))}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  />
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">Titre de propriété foncier</label>
                  <select
                    value={landTitleType}
                    onChange={(e) => setLandTitleType(e.target.value as any)}
                    className="w-full p-2 border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="Certificat d’enregistrement">Certificat d’enregistrement</option>
                    <option value="Contrat de concession perpétuelle">Contrat de concession perpétuelle</option>
                    <option value="Livret de logeur">Livret de logeur</option>
                  </select>
                </div>

                <div>
                  <label className="block font-medium text-slate-700 mb-1">Numéro du volume & folio</label>
                  <input
                    type="text"
                    value={titleNumber}
                    onChange={(e) => setTitleNumber(e.target.value)}
                    placeholder="VOL. XX FOLIO YY"
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  />
                </div>
              </div>
            )}

            {category === 'automobile' && (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Marque</label>
                  <input
                    type="text"
                    value={brand}
                    onChange={(e) => setBrand(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Modèle</label>
                  <input
                    type="text"
                    value={model}
                    onChange={(e) => setModel(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Année</label>
                  <input
                    type="number"
                    value={year}
                    onChange={(e) => setYear(Number(e.target.value))}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Kilométrage (km)</label>
                  <input
                    type="number"
                    value={mileageKm}
                    onChange={(e) => setMileageKm(Number(e.target.value))}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Transmission</label>
                  <select
                    value={transmission}
                    onChange={(e) => setTransmission(e.target.value as any)}
                    className="w-full p-2 border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="Automatique">Automatique</option>
                    <option value="Manuelle">Manuelle</option>
                  </select>
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Carburant</label>
                  <select
                    value={fuel}
                    onChange={(e) => setFuel(e.target.value as any)}
                    className="w-full p-2 border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="Diesel">Diesel</option>
                    <option value="Essence">Essence</option>
                    <option value="Hybride">Hybride</option>
                  </select>
                </div>
              </div>
            )}

            {category === 'mode' && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Marque / Manufacture</label>
                  <input
                    type="text"
                    value={modeBrand}
                    onChange={(e) => setModeBrand(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Modèle / Référence</label>
                  <input
                    type="text"
                    value={modeModel}
                    onChange={(e) => setModeModel(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  />
                </div>
              </div>
            )}

            {!['immobilier', 'automobile', 'mode'].includes(category) && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Type de produit</label>
                  <input
                    type="text"
                    placeholder={`ex. ${getCategoryLabel(category, language)}`}
                    value={productType}
                    onChange={(e) => setProductType(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Marque & Modèle</label>
                  <input
                    type="text"
                    placeholder="ex. Samsung, Apple, Nike, L'Oréal..."
                    value={productBrand}
                    onChange={(e) => setProductBrand(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">État du produit</label>
                  <select
                    value={productCondition}
                    onChange={(e) => setProductCondition(e.target.value as any)}
                    className="w-full p-2 border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="Neuf scellé">Neuf scellé</option>
                    <option value="Neuf">Neuf</option>
                    <option value="Très bon état">Très bon état</option>
                    <option value="Bon état">Bon état</option>
                  </select>
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Garantie / Livraison</label>
                  <input
                    type="text"
                    value={productWarranty}
                    onChange={(e) => setProductWarranty(e.target.value)}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  />
                </div>
              </div>
            )}
          </div>

          {/* 5. Financials & Commercial Preview */}
          <div className="space-y-4">
            <label className="block text-xs font-bold uppercase tracking-wider text-[#0B1F3A]">
              5. Paramètres financiers & {saleType === 'prix_fixe' ? 'Disponibilité' : 'Durée de l’enchère'}
            </label>

            <div className={`grid grid-cols-1 ${saleType === 'prix_fixe' ? 'sm:grid-cols-2' : 'sm:grid-cols-3'} gap-4`}>
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  {saleType === 'prix_fixe' ? 'Prix de vente ferme (USD) *' : 'Prix de départ (USD) *'}
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2 text-slate-400 font-mono text-sm">$</span>
                  <input
                    type="number"
                    min={1}
                    step={1}
                    value={startPrice}
                    onChange={(e) => setStartPrice(Number(e.target.value))}
                    className="w-full pl-7 pr-3 py-2 text-sm font-mono font-bold border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#0B1F3A]"
                  />
                </div>
              </div>

              {saleType === 'enchere' && (
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Augmentation minimale (USD)
                  </label>
                  <input
                    type="number"
                    min={1}
                    step={5}
                    value={minBidStep}
                    onChange={(e) => setMinBidStep(Number(e.target.value))}
                    className="w-full px-3 py-2 text-sm font-mono border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#0B1F3A]"
                  />
                </div>
              )}

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  {saleType === 'prix_fixe' ? 'Durée de mise en vente' : 'Durée de l’enchère'}
                </label>
                <select
                  value={durationDays}
                  onChange={(e) => setDurationDays(Number(e.target.value))}
                  className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white focus:outline-none focus:ring-1 focus:ring-[#0B1F3A]"
                >
                  <option value={1}>1 jour (Vente Flash)</option>
                  <option value={3}>3 jours (Standard)</option>
                  <option value={7}>7 jours (Prestige)</option>
                  <option value={14}>14 jours (Immobilier d’envergure)</option>
                  <option value={30}>30 jours (Catalogue permanent)</option>
                </select>
              </div>
            </div>

            {/* Optional Sponsored Product Toggle (Section 9: 1 USD / produit) */}
            <label className="flex items-center justify-between p-3 bg-amber-50/70 border border-amber-200 rounded-xl cursor-pointer text-xs">
              <div className="flex items-center gap-2.5">
                <input
                  type="checkbox"
                  checked={sponsorOnPublish}
                  onChange={(e) => setSponsorOnPublish(e.target.checked)}
                  className="w-4 h-4 rounded text-[#0B1F3A]"
                />
                <div>
                  <span className="font-bold text-slate-900 block">
                    Sponsoriser ce produit en tête du catalogue (+{sponsoredPriceUsd} USD)
                  </span>
                  <span className="text-[11px] text-slate-600">
                    Option Publicité NgoluMarket (Section 9) : mise en avant prioritaire immédiate.
                  </span>
                </div>
              </div>
              <span className="font-mono font-bold text-amber-800 bg-amber-200/70 px-2 py-0.5 rounded">
                +{sponsoredPriceUsd} USD
              </span>
            </label>

            {/* 6. Asset Verification Documents (PDF / JPG) */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3 text-xs">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <span className="font-bold text-[#0B1F3A] uppercase tracking-wide flex items-center gap-1.5">
                    <FileCheck className="w-4 h-4 text-amber-600" />
                    6. Documents de vérification de l’actif (PDF / JPG)
                  </span>
                  <p className="text-[11px] text-slate-600 mt-0.5">
                    Joignez vos justificatifs (titre foncier, carte rose, facture, certificat). Un administrateur doit valider les documents (<strong>Verified</strong>) avant la publication.
                  </p>
                </div>
                <span className="text-[10px] font-mono font-bold bg-amber-100 text-amber-900 px-2 py-0.5 rounded border border-amber-300 self-start sm:self-auto shrink-0">
                  {assetDocuments.length} fichier(s)
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-12 gap-2">
                <input
                  type="text"
                  value={docLabel}
                  onChange={(e) => setDocLabel(e.target.value)}
                  placeholder="Libellé du document (ex: Certificat d’enregistrement)"
                  className="sm:col-span-7 px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs"
                />
                <button
                  type="button"
                  onClick={() => assetDocInputRef.current?.click()}
                  className="sm:col-span-5 px-3 py-2 bg-[#0B1F3A] hover:bg-[#14325C] text-white font-bold rounded-lg text-xs flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Upload className="w-3.5 h-3.5 text-amber-400" />
                  Importer PDF / JPG
                </button>
                <input
                  ref={assetDocInputRef}
                  type="file"
                  multiple
                  accept=".pdf,.jpg,.jpeg,application/pdf,image/jpeg"
                  onChange={handleAssetDocsUpload}
                  className="hidden"
                />
              </div>

              {assetDocuments.length > 0 && (
                <div className="space-y-2 pt-1">
                  {assetDocuments.map((doc) => (
                    <div
                      key={doc.id}
                      className="p-2.5 bg-white border border-slate-200 rounded-lg flex items-center justify-between gap-2"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        {doc.fileType === 'application/pdf' ? (
                          <div className="w-9 h-9 rounded bg-rose-50 border border-rose-200 flex items-center justify-center text-rose-700 font-bold text-[10px] shrink-0">
                            PDF
                          </div>
                        ) : (
                          <img
                            src={doc.fileUrl}
                            alt={doc.fileName}
                            className="w-9 h-9 rounded object-cover border border-slate-200 shrink-0"
                          />
                        )}
                        <div className="min-w-0">
                          <div className="font-bold text-slate-900 truncate">{doc.name}</div>
                          <div className="text-[10px] font-mono text-slate-500 truncate flex items-center gap-1">
                            <FileText className="w-3 h-3 shrink-0" />
                            {doc.fileName} · {doc.fileSize}
                          </div>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => removeAssetDoc(doc.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 rounded cursor-pointer shrink-0"
                        title="Retirer le document"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-lg text-[11px] text-amber-900 flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                <span>
                  À la soumission, le statut <strong>Document Verification</strong> sera défini sur <strong>Pending</strong> jusqu’à approbation par un administrateur NgoluMarket.
                </span>
              </div>
            </div>

            {/* Financial Simulation Card */}
            <div className="bg-[#0B1F3A] text-white rounded-xl p-4 text-xs space-y-2 border border-[#163254]">
              <div className="flex items-center gap-2 font-bold text-amber-400 uppercase tracking-wide text-[11px]">
                <Calculator className="w-4 h-4" />
                Décompte Commercial NgoluMarket ({saleType === 'prix_fixe' ? 'Prix Fixe' : 'Enchères'})
              </div>

              {saleType === 'prix_fixe' ? (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 border-t border-slate-700 font-mono">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Prix du produit</span>
                    <span className="text-white font-bold">{formatUsd(startPrice)}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Frais vendeur</span>
                    <span className="text-emerald-400 font-bold">0 USD (Gratuit)</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Frais acheteur NgoluMarket</span>
                    <span className="text-amber-300 font-bold">+{buyerFeeUsd} USD</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Total payé par acheteur</span>
                    <span className="text-emerald-400 font-bold">{formatUsd(startPrice + buyerFeeUsd)}</span>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 border-t border-slate-700 font-mono">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Prix adjugé estimé</span>
                    <span className="text-white font-bold">{formatUsd(startPrice)}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Commission ({settings.commissionRatePercent}%)</span>
                    <span className="text-amber-400 font-bold">-{formatUsd(projectedCommission)}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Participation acheteurs</span>
                    <span className="text-emerald-400 font-bold">Gratuite</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Net vendeur estimé</span>
                    <span className="text-emerald-400 font-bold">{formatUsd(projectedNet)}</span>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Action buttons */}
          <div className="pt-4 border-t border-slate-200 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 rounded-lg transition-colors"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-bold rounded-lg transition-colors shadow-sm flex items-center gap-1.5"
            >
              {saleType === 'prix_fixe' ? (
                <>
                  <ShoppingBag className="w-4 h-4" />
                  <span>Soumettre pour vérification (Prix fixe)</span>
                </>
              ) : (
                <>
                  <Gavel className="w-4 h-4" />
                  <span>Soumettre l’enchère pour vérification</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
