import React, { useState } from 'react';
import {
  AlertCircle,
  BarChart3,
  Check,
  CheckCircle2,
  Clock,
  DollarSign,
  ExternalLink,
  FileCheck,
  FileText,
  Megaphone,
  Network,
  Pause,
  Play,
  Save,
  Shield,
  ShieldCheck,
  Sliders,
  Users,
  X,
} from 'lucide-react';
import { useAuctia } from '../context/AuctiaContext';
import {
  AuctionItem,
  DocumentVerificationStatus,
  FinancialSettlement,
  OrderStatus,
  SellerProfile,
} from '../types';
import {
  ALL_CATEGORIES,
  formatUsd,
  getCategoryLabel,
  getStatusLabel,
} from '../utils/formatters';
import { AdminAnalyticsPanel } from './AdminAnalyticsPanel';

interface AdminDashboardProps {
  onSelectAuction: (item: AuctionItem) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onSelectAuction }) => {
  const {
    currentUser,
    auctions,
    users,
    sellerProfiles,
    buyerVerifications,
    payments,
    aggregatorGateways,
    connectedBanks,
    toggleAggregatorGateway,
    settlements,
    auditLogs,
    settings,
    approveAuction,
    rejectAuction,
    suspendAuction,
    resumeAuction,
    closeAuction,
    updateSettings,
    verifySeller,
    adminReviewBuyerVerification,
    updateAssetDocumentVerification,
    updateSettlementStatus,
    adCampaigns,
    reviewAdCampaign,
    updateOrderStatus,
    toggleCategoryEnabled,
    language,
  } = useAuctia();

  const [activeTab, setActiveTab] = useState<
    | 'analytics'
    | 'doc_verification'
    | 'moderation'
    | 'sellers'
    | 'buyers'
    | 'auctions'
    | 'ads'
    | 'settings'
    | 'finances'
    | 'audit'
  >('analytics');

  // Moderation state
  const [rejectModalAuction, setRejectModalAuction] = useState<AuctionItem | null>(null);
  const [rejectionReason, setRejectionReason] = useState(
    'Documents de propriété incomplets ou manquants au cadastre de Kinshasa.'
  );
  const [moderationError, setModerationError] = useState<string | null>(null);

  // Document Verification module state
  const [docVerificationFilter, setDocVerificationFilter] = useState<
    'all' | DocumentVerificationStatus
  >('all');
  const [docReviewNotes, setDocReviewNotes] = useState<Record<string, string>>({});

  // Settings editable state
  const [tempSettings, setTempSettings] = useState(settings);
  const [settingsSaved, setSettingsSaved] = useState(false);

  // Seller verification filter & document review decisions
  const [sellerStatusFilter, setSellerStatusFilter] = useState<'all' | 'pending' | 'verified' | 'rejected'>('all');
  const [reviewingSeller, setReviewingSeller] = useState<SellerProfile | null>(null);
  const [sellerNotes, setSellerNotes] = useState('Dossier notarié et fiscal certifié conforme.');
  const [docDecisions, setDocDecisions] = useState<Record<string, 'verified' | 'rejected'>>({});

  const pendingAuctions = auctions.filter((a) => a.status === 'en_attente');
  const activeAuctions = auctions.filter((a) => a.status === 'en_cours');
  const pendingDocVerificationCount = auctions.filter(
    (a) => (a.documentVerificationStatus || 'pending') === 'pending'
  ).length;
  const filteredDocAuctions = auctions.filter((a) => {
    const docStatus: DocumentVerificationStatus = a.documentVerificationStatus || 'pending';
    return docVerificationFilter === 'all' ? true : docStatus === docVerificationFilter;
  });
  const pendingSellersCount = sellerProfiles.filter((p) => p.verificationStatus === 'pending').length;
  const filteredSellerProfiles = sellerProfiles.filter((p) =>
    sellerStatusFilter === 'all' ? true : p.verificationStatus === sellerStatusFilter
  );

  const totalVolumeAdjugated = settlements.reduce((acc, s) => acc + s.winningBid, 0);
  const totalAuctiaCommissions = settlements.reduce((acc, s) => acc + s.commissionAmount, 0);
  const totalFixedFeesCollected = settlements.reduce(
    (acc, s) => acc + (s.buyerFeeUsd ?? s.fixedFee ?? 0),
    0
  );
  const totalSubscriptionAndAdRevenue = payments
    .filter(
      (p) =>
        p.status === 'completed' &&
        (p.purpose === 'premium_subscription' || p.purpose === 'ad_promotion')
    )
    .reduce((acc, p) => acc + p.amountUsd, 0);

  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings(tempSettings);
    setSettingsSaved(true);
    setTimeout(() => setSettingsSaved(false), 3000);
  };

  const openSellerReview = (profile: SellerProfile) => {
    setReviewingSeller(profile);
    setSellerNotes(
      profile.verificationNotes || 'Dossier examiné par l’équipe conformité NgoluMarket.'
    );
    const initialDecisions: Record<string, 'verified' | 'rejected'> = {};
    (profile.documents || []).forEach((doc) => {
      initialDecisions[doc.id] = doc.status === 'rejected' ? 'rejected' : 'verified';
    });
    setDocDecisions(initialDecisions);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-slate-200 gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold text-slate-900">
              Espace Administration & Modération NgoluMarket
            </h1>
            <span className="text-xs text-amber-800 bg-amber-100 px-2.5 py-0.5 rounded font-semibold border border-amber-300">
              Superviseur Kinshasa
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Contrôle d’intégrité des offres, validation des dossiers notariés et paramétrage économique.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs">
          <span className="text-slate-500">Connecté en tant que :</span>
          <span className="font-bold text-slate-900">{currentUser?.name}</span>
        </div>
      </div>

      {/* KPI Platform Overview */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <span className="text-xs text-slate-500 block">Annonces à valider</span>
          <span className="text-2xl font-bold text-amber-600 font-mono tabular-nums">
            {pendingAuctions.length}
          </span>
          <span className="text-[11px] text-slate-400 block mt-1">Nécessite approbation</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <span className="text-xs text-slate-500 block">Enchères en direct</span>
          <span className="text-2xl font-bold text-emerald-600 font-mono tabular-nums">
            {activeAuctions.length}
          </span>
          <span className="text-[11px] text-slate-400 block mt-1">Kinshasa en temps réel</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <span className="text-xs text-slate-500 block">Volume Adjugé (GMV)</span>
          <span className="text-2xl font-bold text-slate-900 font-mono tabular-nums">
            {formatUsd(totalVolumeAdjugated)}
          </span>
          <span className="text-[11px] text-slate-400 block mt-1">Transactions conclues</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <span className="text-xs text-slate-500 block">Revenus NgoluMarket (Total)</span>
          <span className="text-2xl font-bold text-amber-600 font-mono tabular-nums">
            {formatUsd(
              totalAuctiaCommissions + totalFixedFeesCollected + totalSubscriptionAndAdRevenue
            )}
          </span>
          <span className="text-[11px] text-slate-400 block mt-1 font-mono tabular-nums">
            Comm. : {formatUsd(totalAuctiaCommissions)} · Frais & Abo :{' '}
            {formatUsd(totalFixedFeesCollected + totalSubscriptionAndAdRevenue)}
          </span>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="flex border-b border-slate-200 overflow-x-auto text-xs font-semibold gap-1">
        <button
          type="button"
          onClick={() => setActiveTab('analytics')}
          className={`py-3 px-4 border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'analytics'
              ? 'border-[#0B1F3A] text-[#0B1F3A]'
              : 'border-transparent text-slate-500 hover:text-[#0B1F3A]'
          }`}
        >
          <BarChart3 className="w-4 h-4 text-[#0B1F3A]" />
          Analytiques & KPIs
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('doc_verification')}
          className={`py-3 px-4 border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'doc_verification'
              ? 'border-[#0B1F3A] text-[#0B1F3A]'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <FileText className="w-4 h-4 text-emerald-600" />
          Vérification Documents ({pendingDocVerificationCount})
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('moderation')}
          className={`py-3 px-4 border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'moderation'
              ? 'border-[#0B1F3A] text-[#0B1F3A]'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <FileCheck className="w-4 h-4 text-amber-500" />
          Validation des Annonces ({pendingAuctions.length})
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('sellers')}
          className={`py-3 px-4 border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 cursor-pointer ${
            activeTab === 'sellers'
              ? 'border-[#0B1F3A] text-[#0B1F3A]'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Users className="w-4 h-4 text-blue-500" />
          Vendeurs Professionnels ({sellerProfiles.length}
          {pendingSellersCount > 0 ? ` · ${pendingSellersCount} en attente` : ''})
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('buyers')}
          className={`py-3 px-4 border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'buyers'
              ? 'border-slate-900 text-slate-900'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <ShieldCheck className="w-4 h-4 text-indigo-500" />
          KYC Acheteurs ({buyerVerifications.length})
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('auctions')}
          className={`py-3 px-4 border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'auctions'
              ? 'border-slate-900 text-slate-900'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Shield className="w-4 h-4 text-emerald-500" />
          Contrôle des Enchères ({auctions.length})
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('ads')}
          className={`py-3 px-4 border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'ads'
              ? 'border-[#0B1F3A] text-[#0B1F3A]'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Megaphone className="w-4 h-4 text-amber-500" />
          Publicités & Premium ({adCampaigns.length})
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('settings')}
          className={`py-3 px-4 border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'settings'
              ? 'border-[#0B1F3A] text-[#0B1F3A]'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Sliders className="w-4 h-4 text-purple-500" />
          Tarifs, Catégories & Règles
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('finances')}
          className={`py-3 px-4 border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'finances'
              ? 'border-slate-900 text-slate-900'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <DollarSign className="w-4 h-4 text-emerald-500" />
          Transactions & Séquestres ({payments.length + settlements.length})
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('audit')}
          className={`py-3 px-4 border-b-2 transition-colors whitespace-nowrap flex items-center gap-1.5 ${
            activeTab === 'audit'
              ? 'border-slate-900 text-slate-900'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <Clock className="w-4 h-4 text-slate-500" />
          Journal d’Audit
        </button>
      </div>

      {/* TAB 0: ANALYTICS DASHBOARD WITH DATE RANGE FILTER */}
      {activeTab === 'analytics' && <AdminAnalyticsPanel />}

      {/* TAB: DOCUMENT VERIFICATION MODULE */}
      {activeTab === 'doc_verification' && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-bold text-[#0B1F3A] flex items-center gap-2">
                <FileText className="w-5 h-5 text-emerald-600" />
                Document Verification — Pièces justificatives des actifs (PDF / JPG)
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Inspectez les fichiers PDF/JPG joints par chaque vendeur et basculez le statut Document Verification
                (Pending, Verified, Rejected). Seuls les actifs avec le statut <strong>Verified</strong> peuvent être publiés.
              </p>
            </div>

            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs">
              {(
                [
                  { id: 'all', label: 'Tous' },
                  { id: 'pending', label: 'Pending' },
                  { id: 'verified', label: 'Verified' },
                  { id: 'rejected', label: 'Rejected' },
                ] as const
              ).map((f) => (
                <button
                  key={f.id}
                  type="button"
                  onClick={() => setDocVerificationFilter(f.id)}
                  className={`px-3 py-1.5 rounded-md font-semibold cursor-pointer transition-colors ${
                    docVerificationFilter === f.id
                      ? 'bg-[#0B1F3A] text-white'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          {moderationError && (
            <div className="p-3 rounded-lg border border-rose-200 bg-rose-50 text-rose-800 text-xs font-semibold flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{moderationError}</span>
            </div>
          )}

          {filteredDocAuctions.length === 0 ? (
            <div className="text-center py-12 text-xs text-slate-500 border border-dashed border-slate-200 rounded-xl">
              Aucun dossier documentaire d’actif correspondant à ce filtre pour le moment.
            </div>
          ) : (
            <div className="space-y-4">
              {filteredDocAuctions.map((item) => {
                const docStatus: DocumentVerificationStatus = item.documentVerificationStatus || 'pending';
                const docs = item.assetDocuments || [];
                const noteValue =
                  docReviewNotes[item.id] ?? item.documentVerificationNotes ?? '';
                const pubStatusInfo = getStatusLabel(item.status, language);

                return (
                  <div
                    key={item.id}
                    className="p-5 border border-slate-200 rounded-xl bg-slate-50/50 space-y-4"
                  >
                    <div className="flex flex-col lg:flex-row lg:items-start justify-between gap-4">
                      <div className="flex items-start gap-4">
                        <img
                          src={item.images[0]}
                          alt={item.title}
                          referrerPolicy="no-referrer"
                          className="w-20 h-16 object-cover rounded-lg border border-slate-200 shrink-0"
                        />
                        <div className="space-y-1">
                          <div className="flex flex-wrap items-center gap-2 text-xs">
                            <span className="font-bold text-slate-700 uppercase">
                              {getCategoryLabel(item.category, language)}
                            </span>
                            <span>·</span>
                            <span className={`font-semibold ${pubStatusInfo.textClass}`}>
                              Publication : {pubStatusInfo.label}
                            </span>
                            <span
                              className={`px-2 py-0.5 rounded border text-[11px] font-bold ${
                                docStatus === 'verified'
                                  ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                                  : docStatus === 'rejected'
                                  ? 'bg-rose-50 text-rose-800 border-rose-200'
                                  : 'bg-amber-50 text-amber-800 border-amber-200'
                              }`}
                            >
                              Document Verification :{' '}
                              {docStatus === 'verified'
                                ? 'Verified'
                                : docStatus === 'rejected'
                                ? 'Rejected'
                                : 'Pending'}
                            </span>
                          </div>
                          <h3 className="text-sm font-bold text-slate-900">{item.title}</h3>
                          <div className="text-xs text-slate-500 font-mono">
                            Vendeur : <strong>{item.sellerName}</strong> · Prix :{' '}
                            <strong>{formatUsd(item.fixedPrice || item.currentPrice)}</strong> ·{' '}
                            {docs.length} fichier(s) PDF/JPG
                          </div>
                        </div>
                      </div>

                      {/* 3-State Status Toggle: Pending | Verified | Rejected */}
                      <div className="flex flex-col sm:items-end gap-2 shrink-0">
                        <span className="text-[11px] font-bold uppercase tracking-wide text-slate-500">
                          Document Verification Toggle
                        </span>
                        <div className="inline-flex rounded-lg border border-slate-300 bg-white p-1 gap-1">
                          {(
                            [
                              {
                                value: 'pending',
                                label: 'Pending',
                                activeClass: 'bg-amber-500 text-white shadow-sm',
                              },
                              {
                                value: 'verified',
                                label: 'Verified',
                                activeClass: 'bg-emerald-600 text-white shadow-sm',
                              },
                              {
                                value: 'rejected',
                                label: 'Rejected',
                                activeClass: 'bg-rose-600 text-white shadow-sm',
                              },
                            ] as const
                          ).map((opt) => (
                            <button
                              key={opt.value}
                              type="button"
                              onClick={async () => {
                                setModerationError(null);
                                await updateAssetDocumentVerification(
                                  item.id,
                                  opt.value,
                                  noteValue || undefined,
                                  false
                                );
                              }}
                              className={`px-3 py-1.5 rounded-md text-xs font-bold transition-colors cursor-pointer ${
                                docStatus === opt.value
                                  ? opt.activeClass
                                  : 'text-slate-600 hover:bg-slate-100'
                              }`}
                            >
                              {opt.label}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Uploaded Verification Files (PDF / JPG) */}
                    <div className="space-y-2">
                      <div className="text-xs font-bold text-slate-700">
                        Fichiers de vérification soumis ({docs.length})
                      </div>
                      {docs.length === 0 ? (
                        <div className="p-3 rounded-lg border border-dashed border-slate-300 bg-white text-xs text-slate-500">
                          Aucun fichier PDF/JPG n’a encore été transmis par le vendeur pour cet actif.
                        </div>
                      ) : (
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          {docs.map((doc) => {
                            const isImage =
                              doc.fileType?.startsWith('image/') ||
                              doc.fileUrl?.startsWith('data:image/') ||
                              /\.(jpe?g)$/i.test(doc.fileName);

                            return (
                              <div
                                key={doc.id}
                                className="p-3 bg-white border border-slate-200 rounded-lg space-y-2"
                              >
                                <div className="flex items-center justify-between gap-2">
                                  <div className="flex items-center gap-2 min-w-0">
                                    <FileText className="w-4 h-4 text-[#0B1F3A] shrink-0" />
                                    <div className="min-w-0">
                                      <div className="text-xs font-bold text-slate-900 truncate">
                                        {doc.fileName}
                                      </div>
                                      <div className="text-[10px] text-slate-500">
                                        {doc.fileType || 'Document'} · {doc.fileSize || 'Fichier'}
                                      </div>
                                    </div>
                                  </div>
                                  {doc.fileUrl && (
                                    <a
                                      href={doc.fileUrl}
                                      target="_blank"
                                      rel="noopener noreferrer"
                                      download={doc.fileName}
                                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 text-[11px] font-semibold text-[#0B1F3A] shrink-0"
                                    >
                                      Ouvrir
                                      <ExternalLink className="w-3 h-3" />
                                    </a>
                                  )}
                                </div>
                                {isImage && doc.fileUrl && (
                                  <img
                                    src={doc.fileUrl}
                                    alt={doc.fileName}
                                    className="max-h-36 w-full object-contain rounded border border-slate-200 bg-slate-50"
                                  />
                                )}
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>

                    {/* Review Note + Gated Publish Action */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2 border-t border-slate-200">
                      <input
                        type="text"
                        placeholder="Observation administrative (motif de validation ou de rejet)..."
                        value={noteValue}
                        onChange={(e) =>
                          setDocReviewNotes((prev) => ({ ...prev, [item.id]: e.target.value }))
                        }
                        className="flex-1 px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#0B1F3A]"
                      />

                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          type="button"
                          onClick={() => onSelectAuction(item)}
                          className="px-3 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 text-xs font-semibold rounded-lg cursor-pointer"
                        >
                          Détails
                        </button>
                        <button
                          type="button"
                          disabled={docStatus !== 'verified' || item.status === 'en_cours'}
                          onClick={async () => {
                            setModerationError(null);
                            const res = await approveAuction(
                              item.id,
                              noteValue || 'Documents vérifiés conformes par l’équipe NgoluMarket.'
                            );
                            if (!res.success && res.error) {
                              setModerationError(res.error);
                            }
                          }}
                          className={`px-4 py-2 text-xs font-bold rounded-lg flex items-center gap-1.5 transition-colors ${
                            item.status === 'en_cours'
                              ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 cursor-default'
                              : docStatus === 'verified'
                              ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-sm cursor-pointer'
                              : 'bg-slate-200 text-slate-500 cursor-not-allowed'
                          }`}
                        >
                          <Check className="w-4 h-4" />
                          {item.status === 'en_cours'
                            ? 'Enchère publiée'
                            : 'Publier l’enchère'}
                        </button>
                      </div>
                    </div>

                    {docStatus !== 'verified' && item.status !== 'en_cours' && (
                      <p className="text-[11px] text-amber-800 bg-amber-50 border border-amber-200 rounded-lg px-3 py-1.5 font-medium">
                        Publication verrouillée : basculez d’abord <strong>Document Verification</strong> sur{' '}
                        <strong>Verified</strong> avant de pouvoir publier cette annonce.
                      </p>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB 1: MODERATION OF PENDING AUCTIONS */}
      {activeTab === 'moderation' && (
        <div className="space-y-6">
          <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Annonces soumises en attente d’examen
              </h2>
              <p className="text-xs text-slate-500">
                Vérifiez la conformité des titres de propriété (certificat d’enregistrement, carte rose,
                certificat d’authenticité) avant publication publique.
              </p>
            </div>

            {moderationError && (
              <div className="p-3 rounded-lg border border-rose-200 bg-rose-50 text-rose-800 text-xs font-semibold flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{moderationError}</span>
              </div>
            )}

            {pendingAuctions.length === 0 ? (
              <div className="text-center py-12 text-xs text-slate-500">
                <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2 opacity-80" />
                Aucune annonce en attente. Toutes les soumissions ont été traitées !
              </div>
            ) : (
              <div className="space-y-4">
                {pendingAuctions.map((item) => {
                  const docStatus: DocumentVerificationStatus = item.documentVerificationStatus || 'pending';
                  const docsCount = (item.assetDocuments || []).length;

                  return (
                    <div
                      key={item.id}
                      className="p-5 border border-slate-200 rounded-xl bg-slate-50/50 flex flex-col md:flex-row md:items-center justify-between gap-4"
                    >
                      <div className="flex items-start gap-4">
                        <img
                          src={item.images[0]}
                          alt={item.title}
                          referrerPolicy="no-referrer"
                          className="w-24 h-20 object-cover rounded-lg border border-slate-200 shrink-0"
                        />
                        <div className="space-y-1">
                          <div className="flex flex-wrap items-center gap-2 text-xs">
                            <span className="font-bold text-slate-700 uppercase">
                              {getCategoryLabel(item.category, language)}
                            </span>
                            <span>·</span>
                            <span className="text-slate-600 font-medium">
                              {item.location.commune}, Kinshasa
                            </span>
                            <span>·</span>
                            <span className="text-amber-800 font-semibold bg-amber-100 px-2 py-0.5 rounded text-[11px]">
                              En attente de validation
                            </span>
                            <span
                              className={`px-2 py-0.5 rounded border text-[11px] font-bold ${
                                docStatus === 'verified'
                                  ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                                  : docStatus === 'rejected'
                                  ? 'bg-rose-50 text-rose-800 border-rose-200'
                                  : 'bg-amber-50 text-amber-800 border-amber-200'
                              }`}
                            >
                              Doc : {docStatus === 'verified' ? 'Verified' : docStatus === 'rejected' ? 'Rejected' : 'Pending'} ({docsCount})
                            </span>
                          </div>
                          <h3 className="text-sm font-bold text-slate-900">{item.title}</h3>
                          <p className="text-xs text-slate-600 line-clamp-2 max-w-xl">
                            {item.description}
                          </p>
                          <div className="text-xs text-slate-500 font-mono pt-1">
                            Vendeur : <strong>{item.sellerName}</strong> · Prix de départ :{' '}
                            <strong>{formatUsd(item.startPrice)}</strong> (Pas min: {item.minBidStep} $)
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-row flex-wrap md:flex-col gap-2 shrink-0 justify-end">
                        <button
                          type="button"
                          disabled={docStatus !== 'verified'}
                          title={
                            docStatus !== 'verified'
                              ? 'Basculez Document Verification sur Verified avant publication'
                              : undefined
                          }
                          onClick={async () => {
                            setModerationError(null);
                            const res = await approveAuction(
                              item.id,
                              'Documents vérifiés conformes par l’équipe NgoluMarket.'
                            );
                            if (!res.success && res.error) {
                              setModerationError(res.error);
                            }
                          }}
                          className={`px-4 py-2 font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-1.5 shadow-sm ${
                            docStatus === 'verified'
                              ? 'bg-emerald-600 hover:bg-emerald-500 text-white cursor-pointer'
                              : 'bg-slate-200 text-slate-500 cursor-not-allowed'
                          }`}
                        >
                          <Check className="w-4 h-4" />
                          Approuver et Publier
                        </button>

                        {docStatus !== 'verified' && (
                          <button
                            type="button"
                            onClick={() => setActiveTab('doc_verification')}
                            className="px-4 py-2 bg-[#0B1F3A] hover:bg-[#14325C] text-white font-semibold text-xs rounded-lg transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                          >
                            <FileText className="w-3.5 h-3.5" />
                            Vérifier documents
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => setRejectModalAuction(item)}
                          className="px-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-semibold text-xs rounded-lg transition-colors flex items-center justify-center gap-1.5"
                        >
                          <X className="w-4 h-4" />
                          Refuser l’annonce
                        </button>

                        <button
                          type="button"
                          onClick={() => onSelectAuction(item)}
                          className="px-4 py-2 bg-white hover:bg-slate-100 text-slate-700 border border-slate-200 text-xs rounded-lg transition-colors"
                        >
                          Examiner en détail
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: SELLERS VERIFICATION */}
      {activeTab === 'sellers' && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-bold text-[#0B1F3A]">
                Vérification des Vendeurs & Documents Commerciaux (RDC)
              </h2>
              <p className="text-xs text-slate-500">
                Inspectez les numéros RCCM, Identification Nationale et pièces justificatives soumises avant de certifier les vendeurs.
              </p>
            </div>

            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg text-xs">
              {(
                [
                  { id: 'all', label: `Tous (${sellerProfiles.length})` },
                  { id: 'pending', label: `En attente (${pendingSellersCount})` },
                  {
                    id: 'verified',
                    label: `Certifiés (${sellerProfiles.filter((p) => p.verificationStatus === 'verified').length})`,
                  },
                  {
                    id: 'rejected',
                    label: `Rejetés (${sellerProfiles.filter((p) => p.verificationStatus === 'rejected').length})`,
                  },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setSellerStatusFilter(tab.id)}
                  className={`px-2.5 py-1.5 rounded-md font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                    sellerStatusFilter === tab.id
                      ? 'bg-[#0B1F3A] text-white'
                      : 'text-slate-600 hover:text-[#0B1F3A]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {filteredSellerProfiles.length === 0 ? (
            <div className="text-center py-10 text-xs text-slate-500 border border-dashed border-slate-200 rounded-xl">
              Aucun dossier vendeur dans cette catégorie.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-500 uppercase font-semibold text-[10px] border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-3">Raison Sociale</th>
                    <th className="py-2.5 px-3">RCCM & Id. Nat</th>
                    <th className="py-2.5 px-3">Localisation</th>
                    <th className="py-2.5 px-3">Téléphone & Soumission</th>
                    <th className="py-2.5 px-3">Statut Vérification</th>
                    <th className="py-2.5 px-3">Actions de contrôle</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredSellerProfiles.map((p) => (
                    <tr key={p.userId} className="hover:bg-slate-50">
                      <td className="py-3 px-3 font-semibold text-slate-900">{p.companyName}</td>
                      <td className="py-3 px-3 font-mono text-[11px] text-slate-600">
                        <div>{p.rccmNumber}</div>
                        <div className="text-slate-400">Id.Nat : {p.idNat || 'N/A'}</div>
                      </td>
                      <td className="py-3 px-3 text-slate-600">{p.address}</td>
                      <td className="py-3 px-3 font-mono text-slate-700">
                        <div>{p.phone}</div>
                        <div className="text-[10px] text-slate-400">
                          {p.submittedAt ? new Date(p.submittedAt).toLocaleDateString('fr-FR') : ''}
                        </div>
                      </td>
                      <td className="py-3 px-3">
                        {p.verificationStatus === 'verified' ? (
                          <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 flex items-center gap-1 w-max">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            Certifié
                          </span>
                        ) : p.verificationStatus === 'rejected' ? (
                          <span className="text-[11px] font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200 w-max block">
                            Rejeté
                          </span>
                        ) : (
                          <span className="text-[11px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200 w-max block">
                            En attente ({p.documents?.length || 0} pièces)
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-3">
                        <button
                          type="button"
                          onClick={() => openSellerReview(p)}
                          className="px-3 py-1.5 bg-[#0B1F3A] hover:bg-[#14325C] text-white rounded-lg font-semibold text-[11px] flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                        >
                          <FileCheck className="w-3.5 h-3.5 text-amber-400" />
                          Examiner ({p.documents?.length || 0} docs)
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB: BUYERS KYC VERIFICATION */}
      {activeTab === 'buyers' && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
          <div>
            <h2 className="text-base font-bold text-slate-900">
              Dossiers de Vérification KYC Acheteurs (Kinshasa)
            </h2>
            <p className="text-xs text-slate-500">
              Contrôle d'identité (Passeport, Carte CENI, Permis) et solvabilité bancaire pour déblocage des plafonds d'adjudication supérieurs (supérieur à 5 000 USD jusqu'à 150 000 USD).
            </p>
          </div>

          {buyerVerifications.length === 0 ? (
            <div className="text-center py-12 text-xs text-slate-500 border border-dashed border-slate-200 rounded-xl">
              Aucun dossier KYC acheteur en attente pour le moment.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-500 uppercase font-semibold text-[10px] border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-3">Acheteur</th>
                    <th className="py-2.5 px-3">Téléphone & Réf.</th>
                    <th className="py-2.5 px-3">Pièce d’identité</th>
                    <th className="py-2.5 px-3">Banque & Résidence</th>
                    <th className="py-2.5 px-3">Plafond Enchères</th>
                    <th className="py-2.5 px-3">Statut</th>
                    <th className="py-2.5 px-3">Décision</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {buyerVerifications.map((bv) => (
                    <tr key={bv.userId} className="hover:bg-slate-50">
                      <td className="py-3 px-3 font-semibold text-slate-900">{bv.userName}</td>
                      <td className="py-3 px-3 font-mono text-[11px] text-slate-600">
                        <div>{bv.phone}</div>
                        <div className="text-slate-400">ID: {bv.userId}</div>
                      </td>
                      <td className="py-3 px-3">
                        <span className="font-semibold text-slate-800 uppercase text-[11px] block">
                          {bv.documentType === 'ceni_voter_card'
                            ? 'Carte Électeur CENI'
                            : bv.documentType === 'passport'
                            ? 'Passeport RDC'
                            : 'Permis de conduire'}
                        </span>
                        <span className="font-mono text-slate-500 text-[10px]">
                          N° {bv.documentNumber}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-slate-600">
                        <div className="font-semibold text-slate-800">{bv.bankName || 'Banque RDC'}</div>
                        <div className="text-[10px] text-slate-400">{bv.residenceCommune || 'Kinshasa'}</div>
                      </td>
                      <td className="py-3 px-3 font-mono font-bold text-slate-900">
                        {formatUsd(bv.maxTransactionLimitUsd || 5000)}
                      </td>
                      <td className="py-3 px-3">
                        {bv.status === 'verified' ? (
                          <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 flex items-center gap-1 w-max">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            Agréé
                          </span>
                        ) : bv.status === 'rejected' ? (
                          <span className="text-[11px] font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200 w-max block">
                            Refusé
                          </span>
                        ) : (
                          <span className="text-[11px] font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200 w-max block">
                            En attente
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-3">
                        {bv.status !== 'verified' ? (
                          <div className="flex items-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => adminReviewBuyerVerification(bv.userId, 'approve')}
                              className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[11px] font-semibold"
                            >
                              Approuver
                            </button>
                            <button
                              type="button"
                              onClick={() => adminReviewBuyerVerification(bv.userId, 'reject', 'Pièces non conformes')}
                              className="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded text-[11px] font-semibold"
                            >
                              Refuser
                            </button>
                          </div>
                        ) : (
                          <span className="text-slate-400 text-[11px]">Vérifié</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: AUCTION MANAGEMENT & CONTROLS */}
      {activeTab === 'auctions' && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Gestion opérationnelle des enchères
              </h2>
              <p className="text-xs text-slate-500">
                Actions directes d’urgence : suspendre en cas de contestation, relancer ou clôturer manuellement.
              </p>
            </div>
          </div>

          <div className="divide-y divide-slate-100">
            {auctions.map((item) => {
              const statusInfo = getStatusLabel(item.status);
              return (
                <div key={item.id} className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-3">
                    <img
                      src={item.images[0]}
                      alt={item.title}
                      referrerPolicy="no-referrer"
                      className="w-14 h-12 object-cover rounded-lg border border-slate-200 shrink-0"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-slate-700">{getCategoryLabel(item.category)}</span>
                        <span>·</span>
                        <span className={statusInfo.textClass}>{statusInfo.label}</span>
                      </div>
                      <h4 className="font-semibold text-slate-900">{item.title}</h4>
                      <div className="text-slate-500 font-mono mt-0.5">
                        Prix : {formatUsd(item.currentPrice)} · {item.bidsCount} offres · Vendeur :{' '}
                        {item.sellerName}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-center">
                    {item.status === 'en_cours' ? (
                      <>
                        <button
                          type="button"
                          onClick={() => suspendAuction(item.id, 'Vérification suite à signalement.')}
                          className="px-2.5 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-200 rounded font-medium flex items-center gap-1"
                        >
                          <Pause className="w-3.5 h-3.5" />
                          Suspendre
                        </button>
                        <button
                          type="button"
                          onClick={() => closeAuction(item.id)}
                          className="px-2.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded font-medium"
                        >
                          Clôturer & Adjuger
                        </button>
                      </>
                    ) : item.status === 'suspendue' ? (
                      <button
                        type="button"
                        onClick={() => resumeAuction(item.id)}
                        className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded font-medium flex items-center gap-1"
                      >
                        <Play className="w-3.5 h-3.5" />
                        Réactiver
                      </button>
                    ) : null}

                    <button
                      type="button"
                      onClick={() => onSelectAuction(item)}
                      className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded font-medium"
                    >
                      Voir
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB: PUBLICITES & ABONNEMENTS PREMIUM (Sections 8, 9 & 13) */}
      {activeTab === 'ads' && (
        <div className="space-y-6">
          <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
            <div>
              <h2 className="text-base font-bold text-[#0B1F3A]">
                Gestion des Publicités & Produits Sponsorisés (Section 9 & 13)
              </h2>
              <p className="text-xs text-slate-500">
                Acceptez, refusez ou suspendez les demandes de publicité (1 USD/mois) et produits sponsorisés (1 USD/produit).
              </p>
            </div>

            {adCampaigns.length === 0 ? (
              <div className="text-center py-8 text-xs text-slate-500 border border-dashed border-slate-200 rounded-xl">
                Aucune campagne publicitaire soumise pour le moment.
              </div>
            ) : (
              <div className="divide-y divide-slate-100 text-xs">
                {adCampaigns.map((c) => (
                  <div key={c.id} className="py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-[#0B1F3A]">{c.title}</span>
                        <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-700 font-semibold text-[10px]">
                          {c.type === 'banner_ad' ? 'Publicité 1$/mois' : 'Produit Sponsorisé 1$'}
                        </span>
                        <span
                          className={`px-2 py-0.5 rounded font-bold text-[10px] ${
                            c.status === 'active'
                              ? 'bg-emerald-50 text-emerald-700'
                              : c.status === 'suspended'
                              ? 'bg-amber-50 text-amber-800'
                              : 'bg-rose-50 text-rose-700'
                          }`}
                        >
                          {c.status}
                        </span>
                      </div>
                      <div className="text-slate-500 mt-0.5">
                        Annonceur : {c.userName} · Tarif : {formatUsd(c.amountUsd)} ({c.durationLabel})
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => reviewAdCampaign(c.id, 'active')}
                        className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded font-semibold cursor-pointer"
                      >
                        Accepter
                      </button>
                      <button
                        type="button"
                        onClick={() => reviewAdCampaign(c.id, 'suspended')}
                        className="px-2.5 py-1 bg-amber-100 hover:bg-amber-200 text-amber-900 rounded font-semibold cursor-pointer"
                      >
                        Suspendre
                      </button>
                      <button
                        type="button"
                        onClick={() => reviewAdCampaign(c.id, 'rejected')}
                        className="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded font-semibold cursor-pointer"
                      >
                        Refuser
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Utilisateurs & Administrateurs (Section 13) */}
          <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
            <div>
              <h2 className="text-base font-bold text-[#0B1F3A]">
                Comptes Utilisateurs, Vendeurs Premium & Administrateurs ({users.length})
              </h2>
              <p className="text-xs text-slate-500">
                Vue consolidée des comptes acheteurs/vendeurs, statuts Premium et administrateurs NgoluMarket.
              </p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-500 uppercase font-semibold text-[10px] border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-3">Nom</th>
                    <th className="py-2.5 px-3">Contact</th>
                    <th className="py-2.5 px-3">Rôle</th>
                    <th className="py-2.5 px-3">Abonnement Premium</th>
                    <th className="py-2.5 px-3">Pays / Ville</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {users.map((u) => (
                    <tr key={u.id}>
                      <td className="py-2.5 px-3 font-semibold text-slate-900">{u.name}</td>
                      <td className="py-2.5 px-3 font-mono text-[11px]">{u.phone} {u.email ? `· ${u.email}` : ''}</td>
                      <td className="py-2.5 px-3 uppercase font-bold text-[10px] text-[#0B1F3A]">{u.role}</td>
                      <td className="py-2.5 px-3">
                        {u.isPremium ? (
                          <span className="text-emerald-700 font-bold">Premium Actif</span>
                        ) : (
                          <span className="text-slate-400">Standard</span>
                        )}
                      </td>
                      <td className="py-2.5 px-3 text-slate-600">{u.country || 'RDC'} · {u.city}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: ECONOMIC RULES & CATEGORIES CONFIGURATOR (SECTIONS 6, 7, 8, 9, 10, 13) */}
      {activeTab === 'settings' && (
        <form onSubmit={handleSaveSettings} className="bg-white rounded-xl border border-slate-200 p-6 space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-slate-200">
            <div>
              <h2 className="text-base font-bold text-[#0B1F3A]">
                Configuration des Tarifs, Catégories & Paramètres NgoluMarket
              </h2>
              <p className="text-xs text-slate-500">
                Conformité Fiche Technique v1.0 : modifiez les frais, commissions, abonnements, publicités et catégories actives.
              </p>
            </div>

            {settingsSaved && (
              <span className="text-xs text-emerald-700 bg-emerald-50 px-3 py-1 rounded font-bold border border-emerald-200 flex items-center gap-1">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                Paramètres enregistrés !
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
            {/* Rule 1: Fixed Price Fee (Section 6) */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <span className="font-bold text-[#0B1F3A] block text-sm">
                1. Frais de vente à prix fixe (1 USD par défaut)
              </span>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                Publication gratuite pour le vendeur. Frais fixes payés par l’acheteur sur chaque achat à prix fixe (Section 6).
              </p>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-medium mb-1">Frais acheteur Prix Fixe (USD)</label>
                  <input
                    type="number"
                    min={0}
                    step={0.5}
                    value={tempSettings.fixedPriceBuyerFeeUsd ?? 1}
                    onChange={(e) =>
                      setTempSettings({ ...tempSettings, fixedPriceBuyerFeeUsd: Number(e.target.value) })
                    }
                    className="w-full p-2 border border-slate-300 rounded-lg font-mono font-bold bg-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-medium mb-1">Frais publication vendeur (USD)</label>
                  <input
                    type="number"
                    min={0}
                    value={tempSettings.fixedListingFee}
                    onChange={(e) =>
                      setTempSettings({ ...tempSettings, fixedListingFee: Number(e.target.value) })
                    }
                    className="w-full p-2 border border-slate-300 rounded-lg font-mono font-bold bg-white"
                  />
                </div>
              </div>
            </div>

            {/* Rule 2: Auction Commission Rate (Section 7) */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <span className="font-bold text-[#0B1F3A] block text-sm">
                2. Commission Enchères (5% par défaut)
              </span>
              <p className="text-slate-600 text-[11px] leading-relaxed">
                Payée par le vendeur Premium sur le prix final de l’enchère. Participation acheteur gratuite (Section 7).
              </p>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-medium mb-1">Commission enchères (%)</label>
                  <input
                    type="number"
                    min={0}
                    max={30}
                    step={0.5}
                    value={tempSettings.commissionRatePercent}
                    onChange={(e) =>
                      setTempSettings({
                        ...tempSettings,
                        commissionRatePercent: Number(e.target.value),
                      })
                    }
                    className="w-full p-2 border border-slate-300 rounded-lg font-mono font-bold bg-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-medium mb-1">Abonnement Premium (USD/trim.)</label>
                  <input
                    type="number"
                    min={0}
                    value={tempSettings.premiumSubscriptionPriceUsd ?? 50}
                    onChange={(e) =>
                      setTempSettings({
                        ...tempSettings,
                        premiumSubscriptionPriceUsd: Number(e.target.value),
                      })
                    }
                    className="w-full p-2 border border-slate-300 rounded-lg font-mono font-bold bg-white"
                  />
                </div>
              </div>
            </div>

            {/* Rule 3: Publicité & Produits Sponsorisés (Section 9) */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <span className="font-bold text-[#0B1F3A] block text-sm">
                3. Tarifs Publicité & Sponsoring (Sections 9 & 13)
              </span>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-medium mb-1">Publicité (USD / mois)</label>
                  <input
                    type="number"
                    min={0}
                    step={0.5}
                    value={tempSettings.adMonthlyPriceUsd ?? 1}
                    onChange={(e) =>
                      setTempSettings({ ...tempSettings, adMonthlyPriceUsd: Number(e.target.value) })
                    }
                    className="w-full p-2 border border-slate-300 rounded-lg font-mono font-bold bg-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-medium mb-1">Produit sponsorisé (USD / produit)</label>
                  <input
                    type="number"
                    min={0}
                    step={0.5}
                    value={tempSettings.sponsoredProductPriceUsd ?? 1}
                    onChange={(e) =>
                      setTempSettings({ ...tempSettings, sponsoredProductPriceUsd: Number(e.target.value) })
                    }
                    className="w-full p-2 border border-slate-300 rounded-lg font-mono font-bold bg-white"
                  />
                </div>
              </div>
            </div>

            {/* Rule 4: Taux CDF & Anti-Sniping */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <span className="font-bold text-[#0B1F3A] block text-sm">
                4. Taux de change CDF / USD & Anti-Sniping
              </span>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-medium mb-1">1 USD en CDF</label>
                  <input
                    type="number"
                    min={1000}
                    step={50}
                    value={tempSettings.currencyRateCdf}
                    onChange={(e) =>
                      setTempSettings({ ...tempSettings, currencyRateCdf: Number(e.target.value) })
                    }
                    className="w-full p-2 border border-slate-300 rounded-lg font-mono font-bold bg-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-medium mb-1">Anti-Sniping (minutes)</label>
                  <input
                    type="number"
                    min={1}
                    max={15}
                    value={tempSettings.antiSnipingMinutes}
                    onChange={(e) =>
                      setTempSettings({ ...tempSettings, antiSnipingMinutes: Number(e.target.value) })
                    }
                    className="w-full p-2 border border-slate-300 rounded-lg font-mono bg-white"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Section 10: Catégories configurables depuis l'administration */}
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3 text-xs">
            <span className="font-bold text-[#0B1F3A] block text-sm">
              5. Configuration des Catégories actives (Section 10)
            </span>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
              {ALL_CATEGORIES.map((cat) => {
                const enabled = (settings.enabledCategories || ALL_CATEGORIES).includes(cat);
                return (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => toggleCategoryEnabled(cat)}
                    className={`p-2 rounded-lg border text-left font-semibold transition-colors cursor-pointer flex items-center justify-between ${
                      enabled
                        ? 'bg-[#0B1F3A] text-white border-[#0B1F3A]'
                        : 'bg-white text-slate-500 border-slate-300'
                    }`}
                  >
                    <span className="truncate">{getCategoryLabel(cat, language)}</span>
                    <span className="text-[10px] ml-1">{enabled ? 'ON' : 'OFF'}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-200 flex justify-end">
            <button
              type="submit"
              className="px-5 py-2.5 bg-[#0B1F3A] hover:bg-[#14325C] text-white font-bold text-xs rounded-lg transition-colors flex items-center gap-1.5 shadow-sm cursor-pointer"
            >
              <Save className="w-4 h-4 text-amber-400" />
              Appliquer les modifications
            </button>
          </div>
        </form>
      )}

      {/* TAB 5: FINANCIAL ESCROWS, BANKING AGGREGATOR & SETTLEMENTS */}
      {activeTab === 'finances' && (
        <div className="space-y-6">
          {/* Banking Aggregator & Multi-Bank Hub Monitor */}
          <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
              <div>
                <h2 className="text-base font-bold text-[#0B1F3A] flex items-center gap-2">
                  <Network className="w-5 h-5 text-amber-500" />
                  Agrégateur Bancaire NgoluMarket & Passerelles Connectées ({aggregatorGateways.length})
                </h2>
                <p className="text-xs text-slate-500">
                  Supervision des hubs de compensation interbancaires RDC, Mobile Money et cartes vers le séquestre NGOLUMARKET SAS (Rawbank 05100-01234567890-44).
                </p>
              </div>
              <span className="text-[11px] font-mono font-bold bg-[#0B1F3A] text-amber-300 px-3 py-1.5 rounded-lg self-start sm:self-auto">
                {connectedBanks.length} banques RDC raccordées
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {aggregatorGateways.map((gw) => (
                <div
                  key={gw.id}
                  className={`p-4 rounded-xl border transition-all space-y-3 ${
                    gw.enabled
                      ? 'border-slate-200 bg-slate-50/70'
                      : 'border-rose-200 bg-rose-50/40 opacity-80'
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="text-sm font-bold text-[#0B1F3A]">{gw.name}</h3>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded font-mono ${
                            gw.enabled
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {gw.enabled ? 'EN LIGNE' : 'EN PAUSE'}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-600 mt-0.5">{gw.settlementRail}</p>
                    </div>
                    <button
                      type="button"
                      onClick={() => toggleAggregatorGateway(gw.id)}
                      className={`px-2.5 py-1.5 rounded-lg text-[11px] font-bold cursor-pointer transition-colors shrink-0 ${
                        gw.enabled
                          ? 'bg-amber-100 hover:bg-amber-200 text-amber-900'
                          : 'bg-emerald-600 hover:bg-emerald-500 text-white'
                      }`}
                    >
                      {gw.enabled ? 'Mettre en pause' : 'Réactiver'}
                    </button>
                  </div>

                  <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-200 text-[11px] font-mono">
                    <div>
                      <span className="text-slate-400 block font-sans text-[10px]">Volume routé</span>
                      <span className="font-bold text-[#0B1F3A]">
                        {formatUsd(gw.routedVolumeUsd || 0)}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 block font-sans text-[10px]">Opérations</span>
                      <span className="font-bold text-slate-800">{gw.transactionsCount || 0}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block font-sans text-[10px]">Compensation</span>
                      <span className="font-semibold text-emerald-700">{gw.clearingDelay}</span>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-1.5 pt-1">
                    {gw.connectedBanks.map((bankId) => {
                      const bankInfo = connectedBanks.find((b) => b.id === bankId);
                      return (
                        <span
                          key={bankId}
                          className="text-[10px] font-mono px-2 py-0.5 bg-white border border-slate-200 rounded text-slate-700"
                        >
                          {bankInfo ? `${bankInfo.shortName} (${bankInfo.swiftCode})` : bankId}
                        </span>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>

            {/* Connected DRC Banks Directory Strip */}
            <div className="pt-3 border-t border-slate-200">
              <span className="text-xs font-bold text-[#0B1F3A] block mb-2">
                Répertoire des Banques RDC connectées au Séquestre NgoluMarket
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
                {connectedBanks.map((bank) => (
                  <div
                    key={bank.id}
                    className="p-2.5 bg-slate-50 border border-slate-200 rounded-lg space-y-0.5"
                  >
                    <div className="font-bold text-slate-900 truncate">{bank.shortName}</div>
                    <div className="text-[10px] font-mono text-slate-500">
                      SWIFT: {bank.swiftCode} · BCC {bank.clearingCode}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Registre des Séquestres Bancaires & Règlements
              </h2>
              <p className="text-xs text-slate-500">
                Conformité stricte : distinction du montant du bien, des commissions NgoluMarket et du net dû au
                vendeur.
              </p>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-500 uppercase font-semibold text-[10px] border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-3">Réf. & Enchère</th>
                    <th className="py-2.5 px-3">Adjudication</th>
                    <th className="py-2.5 px-3">Commission NgoluMarket</th>
                    <th className="py-2.5 px-3">Frais fixes</th>
                    <th className="py-2.5 px-3">Net Vendeur</th>
                    <th className="py-2.5 px-3">Statut du séquestre</th>
                    <th className="py-2.5 px-3">Action bancaire</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-mono">
                  {settlements.map((s) => (
                    <tr key={s.id} className="hover:bg-slate-50">
                      <td className="py-3 px-3 font-sans">
                        <div className="font-bold text-slate-900">{s.auctionTitle}</div>
                        <div className="text-[10px] text-slate-400 font-mono">
                          {s.orderNumber || s.id} · {s.saleType === 'prix_fixe' ? 'Prix Fixe' : 'Enchères'}
                        </div>
                      </td>
                      <td className="py-3 px-3 font-bold text-slate-900">{formatUsd(s.winningBid)}</td>
                      <td className="py-3 px-3 text-amber-700 font-bold">
                        +{formatUsd(s.commissionAmount)}
                      </td>
                      <td className="py-3 px-3 text-slate-700">+{s.buyerFeeUsd ?? s.fixedFee} USD</td>
                      <td className="py-3 px-3 text-emerald-700 font-bold">
                        {formatUsd(s.netSellerAmount)}
                      </td>
                      <td className="py-3 px-3 font-sans">
                        <select
                          value={s.orderStatus || 'en_attente_paiement'}
                          onChange={(e) => updateOrderStatus(s.id, e.target.value as OrderStatus)}
                          className="text-[11px] font-semibold px-2 py-1 rounded border border-slate-300 bg-white text-slate-800"
                        >
                          <option value="en_attente_paiement">En attente de paiement</option>
                          <option value="paiement_confirme">Paiement confirmé</option>
                          <option value="commande_acceptee">Commande acceptée</option>
                          <option value="en_preparation">En préparation</option>
                          <option value="expediee">Expédiée / Remise</option>
                          <option value="terminee">Terminée</option>
                          <option value="annulee">Annulée</option>
                          <option value="litige">En litige</option>
                        </select>
                      </td>
                      <td className="py-3 px-3 font-sans">
                        {s.settlementStatus === 'fonds_sequestres' || s.settlementStatus === 'en_attente_paiement' ? (
                          <button
                            type="button"
                            onClick={() => updateSettlementStatus(s.id, 'paye_au_vendeur', 'Ordre de virement émis')}
                            className="px-2 py-1 bg-[#0B1F3A] hover:bg-[#14325C] text-white rounded text-[11px] font-semibold cursor-pointer"
                          >
                            Libérer les fonds
                          </button>
                        ) : (
                          <span className="text-slate-400 text-[11px]">Dossier clôturé</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* REAL API PAYMENT TRANSACTIONS SECTION */}
            <div className="pt-6 border-t border-slate-200 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-emerald-600" />
                    Transactions & Paiements Reçus via Agrégateur Bancaire ({payments.length})
                  </h3>
                  <p className="text-xs text-slate-500">
                    Flux interbancaires et Mobile Money (Rawbank, Equity BCDC, Ecobank, TMB, FBNBank, Sofibanque, Access Bank, M-Pesa, Orange, Airtel, Afrimoney).
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-400 block uppercase font-mono">Total Consigné</span>
                  <span className="font-mono text-base font-bold text-emerald-700">
                    {formatUsd(payments.reduce((acc, p) => acc + (p.status === 'completed' ? p.amountUsd : 0), 0))}
                  </span>
                </div>
              </div>

              {payments.length === 0 ? (
                <div className="text-center py-8 text-xs text-slate-500 border border-dashed border-slate-200 rounded-xl">
                  Aucune transaction enregistrée pour le moment.
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-50 text-slate-500 uppercase font-semibold text-[10px] border-b border-slate-200">
                      <tr>
                        <th className="py-2.5 px-3">Reçu & Réf. API</th>
                        <th className="py-2.5 px-3">Client & Contact</th>
                        <th className="py-2.5 px-3">Montant USD</th>
                        <th className="py-2.5 px-3">Franc Congolais (CDF)</th>
                        <th className="py-2.5 px-3">Agrégateur & Canal</th>
                        <th className="py-2.5 px-3">Motif & Séquestre</th>
                        <th className="py-2.5 px-3">Statut</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-mono">
                      {payments.map((p) => (
                        <tr key={p.id} className="hover:bg-slate-50">
                          <td className="py-3 px-3">
                            <div className="font-bold text-slate-900">{p.receiptNumber}</div>
                            <div className="text-[10px] text-slate-400 font-mono">{p.reference}</div>
                          </td>
                          <td className="py-3 px-3 font-sans">
                            <div className="font-semibold text-slate-800">{p.userName}</div>
                            <div className="text-[10px] text-slate-400 font-mono">{p.userPhone}</div>
                          </td>
                          <td className="py-3 px-3 font-bold text-slate-900">{formatUsd(p.amountUsd)}</td>
                          <td className="py-3 px-3 text-amber-700 font-bold">
                            {p.amountCdf.toLocaleString()} CDF
                          </td>
                          <td className="py-3 px-3 font-sans">
                            <div className="font-bold text-[#0B1F3A] text-[11px]">
                              {p.aggregatorName || 'NgoluPay Hub'}
                            </div>
                            <div className="text-[10px] font-mono uppercase text-slate-500">
                              {p.provider}
                              {p.bankSwiftCode ? ` · ${p.bankSwiftCode}` : ''}
                            </div>
                          </td>
                          <td className="py-3 px-3 font-sans text-[11px]">
                            <div className="font-medium text-slate-800">
                              {p.purpose === 'deposit_guarantee'
                                ? 'Caution de garantie'
                                : p.purpose === 'premium_subscription'
                                ? 'Abonnement Premium'
                                : p.purpose === 'ad_promotion'
                                ? 'Publicité / Sponsoring'
                                : 'Règlement lot'}
                            </div>
                            <div className="text-[10px] text-slate-400">
                              {p.escrowAccountNumber || 'Rawbank Kinshasa'}
                            </div>
                          </td>
                          <td className="py-3 px-3 font-sans">
                            <span className="text-[11px] font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 flex items-center gap-1 w-max">
                              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                              Validé & Séquestré
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: AUDIT TRAIL */}
      {activeTab === 'audit' && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900">
                Journal d’audit immuable des actions sensibles
              </h2>
              <p className="text-xs text-slate-500">
                Traçabilité des offres, approbations, refus, modifications de barèmes et versements.
              </p>
            </div>
          </div>

          <div className="divide-y divide-slate-100 font-mono text-xs max-h-96 overflow-y-auto">
            {auditLogs.map((log) => (
              <div key={log.id} className="py-3 flex items-start justify-between gap-4">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900 uppercase text-[10px] bg-slate-100 px-1.5 py-0.5 rounded">
                      {log.action}
                    </span>
                    <span className="text-slate-400">·</span>
                    <span className="text-slate-600 font-sans font-medium">
                      Acteur : {log.actorName} ({log.actorRole})
                    </span>
                  </div>
                  <p className="font-sans text-slate-700 text-xs">{log.details}</p>
                </div>
                <div className="text-[11px] text-slate-400 shrink-0">
                  {new Date(log.timestamp).toLocaleTimeString('fr-FR', {
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit',
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Rejection Modal */}
      {rejectModalAuction && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 p-6 space-y-4">
            <h3 className="text-base font-bold text-slate-900">
              Refuser la mise aux enchères de "{rejectModalAuction.title}"
            </h3>
            <p className="text-xs text-slate-500">
              Le motif sera notifié au vendeur pro afin qu’il puisse corriger ou compléter son dossier.
            </p>

            <div>
              <label className="block text-xs font-medium text-slate-700 mb-1">
                Motif officiel du refus *
              </label>
              <textarea
                rows={3}
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                className="w-full p-2.5 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-rose-500"
              />
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setRejectModalAuction(null)}
                className="px-3.5 py-2 text-xs text-slate-600 hover:text-slate-900"
              >
                Annuler
              </button>
              <button
                type="button"
                onClick={() => {
                  rejectAuction(rejectModalAuction.id, rejectionReason);
                  setRejectModalAuction(null);
                }}
                className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs rounded-lg"
              >
                Confirmer le refus
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Seller Application & Document Review Modal */}
      {reviewingSeller && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[90vh] flex flex-col">
            <div className="p-5 border-b border-slate-200 bg-[#0B1F3A] text-white flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold text-amber-400 uppercase tracking-widest">
                  Contrôle de Conformité KYC Vendeur
                </span>
                <h3 className="text-base font-bold">{reviewingSeller.companyName}</h3>
                <span className="text-xs text-slate-300 font-mono">
                  RCCM : {reviewingSeller.rccmNumber} · Id. Nat : {reviewingSeller.idNat || 'N/A'}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setReviewingSeller(null)}
                className="text-slate-300 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 overflow-y-auto space-y-5 text-xs">
              <div className="grid grid-cols-2 gap-3 p-3.5 bg-slate-50 border border-slate-200 rounded-xl">
                <div>
                  <span className="text-slate-500 block text-[10px]">Numéro Impôt DGI</span>
                  <span className="font-mono font-bold text-slate-800">{reviewingSeller.taxNumber || 'Non renseigné'}</span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px]">Téléphone certifié</span>
                  <span className="font-mono text-slate-800">{reviewingSeller.phone}</span>
                </div>
                <div className="col-span-2">
                  <span className="text-slate-500 block text-[10px]">Siège social</span>
                  <span className="text-slate-800 font-medium">{reviewingSeller.address}</span>
                </div>
                <div className="col-span-2">
                  <span className="text-slate-500 block text-[10px]">Coordonnées bancaires pour versements</span>
                  <span className="font-mono text-slate-800">{reviewingSeller.bankRib || 'Non renseigné'}</span>
                </div>
              </div>

              <div>
                <span className="font-bold text-[#0B1F3A] uppercase tracking-wide block mb-2">
                  Pièces justificatives téléversées ({reviewingSeller.documents?.length || 0})
                </span>

                {(!reviewingSeller.documents || reviewingSeller.documents.length === 0) ? (
                  <div className="p-4 bg-slate-50 text-center text-slate-500 rounded-lg border border-dashed border-slate-200">
                    Aucun document téléversé pour le moment.
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    {reviewingSeller.documents.map((doc) => {
                      const decision = docDecisions[doc.id] || (doc.status === 'rejected' ? 'rejected' : 'verified');
                      return (
                        <div
                          key={doc.id}
                          className="p-3 bg-white border border-slate-200 rounded-xl space-y-2"
                        >
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                            <div className="flex items-center gap-3 min-w-0">
                              <FileCheck className="w-5 h-5 text-amber-600 shrink-0" />
                              <div className="min-w-0">
                                <span className="font-bold text-slate-900 block truncate">{doc.name}</span>
                                <span className="text-slate-500 font-mono text-[10px]">
                                  {doc.fileName} · {doc.fileSize} · {new Date(doc.uploadedAt).toLocaleDateString('fr-FR')}
                                </span>
                              </div>
                            </div>

                            <div className="flex items-center gap-1.5 shrink-0">
                              {doc.fileUrl && doc.fileUrl !== '#' && (
                                <a
                                  href={doc.fileUrl}
                                  download={doc.fileName}
                                  target="_blank"
                                  rel="noreferrer"
                                  className="px-2 py-1 text-[10px] font-semibold text-[#0B1F3A] bg-slate-100 hover:bg-slate-200 rounded flex items-center gap-1"
                                >
                                  <ExternalLink className="w-3 h-3" />
                                  Ouvrir
                                </a>
                              )}
                              <button
                                type="button"
                                onClick={() =>
                                  setDocDecisions((prev) => ({ ...prev, [doc.id]: 'verified' }))
                                }
                                className={`px-2 py-1 rounded text-[10px] font-bold border cursor-pointer ${
                                  decision === 'verified'
                                    ? 'bg-emerald-600 text-white border-emerald-600'
                                    : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-50'
                                }`}
                              >
                                Conforme
                              </button>
                              <button
                                type="button"
                                onClick={() =>
                                  setDocDecisions((prev) => ({ ...prev, [doc.id]: 'rejected' }))
                                }
                                className={`px-2 py-1 rounded text-[10px] font-bold border cursor-pointer ${
                                  decision === 'rejected'
                                    ? 'bg-rose-600 text-white border-rose-600'
                                    : 'bg-white text-slate-600 border-slate-300 hover:bg-slate-50'
                                }`}
                              >
                                Non conforme
                              </button>
                            </div>
                          </div>

                          {doc.fileUrl && doc.fileUrl.startsWith('data:image/') && (
                            <div className="pt-1">
                              <img
                                src={doc.fileUrl}
                                alt={doc.name}
                                className="max-h-36 rounded-lg border border-slate-200 object-contain bg-slate-50"
                              />
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Observations et compte-rendu de conformité NgoluMarket *
                </label>
                <textarea
                  rows={3}
                  value={sellerNotes}
                  onChange={(e) => setSellerNotes(e.target.value)}
                  className="w-full p-2.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#0B1F3A]"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-3">
                <button
                  type="button"
                  onClick={() => {
                    const rejectedDocs: Record<string, 'verified' | 'rejected'> = {};
                    (reviewingSeller.documents || []).forEach((d) => {
                      rejectedDocs[d.id] = docDecisions[d.id] === 'verified' ? 'rejected' : 'rejected';
                    });
                    verifySeller(
                      reviewingSeller.userId,
                      false,
                      sellerNotes,
                      Object.keys(docDecisions).length > 0 ? docDecisions : rejectedDocs
                    );
                    setReviewingSeller(null);
                  }}
                  className="px-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-lg font-bold cursor-pointer"
                >
                  Rejeter le dossier
                </button>

                <button
                  type="button"
                  onClick={() => {
                    verifySeller(reviewingSeller.userId, true, sellerNotes, docDecisions);
                    setReviewingSeller(null);
                  }}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold shadow-sm cursor-pointer"
                >
                  Approuver & Certifier le Vendeur
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
