import React, { useState } from 'react';
import {
  Award,
  Bell,
  Globe,
  LogOut,
  PlusCircle,
  ShieldCheck,
  Store,
  UserCheck,
} from 'lucide-react';
import { useAuctia } from '../context/AuctiaContext';
import { Category, Language } from '../types';
import { t } from '../utils/i18n';

interface NavbarProps {
  currentCategory: Category | 'all';
  onSelectCategory: (category: Category | 'all') => void;
  activeView: 'home' | 'buyer' | 'seller' | 'admin';
  setActiveView: (view: 'home' | 'buyer' | 'seller' | 'admin') => void;
  onOpenNewAuction: () => void;
  onOpenAuth: (mode?: 'signin' | 'register') => void;
  onOpenNotifications: () => void;
  onOpenDecisions: () => void;
  onOpenPremium: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentCategory,
  onSelectCategory,
  activeView,
  setActiveView,
  onOpenNewAuction,
  onOpenAuth,
  onOpenNotifications,
  onOpenDecisions,
  onOpenPremium,
}) => {
  const { currentUser, logout, notifications, isWsConnected, language, setLanguage } = useAuctia();
  const [showUserMenu, setShowUserMenu] = useState(false);

  const unreadNotifications = notifications.filter(
    (n) => (currentUser ? n.userId === currentUser.id : false) && !n.read
  ).length;

  const isAdmin = currentUser?.role === 'admin' || currentUser?.role === 'super_admin';

  const handleDepositClick = () => {
    if (!currentUser) {
      onOpenAuth('register');
    } else {
      onOpenNewAuction();
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      {/* Location, Currency, Language Switcher & Live Engine Bar (Navy Blue #0B1F3A) */}
      <div className="bg-[#0B1F3A] text-slate-200 text-xs px-4 sm:px-6 py-1.5 border-b border-[#163254] flex items-center justify-between gap-2">
        <div className="flex items-center gap-3">
          <span className="text-amber-400 font-bold tracking-wider text-[11px] uppercase">
            {t(language, 'brandLocation')}
          </span>
          <span className="text-slate-500 hidden sm:inline">·</span>
          <span className="text-slate-300 hidden md:inline">
            {t(language, 'tagline')}
          </span>
          <div className="hidden lg:flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-[#14325C] text-slate-200 border border-[#244B82]">
            <span className={`w-1.5 h-1.5 rounded-full ${isWsConnected ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`}></span>
            <span>{isWsConnected ? t(language, 'liveEngineActive') : t(language, 'connecting')}</span>
          </div>
        </div>

        <div className="flex items-center gap-3 sm:gap-4 text-[11px]">
          {/* Multilingual Switcher: FR | EN | LN */}
          <div className="flex items-center gap-1 bg-[#14325C] border border-[#244B82] rounded-md px-1.5 py-0.5">
            <Globe className="w-3 h-3 text-amber-400 mr-0.5" />
            {(['fr', 'en', 'ln'] as Language[]).map((lang) => (
              <button
                key={lang}
                type="button"
                onClick={() => setLanguage(lang)}
                className={`px-1.5 py-0.5 rounded text-[10px] font-bold uppercase transition-colors cursor-pointer ${
                  language === lang
                    ? 'bg-amber-400 text-[#0B1F3A]'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                {lang}
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={onOpenDecisions}
            className="text-slate-300 hover:text-amber-300 transition-colors hidden sm:inline cursor-pointer"
          >
            {t(language, 'techSheet')}
          </button>

          {!currentUser ? (
            <div className="flex items-center gap-2.5 font-semibold">
              <button
                type="button"
                onClick={() => onOpenAuth('signin')}
                className="text-slate-200 hover:text-white transition-colors cursor-pointer"
              >
                {t(language, 'signIn')}
              </button>
              <span className="text-slate-500">|</span>
              <button
                type="button"
                onClick={() => onOpenAuth('register')}
                className="text-amber-400 hover:text-amber-300 transition-colors cursor-pointer"
              >
                {t(language, 'register')}
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2 text-slate-200">
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              <span className="font-medium text-white truncate max-w-[140px]">{currentUser.name}</span>
              {currentUser.isPremium ? (
                <button
                  type="button"
                  onClick={onOpenPremium}
                  className="hidden sm:inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded bg-amber-400/20 text-amber-300 border border-amber-400/40 text-[10px] font-bold cursor-pointer"
                >
                  <Award className="w-2.5 h-2.5" />
                  {t(language, 'premiumBadge')}
                </button>
              ) : (
                <button
                  type="button"
                  onClick={onOpenPremium}
                  className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded bg-white/10 hover:bg-amber-400 hover:text-[#0B1F3A] text-slate-200 border border-white/20 text-[10px] font-bold transition-colors cursor-pointer"
                >
                  <span>{t(language, 'normalUpgradeBtn')}</span>
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Main Top Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-6 h-16">
          {/* Brand Wordmark */}
          <button
            type="button"
            onClick={() => {
              setActiveView('home');
              onSelectCategory('all');
            }}
            className="flex items-center gap-2.5 group text-left cursor-pointer"
          >
            <div className="w-8 h-8 rounded bg-[#0B1F3A] text-amber-400 flex items-center justify-center font-serif-display font-bold text-lg shadow-sm">
              N
            </div>
            <span className="text-xl font-bold tracking-tight text-[#0B1F3A] whitespace-nowrap shrink-0 group-hover:text-amber-600 transition-colors">
              NgoluMarket
            </span>
          </button>

          {/* Navigation Links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
            <button
              type="button"
              onClick={() => {
                setActiveView('home');
                onSelectCategory('all');
              }}
              className={`hover:text-[#0B1F3A] transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeView === 'home' && currentCategory === 'all'
                  ? 'text-[#0B1F3A] font-semibold underline decoration-amber-500 underline-offset-8'
                  : ''
              }`}
            >
              {t(language, 'allListings')}
            </button>

            <button
              type="button"
              onClick={() => {
                setActiveView('home');
                onSelectCategory('electronique');
              }}
              className={`hover:text-[#0B1F3A] transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeView === 'home' && currentCategory === 'electronique'
                  ? 'text-[#0B1F3A] font-semibold underline decoration-amber-500 underline-offset-8'
                  : ''
              }`}
            >
              {language === 'en' ? 'Electronics' : language === 'ln' ? 'Électronique' : 'Électronique'}
            </button>

            <button
              type="button"
              onClick={() => {
                setActiveView('home');
                onSelectCategory('immobilier');
              }}
              className={`hover:text-[#0B1F3A] transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeView === 'home' && currentCategory === 'immobilier'
                  ? 'text-[#0B1F3A] font-semibold underline decoration-amber-500 underline-offset-8'
                  : ''
              }`}
            >
              {language === 'en' ? 'Real Estate' : language === 'ln' ? 'Bandako' : 'Immobilier'}
            </button>

            <button
              type="button"
              onClick={() => {
                setActiveView('home');
                onSelectCategory('automobile');
              }}
              className={`hover:text-[#0B1F3A] transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                activeView === 'home' && currentCategory === 'automobile'
                  ? 'text-[#0B1F3A] font-semibold underline decoration-amber-500 underline-offset-8'
                  : ''
              }`}
            >
              {language === 'en' ? 'Automotive' : language === 'ln' ? 'Mituka' : 'Automobile'}
            </button>

            {currentUser && (
              <button
                type="button"
                onClick={() => setActiveView('buyer')}
                className={`hover:text-[#0B1F3A] transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  activeView === 'buyer'
                    ? 'text-[#0B1F3A] font-semibold underline decoration-amber-500 underline-offset-8'
                    : ''
                }`}
              >
                {t(language, 'myAuctions')}
              </button>
            )}

            {isAdmin && (
              <button
                type="button"
                onClick={() => setActiveView('admin')}
                className={`flex items-center gap-1.5 hover:text-amber-700 transition-colors whitespace-nowrap shrink-0 font-semibold cursor-pointer ${
                  activeView === 'admin'
                    ? 'text-amber-700 underline decoration-amber-500 underline-offset-8'
                    : 'text-amber-600'
                }`}
              >
                <ShieldCheck className="w-4 h-4" />
                {t(language, 'admin')}
              </button>
            )}
          </nav>

          {/* Primary Action & Controls */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={handleDepositClick}
              className="flex items-center gap-1.5 px-3.5 sm:px-4 py-2 text-xs font-bold text-[#0B1F3A] bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors whitespace-nowrap shrink-0 shadow-sm cursor-pointer"
            >
              <PlusCircle className="w-4 h-4" />
              <span>{t(language, 'publishCta')}</span>
            </button>

            {currentUser ? (
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onOpenNotifications}
                  title="Notifications"
                  className="relative p-2 text-slate-600 hover:text-[#0B1F3A] hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                >
                  <Bell className="w-5 h-5" />
                  {unreadNotifications > 0 && (
                    <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-amber-500"></span>
                  )}
                </button>

                {/* User Dropdown */}
                <div className="relative">
                  <button
                    type="button"
                    onClick={() => setShowUserMenu(!showUserMenu)}
                    className="flex items-center gap-2 p-1.5 hover:bg-slate-100 rounded-lg text-slate-700 transition-colors cursor-pointer"
                  >
                    {currentUser.avatar ? (
                      <img
                        src={currentUser.avatar}
                        alt={currentUser.name}
                        className="w-7 h-7 rounded-full object-cover border border-slate-300"
                      />
                    ) : (
                      <div className="w-7 h-7 rounded-full bg-[#0B1F3A] text-white flex items-center justify-center text-xs font-bold">
                        {currentUser.name.charAt(0).toUpperCase()}
                      </div>
                    )}
                    <span className="text-xs font-semibold hidden lg:inline max-w-[120px] truncate">
                      {currentUser.name}
                    </span>
                  </button>

                  {showUserMenu && (
                    <div
                      className="absolute right-0 mt-2 w-60 bg-white border border-slate-200 rounded-xl shadow-xl py-2 z-50 text-left text-xs"
                      onMouseLeave={() => setShowUserMenu(false)}
                    >
                      <div className="px-3.5 py-2 border-b border-slate-100">
                        <span className="font-bold text-slate-900 block truncate">
                          {currentUser.name}
                        </span>
                        <span className="text-[11px] text-slate-500 block truncate">
                          {currentUser.email || currentUser.phone}
                        </span>
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          setActiveView('buyer');
                          setShowUserMenu(false);
                        }}
                        className="w-full text-left px-3.5 py-2 hover:bg-slate-50 text-slate-700 flex items-center gap-2 cursor-pointer"
                      >
                        <UserCheck className="w-4 h-4 text-slate-400" />
                        <span>{t(language, 'buyerSpaceMenu')}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setActiveView('seller');
                          setShowUserMenu(false);
                        }}
                        className="w-full text-left px-3.5 py-2 hover:bg-slate-50 text-slate-700 flex items-center gap-2 cursor-pointer"
                      >
                        <Store className="w-4 h-4 text-[#0B1F3A]" />
                        <span>{t(language, 'sellerSpaceMenu')}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          onOpenNewAuction();
                          setShowUserMenu(false);
                        }}
                        className="w-full text-left px-3.5 py-2 hover:bg-slate-50 text-slate-700 flex items-center gap-2 cursor-pointer"
                      >
                        <PlusCircle className="w-4 h-4 text-amber-500" />
                        <span>{t(language, 'publishProductMenu')}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          onOpenPremium();
                          setShowUserMenu(false);
                        }}
                        className="w-full text-left px-3.5 py-2 hover:bg-amber-50 text-[#0B1F3A] font-semibold flex items-center justify-between gap-2 cursor-pointer"
                      >
                        <span className="flex items-center gap-2">
                          <Award className="w-4 h-4 text-amber-500" />
                          {currentUser.isPremium ? t(language, 'premiumActiveMenu') : t(language, 'upgradePremiumMenu')}
                        </span>
                        <span
                          className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${
                            currentUser.isPremium
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-amber-100 text-amber-900'
                          }`}
                        >
                          {currentUser.isPremium ? 'PRO' : '50$'}
                        </span>
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          logout();
                          setActiveView('home');
                          setShowUserMenu(false);
                        }}
                        className="w-full text-left px-3.5 py-2 hover:bg-rose-50 text-rose-600 flex items-center gap-2 border-t border-slate-100 mt-1 cursor-pointer"
                      >
                        <LogOut className="w-4 h-4" />
                        <span>{t(language, 'logoutMenu')}</span>
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => onOpenAuth('register')}
                className="px-3.5 py-2 text-xs font-semibold text-white bg-[#0B1F3A] rounded-lg hover:bg-[#14325C] transition-colors whitespace-nowrap shrink-0 shadow-sm cursor-pointer"
              >
                {t(language, 'register')}
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
