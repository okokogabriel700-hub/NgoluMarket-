import React from 'react';
import { CheckCircle2, Globe, Shield, X } from 'lucide-react';
import { useAuctia } from '../context/AuctiaContext';

interface DecisionsModalProps {
  onClose: () => void;
  onGoToSettings: () => void;
}

export const DecisionsModal: React.FC<DecisionsModalProps> = ({ onClose, onGoToSettings }) => {
  const { settings, currentUser } = useAuctia();
  const isAdmin = currentUser?.role === 'admin' || currentUser?.role === 'super_admin';

  const specs = [
    {
      num: '1',
      title: 'Système de vente à prix fixe (Section 6)',
      badge: `Frais acheteur : ${settings.fixedPriceBuyerFeeUsd ?? 1} USD · Vendeur gratuit`,
      detail:
        'Publication gratuite pour le vendeur. Les frais de plateforme NgoluMarket sont fixés à 1 USD par vente à prix fixe et payés par l’acheteur (ex: Produit 50 USD + Frais 1 USD = 51 USD). Configurable dans l’administration.',
    },
    {
      num: '2',
      title: 'Système d’enchères en ligne & Commission (Section 7)',
      badge: `Commission vendeur : ${settings.commissionRatePercent}% · Acheteur gratuit`,
      detail:
        'La publication aux enchères est réservée aux vendeurs Premium. La participation des acheteurs est 100% gratuite. Une commission de 5% du prix final est prélevée au vendeur à la clôture.',
    },
    {
      num: '3',
      title: 'Abonnement Vendeur Premium (Section 8)',
      badge: `${settings.premiumSubscriptionPriceUsd ?? 50} USD / trimestre`,
      detail:
        'Activation des droits Premium dès confirmation du paiement, suivi des dates de début et d’expiration trimestrielle, renouvellement et historique des règlements.',
    },
    {
      num: '4',
      title: 'Publicité et Produits Sponsorisés (Section 9)',
      badge: `Publicité : ${settings.adMonthlyPriceUsd ?? 1} USD/mois · Sponsoring : ${settings.sponsoredProductPriceUsd ?? 1} USD/produit`,
      detail:
        'Les utilisateurs peuvent demander une mise en avant prioritaire ou bannière publicitaire avec validation, refus ou suspension par l’administration.',
    },
    {
      num: '5',
      title: 'Gestion des Commandes & Agrégateur Bancaire (Sections 11 & 12)',
      badge: '8 statuts · Agrégateur Multi-Banques RDC',
      detail:
        'Chaque commande possède un numéro unique (CMD-YYYY-XXXXX) et suit 8 statuts. Paiements routés via l’agrégateur bancaire NgoluPay Hub connectant Rawbank, Equity BCDC, Ecobank, TMB Pepele, FBNBank, Sofibanque, Access Bank, Mobile Money RDC et cartes Visa/Mastercard.',
    },
    {
      num: '6',
      title: 'Identité visuelle, Langues & Expansion (Sections 15 & 16)',
      badge: 'Bleu Marine · FR / EN / LN · Afrique',
      detail:
        'Identité FURAH Labs en Bleu Marine (#0B1F3A), blanc et gris clair. Interface trilingue Français, Anglais et Lingala. Architecture prévue pour RDC (Kinshasa), Kenya, Sénégal (Dakar) et Maroc.',
    },
  ];

  const pointsToValidate = [
    'Validation finale des prestataires de paiement (Mobile Money & cartes bancaires).',
    'Validation du parcours vendeur et du workflow d’activation Premium.',
    'Validation des règles de modération des produits et publicités.',
    'Validation du circuit de traitement et livraison des commandes.',
    'Validation des niveaux d’autorisation des administrateurs (Admin / Super Admin).',
    'Validation du calendrier de lancement à Kinshasa et expansion internationale.',
  ];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/75 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6">
      <div className="relative w-full max-w-4xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-[#163254] bg-[#0B1F3A] text-white flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-amber-400 uppercase tracking-widest block">
              Document de Cadrage Technique — Version 1.0 · FURAH Labs
            </span>
            <h2 className="text-xl font-bold mt-0.5">
              Fiche Technique de Développement NgoluMarket
            </h2>
            <p className="text-xs text-slate-300 mt-1">
              Marché initial : Kinshasa, RDC · Plateformes : Web, Android & iOS · Langues : FR, EN, LN
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-300 hover:text-white rounded-lg cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-5">
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-xl text-xs text-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <strong className="text-[#0B1F3A] block font-bold mb-1">
                « NgoluMarket — Le commerce en ligne, à prix fixe et aux enchères. »
              </strong>
              Tous les barèmes (1 USD prix fixe, 5% commission enchères, 50 USD/trim. Premium, 1 USD pub/sponsoring) et les 9 catégories sont configurables dynamiquement depuis le tableau de bord administrateur.
            </div>
            {isAdmin && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onGoToSettings();
                }}
                className="px-3.5 py-2 bg-[#0B1F3A] hover:bg-[#14325C] text-white font-bold rounded-lg shrink-0 transition-colors shadow-xs cursor-pointer"
              >
                Ouvrir le configurateur admin
              </button>
            )}
          </div>

          <div className="space-y-3">
            {specs.map((item) => (
              <div
                key={item.num}
                className="p-4 border border-slate-200 rounded-xl bg-slate-50/50 hover:bg-white transition-colors text-xs space-y-1.5"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-[#0B1F3A] text-amber-400 font-bold flex items-center justify-center text-[11px] shrink-0 font-mono">
                      {item.num}
                    </span>
                    <h3 className="font-bold text-[#0B1F3A] text-xs sm:text-sm">{item.title}</h3>
                  </div>
                  <span className="text-[11px] font-semibold text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded border border-emerald-200 shrink-0 w-fit">
                    {item.badge}
                  </span>
                </div>
                <p className="text-slate-600 pl-7 leading-relaxed">{item.detail}</p>
              </div>
            ))}
          </div>

          {/* Section 23: Points à valider */}
          <div className="p-4 bg-[#0B1F3A] text-white rounded-xl border border-[#163254] space-y-2.5 text-xs">
            <div className="font-bold text-amber-400 uppercase tracking-wider flex items-center gap-1.5">
              <Shield className="w-4 h-4" />
              Section 23 — Points de validation avant déploiement final (FURAH Labs)
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {pointsToValidate.map((pt, i) => (
                <div key={i} className="flex items-start gap-2 text-slate-200 text-[11px]">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                  <span>{pt}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between text-xs">
          <span className="text-slate-500 flex items-center gap-1.5">
            <Globe className="w-3.5 h-3.5 text-[#0B1F3A]" />
            NgoluMarket · FURAH Labs · Fiche Technique v1.0
          </span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 bg-[#0B1F3A] hover:bg-[#14325C] text-white font-bold rounded-lg transition-colors cursor-pointer"
          >
            Fermer
          </button>
        </div>
      </div>
    </div>
  );
};
