import React, { useRef, useState } from 'react';
import {
  CheckCircle2,
  Clock,
  ExternalLink,
  FileText,
  Plus,
  ShieldAlert,
  ShieldCheck,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import { useAuctia } from '../context/AuctiaContext';
import { SellerDocument } from '../types';

interface SellerVerificationModalProps {
  onClose: () => void;
}

const DOC_TYPE_OPTIONS: { value: SellerDocument['type']; label: string; hint: string }[] = [
  {
    value: 'rccm',
    label: 'Extrait RCCM (Registre du Commerce)',
    hint: 'PDF ou image certifiée du Greffe du Tribunal de Commerce',
  },
  {
    value: 'id_nat',
    label: 'Numéro d’Identification Nationale (Id. Nat)',
    hint: 'Attestation officielle du Ministère de l’Économie',
  },
  {
    value: 'tax_cert',
    label: 'Attestation Fiscale DGI',
    hint: 'Quitus fiscal annuel en cours de validité',
  },
  {
    value: 'bank_rib',
    label: 'Relevé d’Identité Bancaire (RIB)',
    hint: 'Rawbank, Equity BCDC, TMB ou Ecobank RDC',
  },
  {
    value: 'identity_card',
    label: 'Pièce d’identité du gérant / dirigeant',
    hint: 'Passeport, Carte d’électeur CENI ou Permis de conduire',
  },
  {
    value: 'office_lease',
    label: 'Preuve de domiciliation / Patente commerciale',
    hint: 'Contrat de bail commercial ou patente municipale Kinshasa',
  },
];

function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

export const SellerVerificationModal: React.FC<SellerVerificationModalProps> = ({ onClose }) => {
  const {
    currentUser,
    sellerProfiles,
    uploadSellerDocument,
    removeSellerDocument,
    registerSellerProfile,
  } = useAuctia();

  const currentProfile = sellerProfiles.find((p) => p.userId === currentUser?.id);

  const [companyName, setCompanyName] = useState(
    currentProfile?.companyName || currentUser?.companyName || currentUser?.name || ''
  );
  const [rccm, setRccm] = useState(currentProfile?.rccmNumber || '');
  const [idNat, setIdNat] = useState(currentProfile?.idNat || '');
  const [taxNumber, setTaxNumber] = useState(currentProfile?.taxNumber || '');
  const [address, setAddress] = useState(
    currentProfile?.address || (currentUser?.city ? `${currentUser.city}, RDC` : 'Kinshasa, RDC')
  );
  const [phone, setPhone] = useState(currentProfile?.phone || currentUser?.phone || '');
  const [bankRib, setBankRib] = useState(currentProfile?.bankRib || '');

  const [selectedDocType, setSelectedDocType] = useState<SellerDocument['type']>('rccm');
  const [customDocTitle, setCustomDocTitle] = useState('');
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(
    null
  );
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const slotUploadTypeRef = useRef<{ type: SellerDocument['type']; name: string } | null>(null);
  const slotFileInputRef = useRef<HTMLInputElement | null>(null);

  const documents = currentProfile?.documents || [];

  const readFileAndUpload = (
    file: File,
    docType: SellerDocument['type'],
    docName: string
  ) => {
    if (!currentUser) return;
    if (file.size > 5 * 1024 * 1024) {
      setFeedback({
        type: 'error',
        message: 'Le fichier dépasse la limite maximale autorisée de 5 Mo.',
      });
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = typeof reader.result === 'string' ? reader.result : '#';
      uploadSellerDocument(currentUser.id, {
        name: docName,
        type: docType,
        fileName: file.name,
        fileSize: formatFileSize(file.size),
        fileUrl: dataUrl,
      });
      setCustomDocTitle('');
      setFeedback({
        type: 'success',
        message: `Document "${docName}" (${file.name}) téléversé et joint à votre dossier.`,
      });
    };
    reader.onerror = () => {
      setFeedback({
        type: 'error',
        message: 'Impossible de lire le fichier sélectionné. Veuillez réessayer.',
      });
    };
    reader.readAsDataURL(file);
  };

  const handleQuickSlotClick = (type: SellerDocument['type'], name: string) => {
    slotUploadTypeRef.current = { type, name };
    if (slotFileInputRef.current) {
      slotFileInputRef.current.value = '';
      slotFileInputRef.current.click();
    }
  };

  const handleSlotFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    const target = slotUploadTypeRef.current;
    if (!file || !target) return;
    readFileAndUpload(file, target.type, target.name);
  };

  const handleCustomFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const typeMeta = DOC_TYPE_OPTIONS.find((o) => o.value === selectedDocType);
    const label = customDocTitle.trim() || typeMeta?.label || 'Document justificatif';
    readFileAndUpload(file, selectedDocType, label);
    e.target.value = '';
  };

  const handleSubmitDossier = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    if (!companyName.trim() || !rccm.trim()) {
      setFeedback({
        type: 'error',
        message: 'Veuillez renseigner au minimum la raison sociale et le numéro RCCM.',
      });
      return;
    }
    registerSellerProfile({
      userId: currentUser.id,
      companyName: companyName.trim(),
      rccmNumber: rccm.trim(),
      idNat: idNat.trim() || 'Non renseigné',
      taxNumber: taxNumber.trim() || 'Non renseigné',
      address: address.trim() || 'Kinshasa, RDC',
      city: currentUser.city || 'Kinshasa',
      phone: phone.trim() || currentUser.phone,
      bankRib: bankRib.trim() || undefined,
      documents,
    });
    setFeedback({
      type: 'success',
      message:
        'Votre dossier complet a été soumis à l’équipe conformité NgoluMarket pour examen.',
    });
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6">
      <div className="relative w-full max-w-3xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Hidden shared file input for quick upload slots */}
        <input
          ref={slotFileInputRef}
          type="file"
          accept=".pdf,image/png,image/jpeg,image/webp"
          onChange={handleSlotFileChange}
          className="hidden"
        />

        {/* Header */}
        <div className="p-5 border-b border-slate-200 bg-[#0B1F3A] text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-[#14325C] border border-amber-400/30 text-amber-400 rounded-lg">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                Vérification & Certification Vendeur NgoluMarket
              </h2>
              <p className="text-xs text-slate-300">
                Soumettez vos documents commerciaux (RCCM, Id. Nat, DGI, RIB) pour obtenir le badge vérifié
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-300 hover:text-white hover:bg-[#14325C] rounded-lg cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Status banner */}
          <div
            className={`p-4 rounded-xl border flex items-start gap-3 ${
              currentProfile?.verificationStatus === 'verified'
                ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                : currentProfile?.verificationStatus === 'rejected'
                ? 'bg-rose-50 border-rose-200 text-rose-900'
                : currentProfile
                ? 'bg-amber-50 border-amber-200 text-amber-900'
                : 'bg-slate-50 border-slate-200 text-slate-800'
            }`}
          >
            {currentProfile?.verificationStatus === 'verified' ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            ) : currentProfile?.verificationStatus === 'rejected' ? (
              <ShieldAlert className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            ) : (
              <Clock className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            )}

            <div className="text-xs space-y-1">
              <div className="font-bold text-sm">
                Statut du dossier :{' '}
                {currentProfile?.verificationStatus === 'verified'
                  ? 'Vendeur Certifié & Vérifié'
                  : currentProfile?.verificationStatus === 'rejected'
                  ? 'Dossier Rejeté — Action requise'
                  : currentProfile
                  ? 'En cours d’examen par la modération NgoluMarket'
                  : 'Dossier non encore soumis'}
              </div>
              <p className="leading-relaxed opacity-90">
                {currentProfile?.verificationNotes ||
                  'Complétez vos informations légales ci-dessous et téléversez au moins un justificatif officiel (PDF ou image) puis soumettez votre dossier.'}
              </p>
              {currentProfile?.reviewedAt && (
                <p className="text-[11px] font-mono opacity-80">
                  Dernière décision le {new Date(currentProfile.reviewedAt).toLocaleDateString('fr-FR')}
                  {currentProfile.reviewedBy ? ` par ${currentProfile.reviewedBy}` : ''}
                </p>
              )}
            </div>
          </div>

          {feedback && (
            <div
              className={`p-3 rounded-lg text-xs flex items-center gap-2 border ${
                feedback.type === 'success'
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                  : 'bg-rose-50 border-rose-200 text-rose-900'
              }`}
            >
              {feedback.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              ) : (
                <ShieldAlert className="w-4 h-4 text-rose-600 shrink-0" />
              )}
              <span>{feedback.message}</span>
            </div>
          )}

          {/* Section 1: Business Credentials Form */}
          <form onSubmit={handleSubmitDossier} className="space-y-4">
            <span className="text-xs font-bold uppercase tracking-wider text-[#0B1F3A] block">
              1. Coordonnées légales & commerciales
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Raison sociale / Nom commercial *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Kinshasa Prestige SARL"
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  className="w-full p-2.5 border border-slate-300 rounded-lg font-medium focus:outline-none focus:ring-1 focus:ring-[#0B1F3A]"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Numéro RCCM (Registre du commerce) *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: CD/KIN/RCCM/24-B-09812"
                  value={rccm}
                  onChange={(e) => setRccm(e.target.value)}
                  className="w-full p-2.5 border border-slate-300 rounded-lg font-mono focus:outline-none focus:ring-1 focus:ring-[#0B1F3A]"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Numéro d’Identification Nationale (Id. Nat)
                </label>
                <input
                  type="text"
                  placeholder="Ex: 01-83-N55210K"
                  value={idNat}
                  onChange={(e) => setIdNat(e.target.value)}
                  className="w-full p-2.5 border border-slate-300 rounded-lg font-mono focus:outline-none focus:ring-1 focus:ring-[#0B1F3A]"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Numéro Impôt (DGI)
                </label>
                <input
                  type="text"
                  placeholder="Ex: A2401821X"
                  value={taxNumber}
                  onChange={(e) => setTaxNumber(e.target.value)}
                  className="w-full p-2.5 border border-slate-300 rounded-lg font-mono focus:outline-none focus:ring-1 focus:ring-[#0B1F3A]"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Adresse du siège / point de vente *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Boulevard du 30 Juin, Gombe, Kinshasa"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full p-2.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#0B1F3A]"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-medium mb-1">
                  Téléphone professionnel *
                </label>
                <input
                  type="text"
                  required
                  placeholder="+243 81 000 0000"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full p-2.5 border border-slate-300 rounded-lg font-mono focus:outline-none focus:ring-1 focus:ring-[#0B1F3A]"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-slate-700 font-medium mb-1">
                  Coordonnées bancaires / RIB pour versement des ventes
                </label>
                <input
                  type="text"
                  placeholder="Ex: Rawbank Kinshasa - CD03 0001 0444 8888 1234 56"
                  value={bankRib}
                  onChange={(e) => setBankRib(e.target.value)}
                  className="w-full p-2.5 border border-slate-300 rounded-lg font-mono text-[11px] focus:outline-none focus:ring-1 focus:ring-[#0B1F3A]"
                />
              </div>
            </div>

            {/* Section 2: Real Document Upload & Attachment List */}
            <div className="space-y-4 pt-4 border-t border-slate-200">
              <div>
                <span className="text-xs font-bold uppercase tracking-wider text-[#0B1F3A] block">
                  2. Pièces Justificatives ({documents.length})
                </span>
                <p className="text-[11px] text-slate-500">
                  Joignez vos fichiers PDF, PNG ou JPG (max 5 Mo par fichier). Chaque document est inspectable par l’administration.
                </p>
              </div>

              {/* Uploaded documents list */}
              {documents.length > 0 && (
                <div className="space-y-2">
                  {documents.map((doc) => (
                    <div
                      key={doc.id}
                      className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <FileText className="w-5 h-5 text-amber-600 shrink-0" />
                        <div className="min-w-0">
                          <div className="font-semibold text-slate-900 truncate">{doc.name}</div>
                          <div className="text-[11px] text-slate-500 font-mono truncate">
                            {doc.fileName} · {doc.fileSize} ·{' '}
                            {new Date(doc.uploadedAt).toLocaleDateString('fr-FR')}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        {doc.fileUrl && doc.fileUrl !== '#' && (
                          <a
                            href={doc.fileUrl}
                            download={doc.fileName}
                            target="_blank"
                            rel="noreferrer"
                            className="px-2 py-1 text-[11px] font-semibold text-[#0B1F3A] bg-white border border-slate-200 hover:bg-slate-100 rounded flex items-center gap-1"
                          >
                            <ExternalLink className="w-3 h-3" />
                            Aperçu
                          </a>
                        )}
                        {doc.status === 'verified' ? (
                          <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                            Validé
                          </span>
                        ) : doc.status === 'rejected' ? (
                          <span className="text-[11px] font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                            Rejeté
                          </span>
                        ) : (
                          <span className="text-[11px] font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                            En examen
                          </span>
                        )}
                        {currentUser && doc.status !== 'verified' && (
                          <button
                            type="button"
                            onClick={() => removeSellerDocument(currentUser.id, doc.id)}
                            title="Supprimer ce document"
                            className="p-1 text-slate-400 hover:text-rose-600 rounded cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Quick required document upload slots */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <button
                  type="button"
                  onClick={() =>
                    handleQuickSlotClick('rccm', 'Certificat RCCM (RDC)')
                  }
                  className="p-3 border border-dashed border-slate-300 hover:border-[#0B1F3A] hover:bg-slate-50 rounded-xl text-left transition-colors flex items-center gap-3 cursor-pointer"
                >
                  <Upload className="w-4 h-4 text-[#0B1F3A] shrink-0" />
                  <div>
                    <span className="font-bold text-slate-800 block">Joindre Extrait RCCM</span>
                    <span className="text-[10px] text-slate-500">PDF ou scan certifié Greffe</span>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() =>
                    handleQuickSlotClick('tax_cert', 'Attestation Fiscale DGI')
                  }
                  className="p-3 border border-dashed border-slate-300 hover:border-[#0B1F3A] hover:bg-slate-50 rounded-xl text-left transition-colors flex items-center gap-3 cursor-pointer"
                >
                  <Upload className="w-4 h-4 text-[#0B1F3A] shrink-0" />
                  <div>
                    <span className="font-bold text-slate-800 block">Joindre Attestation DGI</span>
                    <span className="text-[10px] text-slate-500">Quitus fiscal en cours</span>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() =>
                    handleQuickSlotClick('bank_rib', 'Relevé d’Identité Bancaire (RIB)')
                  }
                  className="p-3 border border-dashed border-slate-300 hover:border-[#0B1F3A] hover:bg-slate-50 rounded-xl text-left transition-colors flex items-center gap-3 cursor-pointer"
                >
                  <Upload className="w-4 h-4 text-[#0B1F3A] shrink-0" />
                  <div>
                    <span className="font-bold text-slate-800 block">Joindre RIB Bancaire</span>
                    <span className="text-[10px] text-slate-500">Rawbank / Equity BCDC / Ecobank</span>
                  </div>
                </button>

                <button
                  type="button"
                  onClick={() =>
                    handleQuickSlotClick('identity_card', 'Pièce d’identité du gérant')
                  }
                  className="p-3 border border-dashed border-slate-300 hover:border-[#0B1F3A] hover:bg-slate-50 rounded-xl text-left transition-colors flex items-center gap-3 cursor-pointer"
                >
                  <Upload className="w-4 h-4 text-[#0B1F3A] shrink-0" />
                  <div>
                    <span className="font-bold text-slate-800 block">Joindre Pièce d’identité</span>
                    <span className="text-[10px] text-slate-500">Passeport ou Carte CENI</span>
                  </div>
                </button>
              </div>

              {/* Custom document picker */}
              <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2.5 text-xs">
                <span className="font-bold text-[#0B1F3A] block">
                  Ajouter un autre document justificatif
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-12 gap-2">
                  <select
                    value={selectedDocType}
                    onChange={(e) => setSelectedDocType(e.target.value as SellerDocument['type'])}
                    className="sm:col-span-5 p-2 bg-white border border-slate-300 rounded-lg text-xs"
                  >
                    {DOC_TYPE_OPTIONS.map((opt) => (
                      <option key={opt.value} value={opt.value}>
                        {opt.label}
                      </option>
                    ))}
                  </select>
                  <input
                    type="text"
                    placeholder="Intitulé personnalisé (optionnel)"
                    value={customDocTitle}
                    onChange={(e) => setCustomDocTitle(e.target.value)}
                    className="sm:col-span-4 p-2 bg-white border border-slate-300 rounded-lg text-xs"
                  />
                  <label className="sm:col-span-3 px-3 py-2 bg-white hover:bg-slate-100 border border-[#0B1F3A] text-[#0B1F3A] rounded-lg font-bold text-xs flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap">
                    <Plus className="w-3.5 h-3.5" />
                    Choisir fichier
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept=".pdf,image/png,image/jpeg,image/webp"
                      onChange={handleCustomFileChange}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <span className="text-[11px] text-slate-500">
                Conformité vendeur vérifiée par l’administration NgoluMarket Kinshasa.
              </span>
              <div className="flex items-center gap-2 justify-end">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 rounded-lg cursor-pointer"
                >
                  Fermer
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-[#0B1F3A] hover:bg-[#14325C] text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 shadow-sm cursor-pointer"
                >
                  <ShieldCheck className="w-4 h-4 text-amber-400" />
                  {currentProfile?.verificationStatus === 'rejected'
                    ? 'Corriger et resoumettre le dossier'
                    : 'Soumettre mon dossier pour vérification'}
                </button>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
