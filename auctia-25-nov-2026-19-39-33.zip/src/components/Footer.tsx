import React from 'react';
import { Globe, Mail, MapPin, Phone, ShieldCheck } from 'lucide-react';
import { useAuctia } from '../context/AuctiaContext';
import { Category } from '../types';
import { ALL_CATEGORIES, getCategoryLabel } from '../utils/formatters';
import { t } from '../utils/i18n';

interface FooterProps {
  onSelectCategory: (cat: Category | 'all') => void;
  onOpenDecisions: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onSelectCategory, onOpenDecisions }) => {
  const { language, settings } = useAuctia();
  const categories = settings.enabledCategories?.length ? settings.enabledCategories : ALL_CATEGORIES;

  return (
    <footer className="bg-[#071426] text-slate-300 text-xs border-t border-[#163254] mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
          {/* Col 1: Brand & Presentation */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded bg-amber-400 text-[#0B1F3A] flex items-center justify-center font-serif-display font-bold text-base">
                N
              </div>
              <span className="text-lg font-bold tracking-tight text-white font-sans">NgoluMarket</span>
            </div>
            <p className="text-slate-300 text-xs leading-relaxed font-medium">
              {t(language, 'footerQuote')}
            </p>
            <p className="text-slate-400 text-[11px] leading-relaxed">
              {t(language, 'footerDesc')}
            </p>
            <div className="flex items-center gap-1.5 text-emerald-400 font-medium text-[11px] pt-1">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>{t(language, 'footerEscrow')}</span>
            </div>
          </div>

          {/* Col 2: All 9 Categories */}
          <div className="space-y-2.5">
            <h4 className="text-white font-semibold text-xs uppercase tracking-wider">
              {t(language, 'footerCategoriesTitle', { count: categories.length })}
            </h4>
            <div className="grid grid-cols-2 gap-x-3 gap-y-1.5">
              {categories.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => onSelectCategory(cat)}
                  className="text-left text-slate-300 hover:text-amber-300 transition-colors cursor-pointer"
                >
                  {getCategoryLabel(cat, language)}
                </button>
              ))}
              <button
                type="button"
                onClick={() => onSelectCategory('all')}
                className="col-span-2 text-left hover:text-white transition-colors text-amber-400 font-semibold pt-1 cursor-pointer"
              >
                {t(language, 'footerAllCatalog')}
              </button>
            </div>
          </div>

          {/* Col 3: Tarifs & Expansion */}
          <div className="space-y-2.5">
            <h4 className="text-white font-semibold text-xs uppercase tracking-wider">
              {t(language, 'footerPricingTitle')}
            </h4>
            <ul className="space-y-1.5 text-slate-300">
              <li>
                <button
                  type="button"
                  onClick={onOpenDecisions}
                  className="hover:text-white transition-colors text-amber-300 font-semibold cursor-pointer"
                >
                  {t(language, 'techSheet')} NgoluMarket v1.0
                </button>
              </li>
              <li>
                {t(language, 'footerPricingFixed', { fee: settings.fixedPriceBuyerFeeUsd ?? 1 })}
              </li>
              <li>
                {t(language, 'footerPricingAuction', {
                  price: settings.premiumSubscriptionPriceUsd ?? 50,
                  comm: settings.commissionRatePercent,
                })}
              </li>
              <li>
                {t(language, 'footerPricingAds', {
                  ad: settings.adMonthlyPriceUsd ?? 1,
                  sp: settings.sponsoredProductPriceUsd ?? 1,
                })}
              </li>
              <li className="text-emerald-300 text-[11px] font-medium">
                {t(language, 'footerAggregatorLine')}
              </li>
              <li className="pt-1 text-slate-400 flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                <span>{(settings.activeCountries || ['RDC (Kinshasa)', 'Kenya', 'Sénégal (Dakar)', 'Maroc']).join(' · ')}</span>
              </li>
            </ul>
          </div>

          {/* Col 4: Contact & Operations */}
          <div className="space-y-2.5">
            <h4 className="text-white font-semibold text-xs uppercase tracking-wider">
              {t(language, 'footerContactTitle')}
            </h4>
            <div className="space-y-2 text-slate-300">
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <span>Boulevard du 30 Juin, Commune de la Gombe, Kinshasa, RDC</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-amber-400 shrink-0" />
                <span className="font-mono">+243 89 000 0001 / +243 81 234 5678</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-amber-400 shrink-0" />
                <span>contact@ngolumarket.cd</span>
              </div>
              <div className="text-[11px] text-slate-400 pt-1">
                {t(language, 'footerLanguages')}
              </div>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 border-t border-[#163254] flex flex-col sm:flex-row items-center justify-between text-slate-400 gap-4">
          <p>{t(language, 'footerCopyright')}</p>
          <div className="flex items-center gap-4 text-[11px]">
            <span>Kinshasa · Web · Android · iOS</span>
            <span>·</span>
            <span>{t(language, 'footerCurrency')}</span>
            <span>·</span>
            <span>{t(language, 'techSheet')} v1.0</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
