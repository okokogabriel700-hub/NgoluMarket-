import React, { useMemo, useState } from 'react';
import {
  Activity,
  BarChart3,
  Calendar,
  CheckCircle2,
  DollarSign,
  Gavel,
  RotateCcw,
  ShieldCheck,
  TrendingUp,
  UserCheck,
  Users,
} from 'lucide-react';
import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { useAuctia } from '../context/AuctiaContext';
import { formatUsd, getCategoryLabel } from '../utils/formatters';

type DatePreset = 'today' | '7d' | '30d' | '90d' | 'all' | 'custom';

function toDateInputValue(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export const AdminAnalyticsPanel: React.FC = () => {
  const {
    users,
    sellerProfiles,
    auctions,
    settlements,
    payments,
    adCampaigns,
    settings,
    language,
  } = useAuctia();

  const [preset, setPreset] = useState<DatePreset>('all');
  const [dateFrom, setDateFrom] = useState<string>('');
  const [dateTo, setDateTo] = useState<string>('');

  const applyPreset = (nextPreset: DatePreset) => {
    setPreset(nextPreset);
    if (nextPreset === 'all') {
      setDateFrom('');
      setDateTo('');
      return;
    }
    const now = new Date();
    const endStr = toDateInputValue(now);
    const start = new Date(now);
    if (nextPreset === 'today') {
      setDateFrom(endStr);
      setDateTo(endStr);
      return;
    }
    if (nextPreset === '7d') start.setDate(now.getDate() - 6);
    if (nextPreset === '30d') start.setDate(now.getDate() - 29);
    if (nextPreset === '90d') start.setDate(now.getDate() - 89);
    setDateFrom(toDateInputValue(start));
    setDateTo(endStr);
  };

  const rangeBounds = useMemo(() => {
    const startMs = dateFrom ? new Date(`${dateFrom}T00:00:00.000`).getTime() : null;
    const endMs = dateTo ? new Date(`${dateTo}T23:59:59.999`).getTime() : null;
    return { startMs, endMs };
  }, [dateFrom, dateTo]);

  const isInRange = (isoDate?: string): boolean => {
    if (rangeBounds.startMs === null && rangeBounds.endMs === null) return true;
    if (!isoDate) return false;
    const ts = new Date(isoDate).getTime();
    if (Number.isNaN(ts)) return false;
    if (rangeBounds.startMs !== null && ts < rangeBounds.startMs) return false;
    if (rangeBounds.endMs !== null && ts > rangeBounds.endMs) return false;
    return true;
  };

  const analytics = useMemo(() => {
    const filteredUsers = users.filter((u) => isInRange(u.createdAt));
    const filteredAuctions = auctions.filter((a) => isInRange(a.createdAt || a.startDate));
    const filteredSettlements = settlements.filter((s) => isInRange(s.closedAt));
    const filteredPayments = payments.filter((p) => isInRange(p.timestamp));
    const filteredAds = adCampaigns.filter((c) => isInRange(c.createdAt));
    const filteredSellerProfiles = sellerProfiles.filter((p) => isInRange(p.submittedAt));

    // 1. Registered Users
    const registeredUsersCount = filteredUsers.length;
    const premiumUsersCount = filteredUsers.filter((u) => u.isPremium).length;

    // 2. Active Sellers (distinct sellers with listings, profiles, or sales in range)
    const activeSellerIds = new Set<string>();
    filteredAuctions.forEach((a) => {
      if (a.status === 'en_cours' || a.status === 'terminee' || a.status === 'en_attente') {
        activeSellerIds.add(a.sellerId);
      }
    });
    filteredSettlements.forEach((s) => activeSellerIds.add(s.sellerId));
    filteredSellerProfiles.forEach((p) => activeSellerIds.add(p.userId));
    filteredUsers.forEach((u) => {
      if (u.role === 'seller') activeSellerIds.add(u.id);
    });
    const verifiedSellersCount = sellerProfiles.filter(
      (p) => p.verificationStatus === 'verified'
    ).length;

    // 3. Current Auctions (en_cours & saleType !== 'prix_fixe')
    const currentAuctionsList = filteredAuctions.filter(
      (a) => a.status === 'en_cours' && a.saleType !== 'prix_fixe'
    );
    const activeFixedPriceCount = filteredAuctions.filter(
      (a) => a.status === 'en_cours' && a.saleType === 'prix_fixe'
    ).length;

    // 4. Completed Auctions (status === 'terminee' by endDate in range)
    const completedAuctionsList = auctions.filter(
      (a) => a.status === 'terminee' && a.saleType !== 'prix_fixe' && isInRange(a.endDate)
    );
    const completedFixedSalesCount = filteredSettlements.filter(
      (s) => s.saleType === 'prix_fixe'
    ).length;

    // 5. Total Sales Value (GMV)
    const settledAuctionIds = new Set(filteredSettlements.map((s) => s.auctionId));
    const settlementGmv = filteredSettlements.reduce((sum, s) => sum + s.winningBid, 0);
    const unsettledClosedAuctionsGmv = completedAuctionsList
      .filter((a) => !settledAuctionIds.has(a.id) && a.bidsCount > 0)
      .reduce((sum, a) => sum + a.currentPrice, 0);
    const totalSalesValueUsd = settlementGmv + unsettledClosedAuctionsGmv;

    // 6. Platform Revenue (Commissions + Fixed Buyer Fees + Premium Subscriptions + Ads/Sponsored)
    const commissionRevenueUsd = filteredSettlements.reduce(
      (sum, s) => sum + (s.commissionAmount || 0),
      0
    );
    const fixedFeeRevenueUsd = filteredSettlements.reduce(
      (sum, s) => sum + (s.buyerFeeUsd ?? s.fixedFee ?? 0),
      0
    );
    const subscriptionAndAdPaymentsUsd = filteredPayments
      .filter(
        (p) =>
          p.status === 'completed' &&
          (p.purpose === 'premium_subscription' ||
            p.purpose === 'ad_promotion' ||
            p.purpose === 'listing_fee')
      )
      .reduce((sum, p) => sum + p.amountUsd, 0);

    // Fallback if adCampaigns exist without a corresponding payment record
    const paidAdIds = new Set(
      filteredPayments
        .filter((p) => p.purpose === 'ad_promotion')
        .map((p) => p.auctionId || p.auctionTitle)
    );
    const extraAdRevenueUsd = filteredAds
      .filter((ad) => ad.status === 'active' && !paidAdIds.has(ad.auctionId || ad.title))
      .reduce((sum, ad) => sum + ad.amountUsd, 0);

    const platformRevenueUsd =
      commissionRevenueUsd +
      fixedFeeRevenueUsd +
      subscriptionAndAdPaymentsUsd +
      extraAdRevenueUsd;

    // Daily trend series for Recharts AreaChart
    const dailyMap = new Map<
      string,
      { dateKey: string; label: string; salesUsd: number; revenueUsd: number; count: number }
    >();

    const ensureBucket = (iso?: string) => {
      const d = iso ? new Date(iso) : new Date();
      const key = toDateInputValue(d);
      if (!dailyMap.has(key)) {
        dailyMap.set(key, {
          dateKey: key,
          label: d.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' }),
          salesUsd: 0,
          revenueUsd: 0,
          count: 0,
        });
      }
      return dailyMap.get(key)!;
    };

    filteredSettlements.forEach((s) => {
      const b = ensureBucket(s.closedAt);
      b.salesUsd += s.winningBid;
      b.revenueUsd += (s.commissionAmount || 0) + (s.buyerFeeUsd ?? s.fixedFee ?? 0);
      b.count += 1;
    });

    filteredPayments
      .filter(
        (p) =>
          p.status === 'completed' &&
          (p.purpose === 'premium_subscription' ||
            p.purpose === 'ad_promotion' ||
            p.purpose === 'listing_fee')
      )
      .forEach((p) => {
        const b = ensureBucket(p.timestamp);
        b.revenueUsd += p.amountUsd;
      });

    filteredAuctions.forEach((a) => {
      ensureBucket(a.createdAt || a.startDate);
    });

    const dailySeries = Array.from(dailyMap.values()).sort((a, b) =>
      a.dateKey.localeCompare(b.dateKey)
    );

    // Category distribution for Recharts BarChart
    const catMap = new Map<
      string,
      { category: string; listings: number; volumeUsd: number }
    >();
    filteredAuctions.forEach((a) => {
      const label = getCategoryLabel(a.category, language);
      const curr = catMap.get(label) || { category: label, listings: 0, volumeUsd: 0 };
      curr.listings += 1;
      curr.volumeUsd += a.saleType === 'prix_fixe' && a.fixedPrice ? a.fixedPrice : a.currentPrice;
      catMap.set(label, curr);
    });

    const categorySeries = Array.from(catMap.values())
      .sort((a, b) => b.volumeUsd - a.volumeUsd)
      .slice(0, 7);

    const hasAnyData =
      filteredUsers.length > 0 ||
      filteredAuctions.length > 0 ||
      filteredSettlements.length > 0 ||
      filteredPayments.length > 0;

    return {
      registeredUsersCount,
      premiumUsersCount,
      activeSellersCount: activeSellerIds.size,
      verifiedSellersCount,
      currentAuctionsCount: currentAuctionsList.length,
      activeFixedPriceCount,
      completedAuctionsCount: completedAuctionsList.length,
      completedFixedSalesCount,
      totalSalesValueUsd,
      platformRevenueUsd,
      commissionRevenueUsd,
      fixedFeeRevenueUsd,
      subscriptionAndAdRevenueUsd: subscriptionAndAdPaymentsUsd + extraAdRevenueUsd,
      dailySeries,
      categorySeries,
      hasAnyData,
    };
  }, [
    users,
    sellerProfiles,
    auctions,
    settlements,
    payments,
    adCampaigns,
    rangeBounds,
    language,
  ]);

  return (
    <div className="space-y-6">
      {/* Date Range Filter Toolbar */}
      <div className="bg-white rounded-xl border border-slate-200 p-4 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-lg bg-[#0B1F3A] text-amber-400 shrink-0">
            <Calendar className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-[#0B1F3A]">
              Période d’analyse des performances NgoluMarket
            </h2>
            <p className="text-[11px] text-slate-500">
              {dateFrom || dateTo
                ? `Filtre actif : ${dateFrom ? new Date(dateFrom).toLocaleDateString('fr-FR') : 'Début'} → ${dateTo ? new Date(dateTo).toLocaleDateString('fr-FR') : 'Aujourd’hui'}`
                : 'Affichage cumulé depuis le lancement de la plateforme'}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Quick Presets */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
            {(
              [
                { id: 'today', label: 'Aujourd’hui' },
                { id: '7d', label: '7 j' },
                { id: '30d', label: '30 j' },
                { id: '90d', label: '90 j' },
                { id: 'all', label: 'Tout' },
              ] as { id: DatePreset; label: string }[]
            ).map((btn) => (
              <button
                key={btn.id}
                type="button"
                onClick={() => applyPreset(btn.id)}
                className={`px-2.5 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                  preset === btn.id
                    ? 'bg-[#0B1F3A] text-white'
                    : 'text-slate-600 hover:text-[#0B1F3A]'
                }`}
              >
                {btn.label}
              </button>
            ))}
          </div>

          {/* Explicit Date Pickers */}
          <div className="flex items-center gap-1.5 text-xs">
            <label htmlFor="analytics-date-from" className="text-slate-500 font-medium whitespace-nowrap">
              Du
            </label>
            <input
              id="analytics-date-from"
              type="date"
              value={dateFrom}
              onChange={(e) => {
                setDateFrom(e.target.value);
                setPreset('custom');
              }}
              className="px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg font-mono text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-[#0B1F3A]"
            />
            <label htmlFor="analytics-date-to" className="text-slate-500 font-medium whitespace-nowrap">
              Au
            </label>
            <input
              id="analytics-date-to"
              type="date"
              value={dateTo}
              onChange={(e) => {
                setDateTo(e.target.value);
                setPreset('custom');
              }}
              className="px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg font-mono text-xs text-slate-800 focus:outline-none focus:ring-1 focus:ring-[#0B1F3A]"
            />
            {(dateFrom || dateTo) && (
              <button
                type="button"
                onClick={() => applyPreset('all')}
                className="px-2.5 py-1.5 text-xs font-semibold text-slate-600 hover:text-[#0B1F3A] bg-slate-100 hover:bg-slate-200 rounded-lg flex items-center gap-1 cursor-pointer whitespace-nowrap"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Réinitialiser
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Empty state if filtered range contains 0 records */}
      {!analytics.hasAnyData ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center space-y-3">
          <BarChart3 className="w-10 h-10 text-slate-300 mx-auto" />
          <h3 className="text-sm font-bold text-[#0B1F3A]">
            Aucune activité enregistrée sur cette plage de dates
          </h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            Aucun utilisateur, enchère ou règlement n’a été enregistré entre les dates sélectionnées.
          </p>
          <button
            type="button"
            onClick={() => applyPreset('all')}
            className="px-4 py-2 bg-[#0B1F3A] hover:bg-[#14325C] text-white text-xs font-bold rounded-lg cursor-pointer"
          >
            Afficher toutes les données
          </button>
        </div>
      ) : (
        <>
          {/* 6 Requested KPI Metric Cards (Clean 1px borders, tabular-nums, zero nested clutter) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {/* 1. Total Registered Users */}
            <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span className="font-semibold">Utilisateurs inscrits</span>
                <Users className="w-4 h-4 text-[#0B1F3A]" />
              </div>
              <div className="text-2xl font-bold text-[#0B1F3A] font-mono tabular-nums">
                {analytics.registeredUsersCount.toLocaleString('fr-FR')}
              </div>
              <div className="text-[11px] text-slate-500 flex items-center justify-between">
                <span>Total comptes sur la période</span>
                <span className="font-mono font-semibold text-amber-700">
                  {analytics.premiumUsersCount} Premium
                </span>
              </div>
            </div>

            {/* 2. Active Sellers */}
            <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span className="font-semibold">Vendeurs actifs</span>
                <UserCheck className="w-4 h-4 text-emerald-600" />
              </div>
              <div className="text-2xl font-bold text-[#0B1F3A] font-mono tabular-nums">
                {analytics.activeSellersCount.toLocaleString('fr-FR')}
              </div>
              <div className="text-[11px] text-slate-500 flex items-center justify-between">
                <span>Vendeurs avec activité</span>
                <span className="font-mono font-semibold text-emerald-700 flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" />
                  {analytics.verifiedSellersCount} vérifiés
                </span>
              </div>
            </div>

            {/* 3. Current Auctions */}
            <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span className="font-semibold">Enchères en cours</span>
                <Gavel className="w-4 h-4 text-amber-600" />
              </div>
              <div className="text-2xl font-bold text-amber-600 font-mono tabular-nums">
                {analytics.currentAuctionsCount.toLocaleString('fr-FR')}
              </div>
              <div className="text-[11px] text-slate-500 flex items-center justify-between">
                <span>Lots actifs aux enchères</span>
                <span className="font-mono font-semibold text-slate-700">
                  + {analytics.activeFixedPriceCount} prix fixe
                </span>
              </div>
            </div>

            {/* 4. Completed Auctions */}
            <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span className="font-semibold">Enchères terminées</span>
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              </div>
              <div className="text-2xl font-bold text-[#0B1F3A] font-mono tabular-nums">
                {analytics.completedAuctionsCount.toLocaleString('fr-FR')}
              </div>
              <div className="text-[11px] text-slate-500 flex items-center justify-between">
                <span>Adjudications clôturées</span>
                <span className="font-mono font-semibold text-slate-700">
                  + {analytics.completedFixedSalesCount} ventes fixes
                </span>
              </div>
            </div>

            {/* 5. Total Sales Value (GMV) */}
            <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span className="font-semibold">Valeur totale des ventes (GMV)</span>
                <TrendingUp className="w-4 h-4 text-[#0B1F3A]" />
              </div>
              <div className="text-2xl font-bold text-[#0B1F3A] font-mono tabular-nums">
                {formatUsd(analytics.totalSalesValueUsd)}
              </div>
              <div className="text-[11px] text-slate-500 font-mono tabular-nums">
                ≈ {(analytics.totalSalesValueUsd * settings.currencyRateCdf).toLocaleString('fr-FR')} CDF
              </div>
            </div>

            {/* 6. Platform Revenue */}
            <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-2">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span className="font-semibold">Revenus de la plateforme</span>
                <DollarSign className="w-4 h-4 text-emerald-600" />
              </div>
              <div className="text-2xl font-bold text-emerald-700 font-mono tabular-nums">
                {formatUsd(analytics.platformRevenueUsd)}
              </div>
              <div className="text-[11px] text-slate-500 font-mono truncate tabular-nums">
                Comm. {formatUsd(analytics.commissionRevenueUsd)} · Frais {formatUsd(analytics.fixedFeeRevenueUsd)} · Abo/Pub {formatUsd(analytics.subscriptionAndAdRevenueUsd)}
              </div>
            </div>
          </div>

          {/* Charts Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left Chart: Daily Sales & Platform Revenue */}
            <div className="lg:col-span-7 bg-white rounded-xl border border-slate-200 p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-bold text-[#0B1F3A] flex items-center gap-2">
                    <Activity className="w-4 h-4 text-amber-500" />
                    Volume des ventes & Revenus NgoluMarket (USD)
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Comparatif journalier entre la valeur brute vendue et les revenus nets perçus
                  </p>
                </div>
              </div>

              {analytics.dailySeries.length === 0 ? (
                <div className="h-64 flex items-center justify-center text-xs text-slate-400">
                  Aucune transaction sur cette plage de dates.
                </div>
              ) : (
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart
                      data={analytics.dailySeries}
                      margin={{ top: 10, right: 12, left: 0, bottom: 0 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                      <XAxis
                        dataKey="label"
                        tick={{ fontSize: 11, fill: '#64748B' }}
                        axisLine={{ stroke: '#CBD5E1' }}
                        tickLine={false}
                      />
                      <YAxis
                        tick={{ fontSize: 11, fill: '#64748B' }}
                        axisLine={false}
                        tickLine={false}
                        tickFormatter={(v) => `$${v}`}
                      />
                      <Tooltip
                        formatter={(value, name) => [
                          formatUsd(Number(value ?? 0)),
                          name === 'salesUsd' ? 'Ventes (GMV)' : 'Revenus Plateforme',
                        ]}
                        contentStyle={{
                          borderRadius: '8px',
                          borderColor: '#E2E8F0',
                          fontSize: '12px',
                        }}
                      />
                      <Area
                        type="monotone"
                        dataKey="salesUsd"
                        stroke="#0B1F3A"
                        fill="#0B1F3A"
                        fillOpacity={0.12}
                        strokeWidth={2}
                      />
                      <Area
                        type="monotone"
                        dataKey="revenueUsd"
                        stroke="#D97706"
                        fill="#F59E0B"
                        fillOpacity={0.2}
                        strokeWidth={2}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              )}
            </div>

            {/* Right Chart: Category Volume */}
            <div className="lg:col-span-5 bg-white rounded-xl border border-slate-200 p-5 space-y-4">
              <div>
                <h3 className="text-sm font-bold text-[#0B1F3A] flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-[#0B1F3A]" />
                  Catalogue actif par catégorie (USD)
                </h3>
                <p className="text-[11px] text-slate-500">
                  Répartition de la valeur des annonces sur la période sélectionnée
                </p>
              </div>

              {analytics.categorySeries.length === 0 ? (
                <div className="h-64 flex items-center justify-center text-xs text-slate-400">
                  Aucune annonce publiée sur cette plage de dates.
                </div>
              ) : (
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={analytics.categorySeries}
                      layout="vertical"
                      margin={{ top: 4, right: 16, left: 10, bottom: 0 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" horizontal={false} />
                      <XAxis
                        type="number"
                        tick={{ fontSize: 10, fill: '#64748B' }}
                        axisLine={false}
                        tickLine={false}
                        tickFormatter={(v) => `$${v}`}
                      />
                      <YAxis
                        type="category"
                        dataKey="category"
                        width={105}
                        tick={{ fontSize: 11, fill: '#334155' }}
                        axisLine={false}
                        tickLine={false}
                      />
                      <Tooltip
                        formatter={(value) => [formatUsd(Number(value ?? 0)), 'Valeur catalogue']}
                        contentStyle={{
                          borderRadius: '8px',
                          borderColor: '#E2E8F0',
                          fontSize: '12px',
                        }}
                      />
                      <Bar dataKey="volumeUsd" fill="#0B1F3A" radius={[0, 4, 4, 0]} barSize={16} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </div>
          </div>

          {/* Revenue Breakdown Strip */}
          <div className="bg-white rounded-xl border border-slate-200 p-5">
            <h3 className="text-sm font-bold text-[#0B1F3A] mb-3">
              Détail des sources de revenus sur la période
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50 text-slate-500 uppercase font-semibold text-[10px] border-b border-slate-200">
                  <tr>
                    <th className="py-2.5 px-3">Source de revenu</th>
                    <th className="py-2.5 px-3">Règle tarifaire NgoluMarket</th>
                    <th className="py-2.5 px-3 text-right">Montant USD</th>
                    <th className="py-2.5 px-3 text-right">Part du revenu</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  <tr>
                    <td className="py-3 px-3 font-semibold text-slate-900">
                      Commissions sur enchères
                    </td>
                    <td className="py-3 px-3 text-slate-500 font-mono">
                      {settings.commissionRatePercent}% sur prix final (vendeur)
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-[#0B1F3A] tabular-nums">
                      {formatUsd(analytics.commissionRevenueUsd)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono text-slate-600 tabular-nums">
                      {analytics.platformRevenueUsd > 0
                        ? `${Math.round((analytics.commissionRevenueUsd / analytics.platformRevenueUsd) * 100)}%`
                        : '0%'}
                    </td>
                  </tr>
                  <tr>
                    <td className="py-3 px-3 font-semibold text-slate-900">
                      Frais de plateforme (Ventes à prix fixe)
                    </td>
                    <td className="py-3 px-3 text-slate-500 font-mono">
                      {settings.fixedPriceBuyerFeeUsd ?? 1} USD / commande (acheteur)
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-[#0B1F3A] tabular-nums">
                      {formatUsd(analytics.fixedFeeRevenueUsd)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono text-slate-600 tabular-nums">
                      {analytics.platformRevenueUsd > 0
                        ? `${Math.round((analytics.fixedFeeRevenueUsd / analytics.platformRevenueUsd) * 100)}%`
                        : '0%'}
                    </td>
                  </tr>
                  <tr>
                    <td className="py-3 px-3 font-semibold text-slate-900">
                      Abonnements Vendeur Premium & Publicités
                    </td>
                    <td className="py-3 px-3 text-slate-500 font-mono">
                      {settings.premiumSubscriptionPriceUsd ?? 50} USD/trim · {settings.adMonthlyPriceUsd ?? 1} USD pub/sponsor
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-[#0B1F3A] tabular-nums">
                      {formatUsd(analytics.subscriptionAndAdRevenueUsd)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono text-slate-600 tabular-nums">
                      {analytics.platformRevenueUsd > 0
                        ? `${Math.round((analytics.subscriptionAndAdRevenueUsd / analytics.platformRevenueUsd) * 100)}%`
                        : '0%'}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
};
