import React from 'react';
import { Star } from 'lucide-react';

interface StarRatingProps {
  rating?: number;
  reviewsCount?: number;
  size?: 'sm' | 'md';
  showCount?: boolean;
}

export const StarRating: React.FC<StarRatingProps> = ({
  rating = 4.8,
  reviewsCount = 24,
  size = 'sm',
  showCount = true,
}) => {
  const clampedRating = Math.max(0, Math.min(5, rating));
  const fullStars = Math.floor(clampedRating);
  const hasHalfStar = clampedRating - fullStars >= 0.25 && clampedRating - fullStars < 0.75;
  const roundedUpExtra = clampedRating - fullStars >= 0.75 ? 1 : 0;
  const totalFull = fullStars + roundedUpExtra;

  const iconClass = size === 'md' ? 'w-4 h-4' : 'w-3.5 h-3.5';

  return (
    <div
      className="inline-flex items-center gap-1.5"
      title={`Note vendeur : ${clampedRating.toFixed(1)} sur 5 (${reviewsCount} avis)`}
    >
      <div className="flex items-center gap-0.5" aria-label={`Note ${clampedRating} sur 5`}>
        {[0, 1, 2, 3, 4].map((index) => {
          const isFull = index < totalFull;
          const isHalf = !isFull && index === fullStars && hasHalfStar;

          if (isFull) {
            return (
              <Star
                key={index}
                className={`${iconClass} fill-amber-400 text-amber-400`}
              />
            );
          }

          if (isHalf) {
            return (
              <span key={index} className={`relative inline-block ${iconClass}`}>
                <Star className={`${iconClass} text-slate-300 fill-slate-200`} />
                <span className="absolute inset-0 overflow-hidden w-1/2">
                  <Star className={`${iconClass} fill-amber-400 text-amber-400`} />
                </span>
              </span>
            );
          }

          return (
            <Star
              key={index}
              className={`${iconClass} text-slate-300 fill-slate-200`}
            />
          );
        })}
      </div>

      <span className="font-bold text-slate-900 font-mono text-[11px]">
        {clampedRating.toFixed(1)}
      </span>

      {showCount && (
        <span className="text-slate-500 text-[11px]">
          ({reviewsCount} avis)
        </span>
      )}
    </div>
  );
};
