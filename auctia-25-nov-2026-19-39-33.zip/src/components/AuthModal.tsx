import React, { useState } from 'react';
import {
  AlertCircle,
  Award,
  Lock,
  Mail,
  Phone,
  User as UserIcon,
  X,
  Zap,
} from 'lucide-react';
import { useAuctia } from '../context/AuctiaContext';
import { BankAggregatorId, PaymentMethod, PaymentProvider } from '../types';

interface AuthModalProps {
  onClose: () => void;
  defaultMode?: 'signin' | 'register';
  titleHint?: string;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  onClose,
  defaultMode = 'register',
  titleHint,
}) => {
  const { login, registerUser, registerSellerProfile, activatePremiumSubscription, aggregatorGateways, settings } = useAuctia();

  const [mode, setMode] = useState<'signin' | 'register'>(defaultMode);
  const [role, setRole] = useState<'buyer' | 'seller'>('seller'); // Dual account: buy & sell
  const [accountTier, setAccountTier] = useState<'normal' | 'premium'>('normal');
  const [premiumAggregator, setPremiumAggregator] = useState<BankAggregatorId>('ngolupay_hub');
  const [premiumMethod, setPremiumMethod] = useState<PaymentMethod>('mobile_money');
  const [premiumProvider, setPremiumProvider] = useState<PaymentProvider>('mpesa');
  const [premiumAccount, setPremiumAccount] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('+243 ');
  const [password, setPassword] = useState('');
  const [city, setCity] = useState('Kinshasa (Gombe)');
  const [companyName, setCompanyName] = useState('');
  const [loginIdentifier, setLoginIdentifier] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [error, setError] = useState<string | null>(null);

  const premiumPriceUsd = settings.premiumSubscriptionPriceUsd ?? 50;

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const fullName = [firstName.trim(), lastName.trim()].filter(Boolean).join(' ');
    if (!fullName) {
      setError('Veuillez renseigner votre prénom et votre nom.');
      return;
    }
    const cleanPhone = phone.replace(/\s+/g, '');
    if (!cleanPhone || cleanPhone === '+243' || cleanPhone.length < 8) {
      setError('Veuillez renseigner un numéro de téléphone RDC valide (+243...).');
      return;
    }

    const payAccount = premiumAccount.trim() || phone.trim();
    if (accountTier === 'premium' && payAccount.replace(/\s+/g, '').length < 6) {
      setError('Veuillez renseigner un numéro Mobile Money ou référence bancaire valide pour payer les 50 USD.');
      return;
    }

    setIsSubmitting(true);

    const newUser = registerUser({
      name: fullName,
      firstName: firstName.trim() || undefined,
      lastName: lastName.trim() || undefined,
      email: email.trim() || undefined,
      phone: phone.trim(),
      password: password || '123456',
      role,
      status: 'active',
      city,
      companyName: companyName.trim() || undefined,
      isPremium: false,
    });

    if (role === 'seller' || companyName.trim()) {
      registerSellerProfile({
        userId: newUser.id,
        companyName: companyName.trim() || fullName,
        rccmNumber: 'En attente de saisie',
        idNat: '',
        taxNumber: '',
        address: `${city}, Kinshasa`,
        city: 'Kinshasa',
        phone: phone.trim(),
      });
    }

    if (accountTier === 'premium') {
      const premRes = await activatePremiumSubscription({
        method: premiumMethod,
        provider: premiumProvider,
        aggregatorGateway: premiumAggregator,
        accountOrPhone: payAccount,
        userOverride: newUser,
      });
      if (!premRes.success) {
        setIsSubmitting(false);
        setError(
          premRes.error ||
            'Compte Normal créé, mais le paiement Premium (50 USD) a échoué. Vous pouvez réessayer depuis votre espace.'
        );
        return;
      }
    }

    setIsSubmitting(false);
    onClose();
  };

  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const result = login(loginIdentifier, loginPassword);
    if (!result.success) {
      setError(result.error || 'Identifiant ou mot de passe incorrect.');
    } else {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-[#071426]/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="relative w-full max-w-md bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 bg-[#0B1F3A] text-white">
          <div>
            <h3 className="text-base font-bold">
              {mode === 'register' ? 'Inscription Utilisateur NgoluMarket' : 'Connexion à votre espace'}
            </h3>
            <p className="text-xs text-slate-300">
              {titleHint || 'Ventes à prix fixe & enchères en ligne — Kinshasa, RDC'}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          {/* Mode Switcher Tabs */}
          <div className="flex border-b border-slate-200 text-xs">
            <button
              type="button"
              onClick={() => {
                setMode('register');
                setError(null);
              }}
              className={`flex-1 py-2.5 font-bold text-center border-b-2 transition-colors cursor-pointer ${
                mode === 'register'
                  ? 'border-[#0B1F3A] text-[#0B1F3A]'
                  : 'border-transparent text-slate-500 hover:text-slate-700'
              }`}
            >
              S’inscrire
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('signin');
                setError(null);
              }}
              className={`flex-1 py-2.5 font-bold text-center border-b-2 transition-colors cursor-pointer ${
                mode === 'signin'
                  ? 'border-[#0B1F3A] text-[#0B1F3A]'
                  : 'border-transparent text-slate-500 hover:text-slate-700'
              }`}
            >
              Se connecter
            </button>
          </div>

          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-rose-800 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {mode === 'signin' ? (
            <form onSubmit={handleSignIn} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Téléphone (+243...), e-mail ou nom
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="text"
                    required
                    placeholder="+243 81..., email@ngolumarket.cd ou nom"
                    value={loginIdentifier}
                    onChange={(e) => setLoginIdentifier(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#0B1F3A] font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Mot de passe
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="password"
                    placeholder="••••••••"
                    value={loginPassword}
                    onChange={(e) => setLoginPassword(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#0B1F3A]"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-[#0B1F3A] hover:bg-[#14325C] text-white font-bold rounded-lg text-xs transition-colors shadow-sm cursor-pointer"
              >
                Se connecter et continuer
              </button>

              <p className="text-center text-[11px] text-slate-500 pt-1">
                Pas encore de compte ?{' '}
                <button
                  type="button"
                  onClick={() => setMode('register')}
                  className="text-[#0B1F3A] font-bold underline ml-1 cursor-pointer"
                >
                  Inscrivez-vous directement
                </button>
              </p>
            </form>
          ) : (
            <form onSubmit={handleRegister} className="space-y-3">
              <div className="bg-amber-50/70 border border-amber-200/80 rounded-lg p-2.5 text-[11px] text-amber-900 flex items-start gap-2">
                <Zap className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                <span>
                  <strong>Compte mixte Acheteur & Vendeur :</strong> Achetez, participez gratuitement
                  aux enchères et publiez gratuitement vos annonces à prix fixe.
                </span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Type de compte :
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setAccountTier('normal')}
                    className={`p-2.5 rounded-lg border text-left text-xs transition-colors cursor-pointer ${
                      accountTier === 'normal'
                        ? 'border-[#0B1F3A] bg-[#0B1F3A] text-white shadow-xs'
                        : 'border-slate-200 text-slate-700 hover:border-slate-300'
                    }`}
                  >
                    <span className="font-bold block">Compte Normal · Gratuit</span>
                    <span className="text-[10px] opacity-80">
                      Acheter, enchérir & vendre à prix fixe
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setAccountTier('premium');
                      setRole('seller');
                    }}
                    className={`p-2.5 rounded-lg border text-left text-xs transition-colors cursor-pointer ${
                      accountTier === 'premium'
                        ? 'border-amber-500 bg-[#0B1F3A] text-amber-300 ring-1 ring-amber-400 shadow-xs'
                        : 'border-slate-200 text-slate-700 hover:border-amber-300'
                    }`}
                  >
                    <span className="font-bold flex items-center gap-1">
                      <Award className="w-3.5 h-3.5 text-amber-400" />
                      Compte Premium · {premiumPriceUsd}$
                    </span>
                    <span className="text-[10px] opacity-85 block text-slate-300">
                      {accountTier === 'premium'
                        ? 'Lancer des enchères (90 jours)'
                        : 'Publier aux enchères (50$/trim.)'}
                    </span>
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Profil principal :
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setRole('seller')}
                    className={`p-2 rounded-lg border text-left text-xs transition-colors cursor-pointer ${
                      role === 'seller'
                        ? 'border-[#0B1F3A] bg-slate-100 text-[#0B1F3A] font-semibold'
                        : 'border-slate-200 text-slate-600 hover:border-slate-300'
                    }`}
                  >
                    <span className="font-bold block">Acheter & Vendre</span>
                    <span className="text-[10px] opacity-80">
                      Publier annonces & enchérir
                    </span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setRole('buyer')}
                    className={`p-2 rounded-lg border text-left text-xs transition-colors cursor-pointer ${
                      role === 'buyer'
                        ? 'border-[#0B1F3A] bg-slate-100 text-[#0B1F3A] font-semibold'
                        : 'border-slate-200 text-slate-600 hover:border-slate-300'
                    }`}
                  >
                    <span className="font-bold block">Acheteur</span>
                    <span className="text-[10px] opacity-80">Commander & enchérir</span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Prénom *
                  </label>
                  <div className="relative">
                    <UserIcon className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="text"
                      required
                      placeholder="ex. Jean"
                      value={firstName}
                      onChange={(e) => setFirstName(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#0B1F3A] font-medium"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Nom *
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="ex. Mukendi"
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#0B1F3A] font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Numéro de Téléphone (+243) *
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="tel"
                    required
                    placeholder="+243 81 234 5678"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#0B1F3A] font-mono font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">
                  Adresse e-mail (optionnel)
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="email"
                    placeholder="vous@exemple.cd"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#0B1F3A]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Commune à Kinshasa
                  </label>
                  <select
                    value={city}
                    onChange={(e) => setCity(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg bg-white"
                  >
                    <option value="Kinshasa (Gombe)">Gombe</option>
                    <option value="Kinshasa (Ngaliema)">Ngaliema</option>
                    <option value="Kinshasa (Limete)">Limete</option>
                    <option value="Kinshasa (Kintambo)">Kintambo</option>
                    <option value="Kinshasa (Bandalungwa)">Bandalungwa</option>
                    <option value="Kinshasa (Mont-Ngafula)">Mont-Ngafula</option>
                    <option value="Kinshasa (Barumbu)">Barumbu</option>
                    <option value="Kinshasa (Lingwala)">Lingwala</option>
                    <option value="Kinshasa (Lemba)">Lemba</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Mot de passe *
                  </label>
                  <div className="relative">
                    <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="password"
                      required
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#0B1F3A]"
                    />
                  </div>
                </div>
              </div>

              {role === 'seller' && (
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">
                    Nom de votre boutique / enseigne (optionnel)
                  </label>
                  <input
                    type="text"
                    placeholder="ex. Okoko Motors ou Kinshasa Watch Club"
                    value={companyName}
                    onChange={(e) => setCompanyName(e.target.value)}
                    className="w-full px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#0B1F3A]"
                  />
                </div>
              )}

              {accountTier === 'premium' && (
                <div className="p-3 bg-[#0B1F3A] text-white rounded-xl border border-amber-400/40 space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-amber-300 flex items-center gap-1">
                      <Award className="w-3.5 h-3.5" />
                      Paiement Abonnement Premium ({premiumPriceUsd} USD)
                    </span>
                    <span className="font-mono text-[10px] text-slate-300">
                      {(premiumPriceUsd * (settings.currencyRateCdf || 2850)).toLocaleString('fr-FR')} CDF
                    </span>
                  </div>
                  <select
                    value={premiumAggregator}
                    onChange={(e) => setPremiumAggregator(e.target.value as BankAggregatorId)}
                    className="w-full px-2 py-1.5 rounded bg-[#14325C] border border-[#244B82] text-white text-[11px]"
                  >
                    {aggregatorGateways.filter((g) => g.enabled).map((gw) => (
                      <option key={gw.id} value={gw.id}>
                        Agrégateur : {gw.name}
                      </option>
                    ))}
                  </select>
                  <div className="grid grid-cols-2 gap-2">
                    <select
                      value={premiumMethod}
                      onChange={(e) => {
                        const m = e.target.value as PaymentMethod;
                        setPremiumMethod(m);
                        setPremiumProvider(
                          m === 'mobile_money'
                            ? 'mpesa'
                            : m === 'card'
                            ? 'visa_mastercard'
                            : 'rawbank_illicocash'
                        );
                      }}
                      className="px-2 py-1.5 rounded bg-[#14325C] border border-[#244B82] text-white text-[11px]"
                    >
                      <option value="mobile_money">Mobile Money</option>
                      <option value="card">Carte Visa/MC</option>
                      <option value="bank_transfer">Banques RDC</option>
                    </select>
                    <select
                      value={premiumProvider}
                      onChange={(e) => setPremiumProvider(e.target.value as PaymentProvider)}
                      className="px-2 py-1.5 rounded bg-[#14325C] border border-[#244B82] text-white text-[11px]"
                    >
                      {premiumMethod === 'mobile_money' && (
                        <>
                          <option value="mpesa">M-Pesa</option>
                          <option value="orange_money">Orange Money</option>
                          <option value="airtel_money">Airtel Money</option>
                          <option value="afrimoney">Afrimoney</option>
                        </>
                      )}
                      {premiumMethod === 'card' && (
                        <option value="visa_mastercard">Visa / Mastercard</option>
                      )}
                      {premiumMethod === 'bank_transfer' && (
                        <>
                          <option value="rawbank_illicocash">Rawbank (05100-...-44)</option>
                          <option value="equity_bcdc">Equity BCDC</option>
                          <option value="ecobank">Ecobank RDC</option>
                          <option value="tmb_pepele">TMB Pepele</option>
                          <option value="fbnbank_rdc">FBNBank DRC</option>
                          <option value="sofibanque">Sofibanque</option>
                          <option value="access_bank_rdc">Access Bank</option>
                        </>
                      )}
                    </select>
                  </div>
                  <input
                    type="text"
                    placeholder={
                      premiumMethod === 'mobile_money'
                        ? 'N° Mobile Money (sinon téléphone ci-dessus)'
                        : 'Référence carte ou virement bancaire'
                    }
                    value={premiumAccount}
                    onChange={(e) => setPremiumAccount(e.target.value)}
                    className="w-full px-2.5 py-1.5 rounded bg-[#14325C] border border-[#244B82] text-white font-mono text-[11px]"
                  />
                </div>
              )}

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-2.5 bg-[#0B1F3A] hover:bg-[#14325C] text-white font-bold rounded-lg text-xs transition-colors shadow-sm mt-1 cursor-pointer disabled:opacity-60"
              >
                {isSubmitting
                  ? 'Validation du compte...'
                  : accountTier === 'premium'
                  ? `Créer Compte Premium & Payer ${premiumPriceUsd}$`
                  : 'Créer mon Compte Normal (Gratuit)'}
              </button>

              <p className="text-center text-[10px] text-slate-400 leading-tight pt-1">
                Plateforme sécurisée NgoluMarket par FURAH Labs — Kinshasa, RDC.
              </p>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
