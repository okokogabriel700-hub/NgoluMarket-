import React, { useState } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  Bell,
  Check,
  CheckCircle2,
  Clock,
  ExternalLink,
  Phone,
  Settings,
  Smartphone,
  Trash2,
  Volume2,
  VolumeX,
  X,
} from 'lucide-react';
import { useAuctia } from '../context/AuctiaContext';
import { NotificationItem } from '../types';

interface NotificationsDrawerProps {
  onClose: () => void;
  onSelectAuctionId?: (auctionId: string) => void;
}

export const NotificationsDrawer: React.FC<NotificationsDrawerProps> = ({
  onClose,
  onSelectAuctionId,
}) => {
  const {
    currentUser,
    notifications,
    notificationPreferences,
    updateNotificationPreferences,
    markNotificationAsRead,
    clearAllNotifications,
    auctions,
  } = useAuctia();

  const [activeTab, setActiveTab] = useState<'in_app' | 'preferences'>('in_app');

  const myInAppNotifications = notifications.filter((n) =>
    currentUser ? n.userId === currentUser.id : true
  );

  const unreadCount = myInAppNotifications.filter((n) => !n.read).length;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-900/60 backdrop-blur-xs flex justify-end">
      <div className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col border-l border-slate-200 animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="p-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-slate-900 text-amber-400 rounded-lg">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-slate-900">Centre de Notifications</h2>
              <p className="text-[11px] text-slate-500 font-mono">
                {currentUser ? `${currentUser.name} · ${currentUser.phone}` : 'Visiteur public'}
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-200 rounded-lg cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switcher */}
        <div className="flex border-b border-slate-200 text-xs font-semibold">
          <button
            type="button"
            onClick={() => setActiveTab('in_app')}
            className={`flex-1 py-2.5 text-center border-b-2 transition-colors flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'in_app'
                ? 'border-slate-900 text-slate-900 bg-white'
                : 'border-transparent text-slate-500 hover:text-slate-800 bg-slate-50'
            }`}
          >
            <Bell className="w-3.5 h-3.5" />
            <span>En direct</span>
            {unreadCount > 0 && (
              <span className="bg-amber-500 text-slate-950 px-1.5 py-0.2 rounded-full text-[10px] font-bold">
                {unreadCount}
              </span>
            )}
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('preferences')}
            className={`flex-1 py-2.5 text-center border-b-2 transition-colors flex items-center justify-center gap-1.5 cursor-pointer ${
              activeTab === 'preferences'
                ? 'border-slate-900 text-slate-900 bg-white'
                : 'border-transparent text-slate-500 hover:text-slate-800 bg-slate-50'
            }`}
          >
            <Settings className="w-3.5 h-3.5" />
            <span>Préférences d'alerte</span>
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {/* TAB 1: IN-APP NOTIFICATIONS */}
          {activeTab === 'in_app' && (
            <>
              <div className="flex items-center justify-between pb-1">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                  Activités récentes
                </span>
                {unreadCount > 0 && (
                  <button
                    type="button"
                    onClick={clearAllNotifications}
                    className="text-[11px] text-amber-700 hover:underline font-medium cursor-pointer"
                  >
                    Tout marquer comme lu
                  </button>
                )}
              </div>

              {myInAppNotifications.length === 0 ? (
                <div className="text-center py-12 text-slate-400 text-xs">
                  Aucune notification pour l’instant. Placez une offre ou mettez un bien aux enchères pour recevoir des alertes !
                </div>
              ) : (
                <div className="space-y-2">
                  {myInAppNotifications.map((notif) => (
                    <div
                      key={notif.id}
                      onClick={() => {
                        markNotificationAsRead(notif.id);
                        if (notif.linkAuctionId && onSelectAuctionId) {
                          onSelectAuctionId(notif.linkAuctionId);
                          onClose();
                        }
                      }}
                      className={`p-3 rounded-xl border text-xs transition-all cursor-pointer ${
                        !notif.read
                          ? 'bg-amber-50/50 border-amber-200 shadow-xs'
                          : 'bg-white border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <div className="flex items-center gap-1.5 font-bold text-slate-900">
                          {notif.type === 'outbid' && (
                            <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                          )}
                          {notif.type === 'won' && (
                            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                          )}
                          {notif.type === 'approval' && (
                            <Check className="w-4 h-4 text-blue-600 shrink-0" />
                          )}
                          {notif.type === 'new_bid' && (
                            <Bell className="w-4 h-4 text-amber-600 shrink-0" />
                          )}
                          <span>{notif.title}</span>
                        </div>
                        <span className="text-[10px] text-slate-400 shrink-0">
                          {new Date(notif.timestamp).toLocaleTimeString('fr-FR', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                      </div>
                      <p className="text-slate-600 leading-relaxed">{notif.message}</p>
                      {notif.linkAuctionId && (
                        <div className="mt-2 text-[11px] font-semibold text-amber-700 flex items-center gap-1 hover:underline">
                          <span>Voir l'enchère concernée</span>
                          <ArrowRight className="w-3 h-3" />
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </>
          )}

          {/* TAB 2: PREFERENCES */}
          {activeTab === 'preferences' && (
            <div className="space-y-4 text-xs">
              <div>
                <h3 className="font-bold text-slate-900 text-sm">Paramètres des Alertes</h3>
                <p className="text-slate-500 text-[11px]">
                  Configurez vos alertes SMS (+243) et vos signaux en direct pour ne rater aucune enchère.
                </p>
              </div>

              {/* Channels */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                <span className="font-bold text-slate-900 block text-xs uppercase tracking-wide">
                  Canaux de réception
                </span>

                <div className="flex items-center justify-between">
                  <div>
                    <span className="font-semibold text-slate-800 block flex items-center gap-1.5">
                      <Smartphone className="w-3.5 h-3.5 text-slate-600" />
                      Alertes SMS directes RDC (+243)
                    </span>
                    <span className="text-[11px] text-slate-500 font-mono">
                      {currentUser?.phone || '+243 ...'}
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={notificationPreferences.smsNotifications}
                    onChange={(e) =>
                      updateNotificationPreferences({ smsNotifications: e.target.checked })
                    }
                    className="w-4 h-4 rounded text-slate-900"
                  />
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-200">
                  <div>
                    <span className="font-semibold text-slate-800 block">
                      Notifications instantanées à l’écran
                    </span>
                    <span className="text-[11px] text-slate-500">
                      Bannières et compteurs d'offres en direct
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={notificationPreferences.inAppNotifications}
                    onChange={(e) =>
                      updateNotificationPreferences({ inAppNotifications: e.target.checked })
                    }
                    className="w-4 h-4 rounded text-slate-900"
                  />
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-200">
                  <div>
                    <span className="font-semibold text-slate-800 block">Signal sonore en direct</span>
                    <span className="text-[11px] text-slate-500">
                      Carillon discret lors d’une nouvelle offre ou surenchère
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={notificationPreferences.audioChimeEnabled}
                    onChange={(e) =>
                      updateNotificationPreferences({ audioChimeEnabled: e.target.checked })
                    }
                    className="w-4 h-4 rounded text-slate-900"
                  />
                </div>
              </div>

              {/* Trigger Events */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                <span className="font-bold text-slate-900 block text-xs uppercase tracking-wide">
                  Événements déclencheurs
                </span>

                <div className="flex items-center justify-between">
                  <div>
                    <span className="font-semibold text-slate-800 block">Alerte Surenchère</span>
                    <span className="text-[11px] text-slate-500">
                      Dès qu’une offre supérieure à la vôtre est validée
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={notificationPreferences.notifyOnOutbid}
                    onChange={(e) =>
                      updateNotificationPreferences({ notifyOnOutbid: e.target.checked })
                    }
                    className="w-4 h-4 rounded text-slate-900"
                  />
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-200">
                  <div>
                    <span className="font-semibold text-slate-800 block">Rappel de fin prochaine</span>
                    <span className="text-[11px] text-slate-500">
                      15 minutes avant la clôture d’une enchère suivie
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={notificationPreferences.notifyOnEndingSoon}
                    onChange={(e) =>
                      updateNotificationPreferences({ notifyOnEndingSoon: e.target.checked })
                    }
                    className="w-4 h-4 rounded text-slate-900"
                  />
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-200">
                  <div>
                    <span className="font-semibold text-slate-800 block">Résultat & Adjudication</span>
                    <span className="text-[11px] text-slate-500">
                      Notification immédiate si vous remportez l'enchère
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={notificationPreferences.notifyOnWon}
                    onChange={(e) => updateNotificationPreferences({ notifyOnWon: e.target.checked })}
                    className="w-4 h-4 rounded text-slate-900"
                  />
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-200">
                  <div>
                    <span className="font-semibold text-slate-800 block">
                      Nouvelle offre sur mon bien
                    </span>
                    <span className="text-[11px] text-slate-500">
                      Avertissement instantané dès qu'un acheteur surenchérit sur votre bien
                    </span>
                  </div>
                  <input
                    type="checkbox"
                    checked={notificationPreferences.notifyOnNewBidOnMyItem}
                    onChange={(e) =>
                      updateNotificationPreferences({ notifyOnNewBidOnMyItem: e.target.checked })
                    }
                    className="w-4 h-4 rounded text-slate-900"
                  />
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
