import React, { useEffect, useState } from 'react';
import { Award, Clock, Heart, MapPin, ShieldCheck, Sparkles, Star } from 'lucide-react';
import { useAuctia } from '../context/AuctiaContext';
import { AuctionItem } from '../types';
import { calculateTimeRemaining, formatCdf, formatUsd, getCategoryLabel, getStatusLabel } from '../utils/formatters';
import { t } from '../utils/i18n';

interface AuctionCardProps {
  item: AuctionItem;
  onSelect: (item: AuctionItem) => void;
}

export const AuctionCard: React.FC<AuctionCardProps> = ({ item, onSelect }) => {
  const { watchlist, toggleWatchlist, settings, language, sellerProfiles } = useAuctia();
  const isWatched = watchlist.includes(item.id);
  const sellerProfile = sellerProfiles.find((p) => p.userId === item.sellerId);
  const isSellerVerified = sellerProfile
    ? sellerProfile.verificationStatus === 'verified'
    : item.sellerVerified;

  // Live timer tick
  const [timeInfo, setTimeInfo] = useState(() =>
    calculateTimeRemaining(item.endDate, item.startDate, item.status, language)
  );

  useEffect(() => {
    setTimeInfo(calculateTimeRemaining(item.endDate, item.startDate, item.status, language));
    const timer = setInterval(() => {
      setTimeInfo(calculateTimeRemaining(item.endDate, item.startDate, item.status, language));
    }, 1000);
    return () => clearInterval(timer);
  }, [item.endDate, item.startDate, item.status, language]);

  const statusInfo = getStatusLabel(item.status, language);
  const displayPrice = item.saleType === 'prix_fixe' && item.fixedPrice ? item.fixedPrice : item.currentPrice;

  return (
    <div
      onClick={() => onSelect(item)}
      className={`group flex flex-col bg-white rounded-xl border transition-all duration-200 cursor-pointer overflow-hidden shadow-xs hover:shadow-md ${
        item.isSponsored ? 'border-amber-400 ring-1 ring-amber-300/60' : 'border-slate-200/90 hover:border-[#0B1F3A]/40'
      }`}
    >
      {/* Visual Asset Container */}
      <div className="relative aspect-[4/3] w-full bg-slate-100 overflow-hidden">
        <img
          src={item.images[0]}
          alt={item.title}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover group-hover:scale-[1.02] transition-transform duration-300"
        />

        {/* Watchlist toggle */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            toggleWatchlist(item.id);
          }}
          aria-label={isWatched ? 'Retirer des favoris' : 'Ajouter aux favoris'}
          className={`absolute top-3 right-3 p-2 rounded-full backdrop-blur-md transition-colors ${
            isWatched
              ? 'bg-rose-500 text-white shadow-sm'
              : 'bg-black/30 hover:bg-black/50 text-white'
          }`}
        >
          <Heart className={`w-4 h-4 ${isWatched ? 'fill-current' : ''}`} />
        </button>

        {/* Sale type & Sponsored badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-1 items-start">
          {item.saleType === 'prix_fixe' ? (
            <div className="bg-emerald-600/95 backdrop-blur-md text-white text-[11px] font-bold px-2.5 py-1 rounded shadow-sm">
              {t(language, 'fixedPriceOnly')}
            </div>
          ) : (
            <div className="bg-[#0B1F3A]/90 backdrop-blur-md text-amber-300 text-[11px] font-bold px-2.5 py-1 rounded shadow-sm">
              {t(language, 'auctionsOnly')}
            </div>
          )}

          {item.isSponsored && (
            <div className="bg-amber-400 text-[#0B1F3A] text-[10px] font-extrabold px-2 py-0.5 rounded shadow-sm flex items-center gap-1 uppercase tracking-wider">
              <Sparkles className="w-3 h-3" />
              {t(language, 'sponsored')}
            </div>
          )}

          {item.status !== 'en_cours' && (
            <div className="bg-[#0B1F3A]/90 backdrop-blur-md text-white text-[10px] px-2 py-0.5 rounded">
              {statusInfo.label}
            </div>
          )}
        </div>

        {/* Live timer strip inside bottom of media */}
        {item.status === 'en_cours' && (
          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/75 via-black/30 to-transparent p-3 pt-6 flex items-center justify-between text-white text-xs">
            {item.saleType === 'prix_fixe' ? (
              <div className="flex items-center gap-1.5 font-medium text-emerald-300">
                <span>{t(language, 'instantAvailability')}</span>
              </div>
            ) : (
              <div className="flex items-center gap-1.5 font-mono tabular-nums text-amber-300 font-medium">
                <Clock className="w-3.5 h-3.5" />
                <span>{timeInfo.text}</span>
              </div>
            )}
            <span className="text-[11px] text-slate-200 font-normal">
              {item.saleType === 'prix_fixe'
                ? t(language, 'buyerFeeShort', { fee: settings.fixedPriceBuyerFeeUsd ?? 1 })
                : `${item.bidsCount} ${
                    item.bidsCount === 1 ? t(language, 'bidSingular') : t(language, 'bidPlural')
                  }`}
            </span>
          </div>
        )}
      </div>

      {/* Card Content & Metadata */}
      <div className="flex flex-col flex-1 p-4.5 gap-2.5">
        <div className="flex items-center gap-2 text-xs text-slate-500 flex-wrap">
          <span className="font-semibold text-[#0B1F3A]">{getCategoryLabel(item.category, language)}</span>
          <span aria-hidden="true">·</span>
          <span className="flex items-center gap-1">
            <MapPin className="w-3 h-3 text-slate-400" />
            {item.location.commune}
          </span>
          <span aria-hidden="true">·</span>
          <span className="inline-flex items-center gap-0.5 font-mono font-bold text-slate-700">
            <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
            {(item.sellerRating ?? 4.8).toFixed(1)}
          </span>
          {item.sellerIsPremium && (
            <>
              <span aria-hidden="true">·</span>
              <span className="flex items-center gap-0.5 text-amber-700 font-semibold">
                <Award className="w-3 h-3 text-amber-600" />
                Pro
              </span>
            </>
          )}
          {isSellerVerified && !item.sellerIsPremium && (
            <>
              <span aria-hidden="true">·</span>
              <span className="flex items-center gap-0.5 text-emerald-700 font-medium">
                <ShieldCheck className="w-3 h-3 text-emerald-600" />
                {t(language, 'verifiedBadge')}
              </span>
            </>
          )}
        </div>

        {/* Title */}
        <h3 className="text-base font-semibold text-slate-900 line-clamp-2 leading-snug group-hover:text-[#0B1F3A] transition-colors">
          {item.title}
        </h3>

        {/* Pricing Area */}
        <div className="mt-auto pt-2 border-t border-slate-100 flex items-baseline justify-between">
          <div>
            <div className="text-[11px] text-slate-400 uppercase tracking-wide">
              {item.saleType === 'prix_fixe'
                ? t(language, 'fixedPriceLabel')
                : item.bidsCount > 0
                ? t(language, 'currentBidLabel')
                : t(language, 'startPriceLabel')}
            </div>
            <div className="text-lg font-bold font-mono tabular-nums text-[#0B1F3A]">
              {formatUsd(displayPrice)}
            </div>
            <div className="text-[11px] text-slate-400 font-mono tabular-nums">
              ≈ {formatCdf(displayPrice, settings.currencyRateCdf)}
            </div>
          </div>

          <button
            type="button"
            className="px-3 py-1.5 text-xs font-semibold text-white bg-[#0B1F3A] group-hover:bg-amber-400 group-hover:text-[#0B1F3A] rounded-lg transition-colors whitespace-nowrap"
          >
            {item.status === 'terminee'
              ? t(language, 'consult')
              : item.saleType === 'prix_fixe'
              ? t(language, 'buyNow')
              : t(language, 'placeBid')}
          </button>
        </div>
      </div>
    </div>
  );
};
