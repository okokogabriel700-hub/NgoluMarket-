import React from 'react';
import { Building, CheckCircle2, CreditCard, Landmark, Network, Smartphone } from 'lucide-react';
import { useAuctia } from '../context/AuctiaContext';
import {
  BankAggregatorId,
  BankProvider,
  PaymentMethod,
  PaymentProvider,
} from '../types';

interface BankingAggregatorSelectorProps {
  aggregatorGateway: BankAggregatorId;
  onChangeAggregator: (id: BankAggregatorId) => void;
  method: PaymentMethod;
  onChangeMethod: (method: PaymentMethod) => void;
  provider: PaymentProvider;
  onChangeProvider: (provider: PaymentProvider) => void;
  variant?: 'dark' | 'light';
  showBeneficiaryBox?: boolean;
}

const MOBILE_MONEY_OPERATORS: { id: PaymentProvider; name: string; sub: string }[] = [
  { id: 'mpesa', name: 'M-Pesa (Vodacom RDC)', sub: '081 / 082' },
  { id: 'orange_money', name: 'Orange Money RDC', sub: '084 / 085 / 089' },
  { id: 'airtel_money', name: 'Airtel Money RDC', sub: '097 / 099' },
  { id: 'afrimoney', name: 'Afrimoney (Africell)', sub: '090 (Africell)' },
];

export const BankingAggregatorSelector: React.FC<BankingAggregatorSelectorProps> = ({
  aggregatorGateway,
  onChangeAggregator,
  method,
  onChangeMethod,
  provider,
  onChangeProvider,
  variant = 'light',
  showBeneficiaryBox = true,
}) => {
  const { aggregatorGateways, connectedBanks } = useAuctia();

  const activeGateways = aggregatorGateways.filter((g) => g.enabled);
  const selectedGw =
    aggregatorGateways.find((g) => g.id === aggregatorGateway) || aggregatorGateways[0];

  const availableBanks = connectedBanks.filter(
    (b) => !selectedGw || selectedGw.connectedBanks.includes(b.id as BankProvider)
  );

  const isDark = variant === 'dark';

  const handleAggregatorPick = (gwId: BankAggregatorId) => {
    onChangeAggregator(gwId);
    const gw = aggregatorGateways.find((g) => g.id === gwId);
    if (gw && !gw.supportedMethods.includes(method)) {
      const nextMethod = gw.supportedMethods[0] || 'bank_transfer';
      onChangeMethod(nextMethod);
      if (nextMethod === 'bank_transfer') {
        onChangeProvider((gw.connectedBanks[0] as PaymentProvider) || 'rawbank_illicocash');
      } else if (nextMethod === 'card') {
        onChangeProvider('visa_mastercard');
      } else {
        onChangeProvider('mpesa');
      }
    } else if (gw && method === 'bank_transfer' && !gw.connectedBanks.includes(provider as BankProvider)) {
      onChangeProvider((gw.connectedBanks[0] as PaymentProvider) || 'rawbank_illicocash');
    }
  };

  return (
    <div className="space-y-3.5 text-xs">
      {/* Official NgoluMarket Corporate Escrow Coordinates */}
      {showBeneficiaryBox && (
        <div
          className={`p-3.5 rounded-xl border space-y-2 ${
            isDark
              ? 'bg-slate-800/95 border-amber-500/40'
              : 'bg-slate-50 border-slate-200'
          }`}
        >
          <div
            className={`flex items-center justify-between border-b pb-2 ${
              isDark ? 'border-slate-700/70' : 'border-slate-200'
            }`}
          >
            <span
              className={`font-bold flex items-center gap-1.5 ${
                isDark ? 'text-amber-300' : 'text-[#0B1F3A]'
              }`}
            >
              <Building className="w-4 h-4 text-amber-500 shrink-0" />
              Compte Séquestre Officiel NgoluMarket
            </span>
            <span
              className={`text-[10px] font-bold px-2 py-0.5 rounded font-mono ${
                isDark
                  ? 'bg-amber-500/20 text-amber-300'
                  : 'bg-[#0B1F3A] text-amber-300'
              }`}
            >
              Agrégateur Bancaire RDC
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] font-mono">
            <div>
              <span className={`block text-[10px] font-sans ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                Bénéficiaire
              </span>
              <span className={`font-bold ${isDark ? 'text-white' : 'text-[#0B1F3A]'}`}>
                NGOLUMARKET SAS
              </span>
            </div>
            <div>
              <span className={`block text-[10px] font-sans ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                Banque Séquestre
              </span>
              <span className={`font-semibold ${isDark ? 'text-white' : 'text-slate-800'}`}>
                RAWBANK (Gombe)
              </span>
            </div>
            <div>
              <span className={`block text-[10px] font-sans ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                N° Compte / RIB
              </span>
              <span className={`font-bold tracking-wider ${isDark ? 'text-amber-300' : 'text-[#0B1F3A]'}`}>
                05100-01234567890-44
              </span>
            </div>
            <div>
              <span className={`block text-[10px] font-sans ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                SWIFT / Marchand
              </span>
              <span className={`font-bold ${isDark ? 'text-amber-300' : 'text-amber-700'}`}>
                RAWBCDKI · 882010
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Banking Aggregator Gateway Selector */}
      <div>
        <div className="flex items-center justify-between mb-1.5">
          <label
            className={`font-bold flex items-center gap-1.5 ${
              isDark ? 'text-slate-200' : 'text-[#0B1F3A]'
            }`}
          >
            <Network className="w-3.5 h-3.5 text-amber-500" />
            Agrégateur Bancaire & Routeur de Compensation
          </label>
          <span
            className={`text-[10px] font-mono font-semibold ${
              isDark ? 'text-emerald-300' : 'text-emerald-700'
            }`}
          >
            {activeGateways.length} passerelle(s) actives
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {aggregatorGateways.map((gw) => {
            const isSelected = aggregatorGateway === gw.id;
            return (
              <button
                key={gw.id}
                type="button"
                disabled={!gw.enabled}
                onClick={() => handleAggregatorPick(gw.id)}
                className={`p-2.5 rounded-xl border text-left transition-all cursor-pointer disabled:opacity-45 disabled:cursor-not-allowed ${
                  isSelected
                    ? isDark
                      ? 'border-amber-400 bg-amber-500/15 text-white ring-1 ring-amber-400/50'
                      : 'border-[#0B1F3A] bg-[#0B1F3A] text-white ring-1 ring-[#0B1F3A]'
                    : isDark
                    ? 'border-slate-700 bg-slate-800/80 text-slate-300 hover:border-slate-500'
                    : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                }`}
              >
                <div className="flex items-center justify-between gap-1">
                  <span className="font-bold text-[11px] truncate">{gw.name}</span>
                  {isSelected ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                  ) : (
                    <span
                      className={`text-[9px] px-1.5 py-0.5 rounded font-mono font-bold ${
                        gw.enabled
                          ? isDark
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : 'bg-emerald-50 text-emerald-700'
                          : 'bg-rose-100 text-rose-700'
                      }`}
                    >
                      {gw.enabled ? 'ACTIF' : 'PAUSE'}
                    </span>
                  )}
                </div>
                <p
                  className={`text-[10px] mt-0.5 line-clamp-1 ${
                    isSelected
                      ? 'text-slate-300'
                      : isDark
                      ? 'text-slate-400'
                      : 'text-slate-500'
                  }`}
                >
                  {gw.settlementRail}
                </p>
                <div className="flex items-center justify-between mt-1.5 text-[9px] font-mono opacity-85">
                  <span>{gw.connectedBanks.length} banques RDC</span>
                  <span>{gw.clearingDelay}</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Payment Rail Tabs */}
      <div>
        <label
          className={`block font-medium mb-1.5 ${
            isDark ? 'text-slate-300' : 'text-slate-700'
          }`}
        >
          Canal de règlement via l’agrégateur
        </label>
        <div className="grid grid-cols-3 gap-2">
          <button
            type="button"
            onClick={() => {
              onChangeMethod('bank_transfer');
              const firstBank = (availableBanks[0]?.id as PaymentProvider) || 'rawbank_illicocash';
              onChangeProvider(firstBank);
            }}
            className={`p-2 rounded-xl border font-bold flex flex-col sm:flex-row items-center justify-center gap-1.5 cursor-pointer transition-colors ${
              method === 'bank_transfer'
                ? isDark
                  ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                  : 'bg-[#0B1F3A] text-white border-[#0B1F3A]'
                : isDark
                ? 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-750'
                : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
            }`}
          >
            <Landmark className="w-4 h-4 shrink-0" />
            <span>Banques RDC</span>
          </button>

          <button
            type="button"
            onClick={() => {
              onChangeMethod('mobile_money');
              onChangeProvider('mpesa');
            }}
            className={`p-2 rounded-xl border font-bold flex flex-col sm:flex-row items-center justify-center gap-1.5 cursor-pointer transition-colors ${
              method === 'mobile_money'
                ? isDark
                  ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                  : 'bg-[#0B1F3A] text-white border-[#0B1F3A]'
                : isDark
                ? 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-750'
                : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
            }`}
          >
            <Smartphone className="w-4 h-4 shrink-0" />
            <span>Mobile Money</span>
          </button>

          <button
            type="button"
            onClick={() => {
              onChangeMethod('card');
              onChangeProvider('visa_mastercard');
            }}
            className={`p-2 rounded-xl border font-bold flex flex-col sm:flex-row items-center justify-center gap-1.5 cursor-pointer transition-colors ${
              method === 'card'
                ? isDark
                  ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                  : 'bg-[#0B1F3A] text-white border-[#0B1F3A]'
                : isDark
                ? 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-750'
                : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-50'
            }`}
          >
            <CreditCard className="w-4 h-4 shrink-0" />
            <span>Visa / MC</span>
          </button>
        </div>
      </div>

      {/* Connected Bank Matrix */}
      {method === 'bank_transfer' && (
        <div>
          <label
            className={`block text-[11px] font-medium mb-1.5 ${
              isDark ? 'text-slate-400' : 'text-slate-600'
            }`}
          >
            Banque émettrice connectée à l’agrégateur ({availableBanks.length} banques)
          </label>
          <div className="grid grid-cols-2 gap-2">
            {availableBanks.map((bank) => {
              const isSelected = provider === bank.id;
              return (
                <button
                  key={bank.id}
                  type="button"
                  onClick={() => onChangeProvider(bank.id)}
                  className={`p-2 rounded-lg border text-left transition-colors cursor-pointer ${
                    isSelected
                      ? isDark
                        ? 'border-amber-400 bg-amber-500/15 text-white'
                        : 'border-[#0B1F3A] bg-blue-50/70 text-[#0B1F3A] ring-1 ring-[#0B1F3A]'
                      : isDark
                      ? 'border-slate-700 bg-slate-800/60 text-slate-300 hover:border-slate-600'
                      : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                  }`}
                >
                  <div className="font-bold text-[11px] truncate">{bank.shortName}</div>
                  <div
                    className={`text-[10px] font-mono truncate ${
                      isDark ? 'text-slate-400' : 'text-slate-500'
                    }`}
                  >
                    SWIFT: {bank.swiftCode} · {bank.settlementDelay}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Mobile Money Matrix */}
      {method === 'mobile_money' && (
        <div>
          <label
            className={`block text-[11px] font-medium mb-1.5 ${
              isDark ? 'text-slate-400' : 'text-slate-600'
            }`}
          >
            Opérateur Mobile Money RDC (routé par {selectedGw?.name})
          </label>
          <div className="grid grid-cols-2 gap-2">
            {MOBILE_MONEY_OPERATORS.map((op) => {
              const isSelected = provider === op.id;
              return (
                <button
                  key={op.id}
                  type="button"
                  onClick={() => onChangeProvider(op.id)}
                  className={`p-2 rounded-lg border text-left transition-colors cursor-pointer ${
                    isSelected
                      ? isDark
                        ? 'border-amber-400 bg-amber-500/15 text-white'
                        : 'border-[#0B1F3A] bg-blue-50/70 text-[#0B1F3A] ring-1 ring-[#0B1F3A]'
                      : isDark
                      ? 'border-slate-700 bg-slate-800/60 text-slate-300 hover:border-slate-600'
                      : 'border-slate-200 bg-white text-slate-700 hover:border-slate-300'
                  }`}
                >
                  <div className="font-bold text-[11px]">{op.name}</div>
                  <div className={`text-[10px] font-mono ${isDark ? 'text-slate-400' : 'text-slate-500'}`}>
                    Préfixes : {op.sub}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
