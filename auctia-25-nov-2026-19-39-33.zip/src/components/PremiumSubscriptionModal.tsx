import React, { useState } from 'react';
import {
  AlertCircle,
  Award,
  Check,
  CheckCircle2,
  ShieldCheck,
  X,
} from 'lucide-react';
import { useAuctia } from '../context/AuctiaContext';
import { BankAggregatorId, PaymentMethod, PaymentProvider, PaymentTransaction } from '../types';
import { formatUsd } from '../utils/formatters';
import { BankingAggregatorSelector } from './BankingAggregatorSelector';

interface PremiumSubscriptionModalProps {
  onClose: () => void;
  onOpenAuth?: () => void;
}

export const PremiumSubscriptionModal: React.FC<PremiumSubscriptionModalProps> = ({
  onClose,
  onOpenAuth,
}) => {
  const { currentUser, settings, activatePremiumSubscription } = useAuctia();

  const priceUsd = settings.premiumSubscriptionPriceUsd ?? 50;
  const exchangeRate = settings.currencyRateCdf || 2850;
  const priceCdf = Math.round(priceUsd * exchangeRate);

  const [aggregatorGateway, setAggregatorGateway] = useState<BankAggregatorId>('ngolupay_hub');
  const [method, setMethod] = useState<PaymentMethod>('bank_transfer');
  const [provider, setProvider] = useState<PaymentProvider>('rawbank_illicocash');
  const [accountOrPhone, setAccountOrPhone] = useState(currentUser?.phone || '+243 ');
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [receipt, setReceipt] = useState<PaymentTransaction | null>(null);

  const handleMethodChange = (nextMethod: PaymentMethod) => {
    setMethod(nextMethod);
    if (nextMethod === 'mobile_money') {
      setProvider('mpesa');
      setAccountOrPhone(currentUser?.phone || '+243 ');
    } else if (nextMethod === 'card') {
      setProvider('visa_mastercard');
      setAccountOrPhone('');
    } else {
      setProvider('rawbank_illicocash');
      setAccountOrPhone('05100-');
    }
  };

  const handleConfirmPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!currentUser) {
      onClose();
      onOpenAuth?.();
      return;
    }

    if (!accountOrPhone.trim() || accountOrPhone.trim().length < 6) {
      setError('Veuillez saisir un numéro Mobile Money, compte bancaire ou référence carte valide.');
      return;
    }

    setIsProcessing(true);
    const res = await activatePremiumSubscription({
      method,
      provider,
      aggregatorGateway,
      accountOrPhone: accountOrPhone.trim(),
    });
    setIsProcessing(false);

    if (!res.success) {
      setError(res.error || 'Échec lors du paiement de l’abonnement Premium.');
      return;
    }

    if (res.transaction) {
      setReceipt(res.transaction);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-[#071426]/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-6">
      <div className="relative w-full max-w-3xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="p-5 border-b border-[#163254] bg-[#0B1F3A] text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-amber-400 text-[#0B1F3A]">
              <Award className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">
                Compte Normal vs Compte Premium NgoluMarket
              </h2>
              <p className="text-xs text-slate-300">
                Passez au Compte Premium pour {formatUsd(priceUsd)} / trimestre (90 jours) via l’Agrégateur Bancaire
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-slate-300 hover:text-white hover:bg-white/10 rounded-lg cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Active status banner */}
          {currentUser && (
            <div
              className={`p-4 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs ${
                currentUser.isPremium
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-900'
                  : 'bg-slate-50 border-slate-200 text-slate-800'
              }`}
            >
              <div className="flex items-center gap-2.5">
                {currentUser.isPremium ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                ) : (
                  <ShieldCheck className="w-5 h-5 text-[#0B1F3A] shrink-0" />
                )}
                <div>
                  <span className="font-bold text-sm block">
                    Votre statut actuel :{' '}
                    {currentUser.isPremium ? 'Compte Premium PRO Actif' : 'Compte Normal (Gratuit)'}
                  </span>
                  <span className="text-[11px] opacity-85">
                    {currentUser.isPremium
                      ? `Actif jusqu'au ${
                          currentUser.premiumExpiresAt
                            ? new Date(currentUser.premiumExpiresAt).toLocaleDateString('fr-FR')
                            : '90 jours'
                        }. Vous pouvez prolonger de +90 jours pour ${formatUsd(priceUsd)}.`
                      : `Passez Premium pour ${formatUsd(priceUsd)} afin de publier des ventes aux enchères en temps réel.`}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Plan Comparison Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            {/* Compte Normal */}
            <div
              className={`p-5 rounded-xl border space-y-3 ${
                !currentUser?.isPremium
                  ? 'border-[#0B1F3A] bg-slate-50/70'
                  : 'border-slate-200 bg-white'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-sm text-[#0B1F3A]">Compte Normal</span>
                <span className="font-mono font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded border border-emerald-200">
                  Gratuit (0 $)
                </span>
              </div>
              <ul className="space-y-2 text-slate-600">
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span>Acheter des produits à prix fixe (frais acheteur {settings.fixedPriceBuyerFeeUsd ?? 1} USD)</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span>Participer gratuitement aux enchères en direct</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span>Vendre gratuitement des produits à prix fixe</span>
                </li>
                <li className="flex items-start gap-2 text-slate-400">
                  <X className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                  <span>Publication de ventes aux enchères non incluse</span>
                </li>
              </ul>
            </div>

            {/* Compte Premium */}
            <div className="p-5 rounded-xl border-2 border-amber-400 bg-[#0B1F3A] text-white space-y-3">
              <div className="flex items-center justify-between">
                <span className="font-bold text-sm text-white flex items-center gap-1.5">
                  <Award className="w-4 h-4 text-amber-400" />
                  Compte Premium
                </span>
                <span className="font-mono font-bold text-[#0B1F3A] bg-amber-400 px-2.5 py-0.5 rounded">
                  {formatUsd(priceUsd)} / trim.
                </span>
              </div>
              <ul className="space-y-2 text-slate-200">
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <span>Tous les avantages du Compte Normal inclus</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <span>
                    <strong className="text-white">Lancer des enchères en temps réel</strong> (commission {settings.commissionRatePercent}% au vendeur)
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <span>Badge officiel <strong className="text-amber-300">Vendeur Premium PRO</strong> sur votre boutique</span>
                </li>
                <li className="flex items-start gap-2">
                  <Check className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <span>Validité 90 jours (1 trimestre) avec historique des reçus</span>
                </li>
              </ul>
            </div>
          </div>

          {receipt ? (
            /* Payment Receipt */
            <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-5 space-y-4 text-xs">
              <div className="flex items-center justify-between border-b border-emerald-200 pb-3">
                <div className="flex items-center gap-2 text-emerald-800 font-bold text-sm">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  Compte Premium Activé avec Succès !
                </div>
                <span className="font-mono font-bold text-emerald-900">{receipt.receiptNumber}</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div>
                  <span className="text-slate-500 block text-[10px]">Montant réglé</span>
                  <span className="font-mono font-bold text-[#0B1F3A] text-sm">
                    {formatUsd(receipt.amountUsd)}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px]">Équivalent CDF</span>
                  <span className="font-mono font-bold text-amber-700">
                    {receipt.amountCdf.toLocaleString('fr-FR')} CDF
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px]">Agrégateur / Canal</span>
                  <span className="font-semibold uppercase text-slate-900">
                    {receipt.aggregatorName || receipt.provider}
                  </span>
                </div>
                <div>
                  <span className="text-slate-500 block text-[10px]">Référence</span>
                  <span className="font-mono font-bold text-slate-900">{receipt.reference}</span>
                </div>
              </div>

              <div className="flex justify-end pt-1">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-5 py-2.5 bg-[#0B1F3A] hover:bg-[#14325C] text-white font-bold rounded-lg cursor-pointer"
                >
                  Accéder à mes fonctionnalités Premium
                </button>
              </div>
            </div>
          ) : (
            /* Real Payment Form via Banking Aggregator */
            <form onSubmit={handleConfirmPayment} className="space-y-4 pt-2 border-t border-slate-200">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h3 className="text-sm font-bold text-[#0B1F3A]">
                    Régler l’abonnement Premium ({formatUsd(priceUsd)} · {priceCdf.toLocaleString('fr-FR')} CDF)
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    Sélectionnez votre agrégateur bancaire, banque RDC, Mobile Money ou carte pour activer Premium immédiatement.
                  </p>
                </div>
              </div>

              {error && (
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-rose-800 text-xs flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              <BankingAggregatorSelector
                aggregatorGateway={aggregatorGateway}
                onChangeAggregator={setAggregatorGateway}
                method={method}
                onChangeMethod={handleMethodChange}
                provider={provider}
                onChangeProvider={setProvider}
                variant="light"
                showBeneficiaryBox={true}
              />

              {/* Account Input */}
              <div className="text-xs">
                <label className="block text-slate-700 font-medium mb-1">
                  {method === 'mobile_money'
                    ? 'Numéro Mobile Money (+243) *'
                    : method === 'card'
                    ? 'Numéro de carte (4 derniers chiffres / réf.) *'
                    : 'Votre compte bancaire / RIB ou Référence de virement *'}
                </label>
                <input
                  type="text"
                  required
                  value={accountOrPhone}
                  onChange={(e) => setAccountOrPhone(e.target.value)}
                  placeholder={
                    method === 'mobile_money'
                      ? '+243 81 234 5678'
                      : method === 'card'
                      ? '4242 **** **** 4242'
                      : '05100-XXXXXXXX-XX ou VIR-...'
                  }
                  className="w-full p-2.5 border border-slate-300 rounded-lg font-mono"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900 cursor-pointer"
                >
                  Rester en Compte Normal
                </button>
                <button
                  type="submit"
                  disabled={isProcessing}
                  className="px-5 py-2.5 bg-amber-400 hover:bg-amber-300 text-[#0B1F3A] font-bold text-xs rounded-lg transition-colors flex items-center gap-1.5 shadow-sm cursor-pointer disabled:opacity-60"
                >
                  <Award className="w-4 h-4" />
                  {currentUser
                    ? isProcessing
                      ? 'Routage bancaire en cours...'
                      : `Payer ${formatUsd(priceUsd)} et activer Premium`
                    : `Se connecter pour passer Premium (${formatUsd(priceUsd)})`}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
