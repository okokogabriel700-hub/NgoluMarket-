import React, { useState } from 'react';
import {
  AlertTriangle,
  Award,
  CheckCircle2,
  Clock,
  Download,
  Edit3,
  Eye,
  FileCheck,
  Heart,
  Package,
  Shield,
  Save,
} from 'lucide-react';
import { useAuctia } from '../context/AuctiaContext';
import { AuctionItem, FinancialSettlement, PaymentProvider } from '../types';
import {
  calculateTimeRemaining,
  formatUsd,
  getCategoryLabel,
  getOrderStatusLabel,
} from '../utils/formatters';

interface BuyerDashboardProps {
  onSelectAuction: (item: AuctionItem) => void;
  onOpenNewAuction?: () => void;
  onOpenPremium?: () => void;
}

export const BuyerDashboard: React.FC<BuyerDashboardProps> = ({
  onSelectAuction,
  onOpenNewAuction,
  onOpenPremium,
}) => {
  const {
    currentUser,
    auctions,
    bids,
    settlements,
    watchlist,
    recentlyViewedIds,
    language,
    settings,
    updateUserProfile,
    activatePremiumSubscription,
  } = useAuctia();

  const [selectedSettlement, setSelectedSettlement] = useState<FinancialSettlement | null>(null);
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [editName, setEditName] = useState(currentUser?.name || '');
  const [editEmail, setEditEmail] = useState(currentUser?.email || '');
  const [editPhone, setEditPhone] = useState(currentUser?.phone || '');
  const [editCity, setEditCity] = useState(currentUser?.city || 'Kinshasa');
  const [editAvatar, setEditAvatar] = useState(currentUser?.avatar || '');
  const [profileSaved, setProfileSaved] = useState(false);

  const [premiumProvider, setPremiumProvider] = useState<PaymentProvider>('mpesa');
  const [premiumPhone, setPremiumPhone] = useState(currentUser?.phone || '+243 ');
  const [isActivatingPremium, setIsActivatingPremium] = useState(false);
  const [premiumMsg, setPremiumMsg] = useState<string | null>(null);

  if (!currentUser) {
    return (
      <div className="max-w-4xl mx-auto py-16 px-4 text-center">
        <h2 className="text-xl font-bold text-[#0B1F3A] mb-2">Espace Utilisateur NgoluMarket</h2>
        <p className="text-sm text-slate-500 mb-4">
          Veuillez vous inscrire ou vous connecter pour accéder à vos commandes, favoris et enchères.
        </p>
      </div>
    );
  }

  const userBidAuctionIds = Array.from(
    new Set(bids.filter((b) => b.bidderId === currentUser.id).map((b) => b.auctionId))
  );

  const myBidAuctions = auctions.filter((a) => userBidAuctionIds.includes(a.id));
  const myWonAuctions = auctions.filter(
    (a) => a.status === 'terminee' && a.highestBidderId === currentUser.id
  );
  const myWatchedAuctions = auctions.filter((a) => watchlist.includes(a.id));
  const myRecentlyViewed = recentlyViewedIds
    .map((id) => auctions.find((a) => a.id === id))
    .filter((a): a is AuctionItem => Boolean(a));
  const myCreatedAuctions = auctions.filter((a) => a.sellerId === currentUser.id);
  const mySettlements = settlements.filter((s) => s.winnerId === currentUser.id);

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateUserProfile({
      name: editName.trim() || currentUser.name,
      email: editEmail.trim() || undefined,
      phone: editPhone.trim() || currentUser.phone,
      city: editCity.trim() || 'Kinshasa',
      avatar: editAvatar.trim() || undefined,
    });
    setIsEditingProfile(false);
    setProfileSaved(true);
    setTimeout(() => setProfileSaved(false), 3000);
  };

  const handleActivatePremium = async () => {
    setIsActivatingPremium(true);
    setPremiumMsg(null);
    const res = await activatePremiumSubscription({
      method: premiumProvider.includes('rawbank') ? 'bank_transfer' : 'mobile_money',
      provider: premiumProvider,
      aggregatorGateway: 'ngolupay_hub',
      accountOrPhone: premiumPhone,
    });
    setIsActivatingPremium(false);
    if (res.success) {
      setPremiumMsg('Votre abonnement Vendeur Premium (50 USD/trimestre) est désormais actif !');
    } else {
      setPremiumMsg(res.error || 'Échec du paiement Premium.');
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Profile Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-slate-200 gap-4">
        <div className="flex items-center gap-4">
          {currentUser.avatar ? (
            <img
              src={currentUser.avatar}
              alt={currentUser.name}
              className="w-14 h-14 rounded-full object-cover border-2 border-[#0B1F3A]"
            />
          ) : (
            <div className="w-14 h-14 rounded-full bg-[#0B1F3A] text-amber-400 font-bold flex items-center justify-center text-lg">
              {currentUser.name.substring(0, 2).toUpperCase()}
            </div>
          )}
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-2xl font-bold text-[#0B1F3A]">{currentUser.name}</h1>
              <span className="text-xs text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded font-semibold border border-emerald-200">
                Compte Acheteur & Vendeur
              </span>
              {currentUser.isPremium ? (
                <span className="text-xs text-amber-900 bg-amber-100 px-2.5 py-0.5 rounded font-bold border border-amber-300 flex items-center gap-1">
                  <Award className="w-3.5 h-3.5 text-amber-600" />
                  Compte Premium Actif
                </span>
              ) : (
                <span className="text-xs text-slate-700 bg-slate-100 px-2.5 py-0.5 rounded font-semibold border border-slate-200">
                  Compte Normal (Gratuit)
                </span>
              )}
            </div>
            <p className="text-xs text-slate-500 mt-1">
              {currentUser.phone} {currentUser.email ? `· ${currentUser.email}` : ''} · {currentUser.city}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setIsEditingProfile(!isEditingProfile)}
            className="px-3.5 py-2 text-xs font-semibold text-[#0B1F3A] bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Edit3 className="w-3.5 h-3.5" />
            <span>Modifier mon profil</span>
          </button>
        </div>
      </div>

      {profileSaved && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          Vos informations personnelles ont été mises à jour.
        </div>
      )}

      {/* Profile Editing Panel (Section 4) */}
      {isEditingProfile && (
        <form
          onSubmit={handleSaveProfile}
          className="bg-white rounded-xl border border-slate-200 p-6 space-y-4 text-xs"
        >
          <h2 className="text-sm font-bold text-[#0B1F3A]">
            Modification des informations personnelles & Photo de profil
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div>
              <label className="block font-medium text-slate-700 mb-1">Nom complet</label>
              <input
                type="text"
                value={editName}
                onChange={(e) => setEditName(e.target.value)}
                className="w-full p-2 border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">Adresse e-mail</label>
              <input
                type="email"
                placeholder="nom@exemple.cd"
                value={editEmail}
                onChange={(e) => setEditEmail(e.target.value)}
                className="w-full p-2 border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">Téléphone</label>
              <input
                type="text"
                value={editPhone}
                onChange={(e) => setEditPhone(e.target.value)}
                className="w-full p-2 border border-slate-300 rounded-lg font-mono"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">Ville / Commune</label>
              <input
                type="text"
                value={editCity}
                onChange={(e) => setEditCity(e.target.value)}
                className="w-full p-2 border border-slate-300 rounded-lg"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="block font-medium text-slate-700 mb-1">
                URL de photo de profil (optionnel)
              </label>
              <input
                type="url"
                placeholder="https://..."
                value={editAvatar}
                onChange={(e) => setEditAvatar(e.target.value)}
                className="w-full p-2 border border-slate-300 rounded-lg"
              />
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={() => setIsEditingProfile(false)}
              className="px-3.5 py-2 text-slate-600 hover:text-slate-900"
            >
              Annuler
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-[#0B1F3A] text-white font-bold rounded-lg flex items-center gap-1.5 cursor-pointer"
            >
              <Save className="w-3.5 h-3.5 text-amber-400" />
              Enregistrer
            </button>
          </div>
        </form>
      )}

      {/* KPI Stats Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <span className="text-xs text-slate-500 block">Commandes & Adjudications</span>
          <span className="text-2xl font-bold text-[#0B1F3A] font-mono tabular-nums">
            {mySettlements.length}
          </span>
          <span className="text-[11px] text-emerald-600 block mt-1 font-medium">Suivi actif</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <span className="text-xs text-slate-500 block">Offres actives</span>
          <span className="text-2xl font-bold text-amber-600 font-mono tabular-nums">
            {myBidAuctions.filter((a) => a.status === 'en_cours').length}
          </span>
          <span className="text-[11px] text-slate-400 block mt-1">En cours à Kinshasa</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <span className="text-xs text-slate-500 block">Produits favoris</span>
          <span className="text-2xl font-bold text-[#0B1F3A] font-mono tabular-nums">
            {myWatchedAuctions.length}
          </span>
          <span className="text-[11px] text-slate-400 block mt-1">Liste d’attente</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <span className="text-xs text-slate-500 block">Consultations récentes</span>
          <span className="text-2xl font-bold text-[#0B1F3A] font-mono tabular-nums">
            {myRecentlyViewed.length}
          </span>
          <span className="text-[11px] text-slate-400 block mt-1">Historique des vues</span>
        </div>
      </div>

      {/* Section 8: Abonnement Vendeur Premium Card */}
      <div className="bg-[#0B1F3A] text-white rounded-xl p-6 border border-[#163254] flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-400" />
            <h2 className="text-base font-bold text-white">
              Abonnement Vendeur Premium NgoluMarket ({settings.premiumSubscriptionPriceUsd ?? 50} USD / trimestre)
            </h2>
          </div>
          {currentUser.isPremium ? (
            <p className="text-xs text-emerald-300">
              Statut ACTIF · Début :{' '}
              {currentUser.premiumStartedAt
                ? new Date(currentUser.premiumStartedAt).toLocaleDateString('fr-FR')
                : 'Actif'}{' '}
              · Expiration :{' '}
              {currentUser.premiumExpiresAt
                ? new Date(currentUser.premiumExpiresAt).toLocaleDateString('fr-FR')
                : 'Dans 90 jours'}
              . Vous pouvez publier des enchères en ligne librement.
            </p>
          ) : (
            <p className="text-xs text-slate-300 max-w-2xl">
              Passez Vendeur Premium pour débloquer la mise aux enchères en ligne en temps réel (5% de commission vendeur, participation acheteurs gratuite).
            </p>
          )}
          {premiumMsg && (
            <p className="text-xs text-amber-300 font-semibold pt-1">{premiumMsg}</p>
          )}
        </div>

        {!currentUser.isPremium && (
          <div className="flex flex-wrap items-center gap-2 shrink-0">
            {onOpenPremium ? (
              <button
                type="button"
                onClick={onOpenPremium}
                className="px-4 py-2.5 bg-amber-400 hover:bg-amber-300 text-[#0B1F3A] font-bold rounded-lg text-xs cursor-pointer flex items-center gap-1.5 shadow-sm"
              >
                <Award className="w-4 h-4" />
                Passer Compte Premium ({settings.premiumSubscriptionPriceUsd ?? 50} USD)
              </button>
            ) : (
              <>
                <select
                  value={premiumProvider}
                  onChange={(e) => setPremiumProvider(e.target.value as PaymentProvider)}
                  className="px-2.5 py-2 rounded-lg bg-[#14325C] border border-[#244B82] text-white text-xs"
                >
                  <option value="mpesa">M-Pesa Vodacom</option>
                  <option value="orange_money">Orange Money</option>
                  <option value="airtel_money">Airtel Money</option>
                  <option value="rawbank_illicocash">Rawbank Illicocash</option>
                </select>
                <input
                  type="text"
                  value={premiumPhone}
                  onChange={(e) => setPremiumPhone(e.target.value)}
                  placeholder="+243..."
                  className="px-2.5 py-2 rounded-lg bg-[#14325C] border border-[#244B82] text-white font-mono text-xs w-36"
                />
                <button
                  type="button"
                  disabled={isActivatingPremium}
                  onClick={handleActivatePremium}
                  className="px-4 py-2 bg-amber-400 hover:bg-amber-300 text-[#0B1F3A] font-bold rounded-lg text-xs cursor-pointer"
                >
                  {isActivatingPremium
                    ? 'Activation...'
                    : `Souscrire (${settings.premiumSubscriptionPriceUsd ?? 50} USD)`}
                </button>
              </>
            )}
          </div>
        )}
      </div>

      {/* Section 11: Mes Commandes & Suivi des Statuts */}
      {mySettlements.length > 0 && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
          <div>
            <h2 className="text-base font-bold text-[#0B1F3A] flex items-center gap-2">
              <Package className="w-5 h-5 text-emerald-600" />
              Suivi de mes Commandes & Bordereaux ({mySettlements.length})
            </h2>
            <p className="text-xs text-slate-500">
              Numéro unique de commande, frais NgoluMarket et suivi en temps réel de la préparation à la remise.
            </p>
          </div>

          <div className="divide-y divide-slate-100">
            {mySettlements.map((s) => {
              const item = auctions.find((a) => a.id === s.auctionId);
              const orderBadge = getOrderStatusLabel(s.orderStatus, language);
              const totalBuyerPay = s.winningBid + (s.buyerFeeUsd || 0);
              return (
                <div
                  key={s.id}
                  className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap text-xs">
                      <span className="font-mono font-bold text-[#0B1F3A]">
                        {s.orderNumber || s.id}
                      </span>
                      <span className={`px-2 py-0.5 rounded border text-[11px] font-semibold ${orderBadge.badgeClass}`}>
                        {orderBadge.label}
                      </span>
                      <span className="text-slate-400 text-[11px]">
                        {new Date(s.closedAt).toLocaleDateString('fr-FR')}
                      </span>
                    </div>
                    <h3 className="text-sm font-bold text-slate-900">{s.auctionTitle}</h3>
                    <div className="text-xs text-slate-600 font-mono">
                      Produit : <strong>{formatUsd(s.winningBid)}</strong>
                      {s.buyerFeeUsd ? ` + Frais NgoluMarket : ${s.buyerFeeUsd} USD = Total : ${formatUsd(totalBuyerPay)}` : ''}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setSelectedSettlement(s)}
                      className="px-3.5 py-2 text-xs font-semibold text-[#0B1F3A] bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors flex items-center gap-1.5 shadow-xs cursor-pointer"
                    >
                      <FileCheck className="w-4 h-4" />
                      Bordereau Officiel
                    </button>
                    {item && (
                      <button
                        type="button"
                        onClick={() => onSelectAuction(item)}
                        className="px-3 py-2 text-xs font-medium text-slate-600 hover:text-slate-900 bg-slate-100 rounded-lg cursor-pointer"
                      >
                        Détails
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Mes Biens mis en vente */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-[#0B1F3A]">
              Mes Produits publiés ({myCreatedAuctions.length})
            </h2>
            <p className="text-xs text-slate-500">
              Suivez vos annonces à prix fixe et vos enchères en cours.
            </p>
          </div>
          {onOpenNewAuction && (
            <button
              type="button"
              onClick={onOpenNewAuction}
              className="px-3.5 py-2 bg-amber-400 hover:bg-amber-300 text-[#0B1F3A] text-xs font-bold rounded-lg transition-colors shadow-xs flex items-center gap-1.5 self-start sm:self-auto cursor-pointer"
            >
              + Publier un produit
            </button>
          )}
        </div>

        {myCreatedAuctions.length === 0 ? (
          <div className="text-center py-6 border border-dashed border-slate-200 rounded-xl text-xs text-slate-500">
            Vous n’avez pas encore publié de produit.
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {myCreatedAuctions.map((item) => (
              <div
                key={item.id}
                className="py-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
              >
                <div className="flex items-center gap-3">
                  <img
                    src={item.images[0]}
                    alt={item.title}
                    referrerPolicy="no-referrer"
                    className="w-14 h-12 object-cover rounded-lg border border-slate-200 shrink-0"
                  />
                  <div>
                    <span className="font-semibold text-slate-500 uppercase text-[10px]">
                      {getCategoryLabel(item.category, language)} · {item.location.commune}
                    </span>
                    <h3 className="font-bold text-slate-900 text-sm">{item.title}</h3>
                    <div className="text-slate-500 font-mono mt-0.5">
                      Prix : <strong className="text-slate-900">{formatUsd(item.fixedPrice || item.currentPrice)}</strong> ·{' '}
                      {item.bidsCount} offres/achats
                    </div>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => onSelectAuction(item)}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold rounded-lg cursor-pointer self-start sm:self-auto"
                >
                  Consulter
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Favoris & Historique des consultations (Section 10) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-3">
          <h2 className="text-base font-bold text-[#0B1F3A] flex items-center gap-2">
            <Heart className="w-4 h-4 text-rose-500" />
            Mes Favoris ({myWatchedAuctions.length})
          </h2>
          {myWatchedAuctions.length === 0 ? (
            <p className="text-xs text-slate-500 py-4">Aucun produit enregistré en favoris.</p>
          ) : (
            <div className="divide-y divide-slate-100">
              {myWatchedAuctions.map((item) => (
                <div key={item.id} className="py-2.5 flex items-center justify-between gap-3 text-xs">
                  <div className="truncate">
                    <div className="font-semibold text-slate-900 truncate">{item.title}</div>
                    <div className="text-slate-500 font-mono">
                      {formatUsd(item.fixedPrice || item.currentPrice)}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => onSelectAuction(item)}
                    className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 rounded font-semibold shrink-0 cursor-pointer"
                  >
                    Voir
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-3">
          <h2 className="text-base font-bold text-[#0B1F3A] flex items-center gap-2">
            <Eye className="w-4 h-4 text-[#0B1F3A]" />
            Historique des consultations ({myRecentlyViewed.length})
          </h2>
          {myRecentlyViewed.length === 0 ? (
            <p className="text-xs text-slate-500 py-4">Aucun produit consulté récemment.</p>
          ) : (
            <div className="divide-y divide-slate-100">
              {myRecentlyViewed.map((item) => (
                <div key={item.id} className="py-2.5 flex items-center justify-between gap-3 text-xs">
                  <div className="truncate">
                    <div className="font-semibold text-slate-900 truncate">{item.title}</div>
                    <div className="text-slate-500 font-mono">
                      {getCategoryLabel(item.category, language)} · {formatUsd(item.fixedPrice || item.currentPrice)}
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => onSelectAuction(item)}
                    className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 rounded font-semibold shrink-0 cursor-pointer"
                  >
                    Revoir
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Active Bids Section */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
        <h2 className="text-base font-bold text-[#0B1F3A]">Vos participations aux enchères</h2>

        {myBidAuctions.length === 0 ? (
          <div className="text-center py-6 text-xs text-slate-500">
            Vous n’avez placé aucune offre d’enchère pour l’instant.
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {myBidAuctions.map((item) => {
              const isLeading = item.highestBidderId === currentUser.id;
              const time = calculateTimeRemaining(item.endDate, item.startDate, item.status, language);

              return (
                <div key={item.id} className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-center gap-4">
                    <img
                      src={item.images[0]}
                      alt={item.title}
                      referrerPolicy="no-referrer"
                      className="w-16 h-14 object-cover rounded-lg border border-slate-200 shrink-0"
                    />
                    <div>
                      <div className="flex items-center gap-2 text-xs">
                        <span className="font-semibold text-slate-500">
                          {getCategoryLabel(item.category, language)}
                        </span>
                        <span className="text-slate-300">·</span>
                        {isLeading ? (
                          <span className="text-emerald-700 font-bold">Vous menez l’enchère</span>
                        ) : (
                          <span className="text-rose-600 font-bold flex items-center gap-1">
                            <AlertTriangle className="w-3.5 h-3.5" />
                            Vous avez été surenchéri
                          </span>
                        )}
                      </div>
                      <h3 className="text-sm font-semibold text-slate-900">{item.title}</h3>
                      <div className="text-xs text-slate-500 flex items-center gap-3 font-mono mt-0.5">
                        <span>Offre en tête : {formatUsd(item.currentPrice)}</span>
                        <span>·</span>
                        <span className="flex items-center gap-1 text-slate-700">
                          <Clock className="w-3 h-3" /> {time.text}
                        </span>
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => onSelectAuction(item)}
                    className={`px-4 py-2 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                      isLeading
                        ? 'bg-slate-100 text-slate-800 hover:bg-slate-200'
                        : 'bg-amber-400 hover:bg-amber-300 text-[#0B1F3A] shadow-sm'
                    }`}
                  >
                    {isLeading ? 'Suivre l’enchère' : 'Surenchérir'}
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Official Bordereau Modal */}
      {selectedSettlement && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/75 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden">
            <div className="p-6 bg-[#0B1F3A] text-white flex items-center justify-between">
              <div>
                <span className="text-xs uppercase tracking-widest text-amber-400 font-semibold">
                  NgoluMarket Kinshasa · Commande {selectedSettlement.orderNumber || selectedSettlement.id}
                </span>
                <h3 className="text-lg font-bold">Bordereau Officiel de Commande</h3>
                <span className="text-xs text-slate-300 font-mono">
                  Date : {new Date(selectedSettlement.closedAt).toLocaleDateString('fr-FR')}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setSelectedSettlement(null)}
                className="text-slate-300 hover:text-white cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-6 text-xs">
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-1.5">
                <span className="text-[11px] text-slate-400 uppercase font-semibold">Désignation du produit</span>
                <div className="text-sm font-bold text-slate-900">{selectedSettlement.auctionTitle}</div>
                <div className="text-slate-600">
                  Acheteur : <strong className="text-slate-900">{currentUser.name}</strong> ({currentUser.phone})
                </div>
              </div>

              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <div className="bg-slate-100 px-4 py-2 font-bold text-[#0B1F3A] text-xs">
                  Décompte financier NgoluMarket
                </div>
                <div className="divide-y divide-slate-100 p-4 space-y-2 font-mono">
                  <div className="flex justify-between py-1">
                    <span className="text-slate-600">Prix du produit :</span>
                    <span className="font-bold text-slate-900 text-sm">
                      {formatUsd(selectedSettlement.winningBid)}
                    </span>
                  </div>
                  {selectedSettlement.saleType === 'prix_fixe' ? (
                    <>
                      <div className="flex justify-between py-1 text-slate-600">
                        <span>Frais NgoluMarket (acheteur) :</span>
                        <span>+{selectedSettlement.buyerFeeUsd ?? 1} USD</span>
                      </div>
                      <div className="flex justify-between py-1 pt-2 border-t border-slate-200 font-bold">
                        <span className="text-[#0B1F3A]">Total payé par l’acheteur :</span>
                        <span className="text-emerald-700 text-sm">
                          {formatUsd(selectedSettlement.winningBid + (selectedSettlement.buyerFeeUsd ?? 1))}
                        </span>
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="flex justify-between py-1 text-slate-500">
                        <span>Commission vendeur ({selectedSettlement.commissionRate}%) :</span>
                        <span>{formatUsd(selectedSettlement.commissionAmount)}</span>
                      </div>
                      <div className="flex justify-between py-1 pt-2 border-t border-slate-200 font-bold">
                        <span className="text-slate-900">Net vendeur :</span>
                        <span className="text-emerald-700 text-sm">
                          {formatUsd(selectedSettlement.netSellerAmount)}
                        </span>
                      </div>
                    </>
                  )}
                </div>
              </div>

              <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl space-y-1.5 text-slate-700">
                <div className="font-bold text-amber-900 flex items-center gap-1.5">
                  <Shield className="w-4 h-4 text-amber-700" />
                  Statut de livraison & Séquestre
                </div>
                <p className="text-[11px] leading-relaxed">
                  Statut actuel : <strong>{getOrderStatusLabel(selectedSettlement.orderStatus, language).label}</strong>.
                  Vos fonds sont sécurisés jusqu’à remise conforme du produit.
                </p>
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="px-4 py-2 bg-[#0B1F3A] hover:bg-[#14325C] text-white rounded-lg font-bold flex items-center gap-1.5 text-xs shadow-sm cursor-pointer"
                >
                  <Download className="w-4 h-4" />
                  Imprimer le Bordereau
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
