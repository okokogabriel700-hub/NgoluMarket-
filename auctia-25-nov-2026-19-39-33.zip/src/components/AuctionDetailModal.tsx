import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertCircle,
  ArrowRight,
  Award,
  Building,
  Car,
  Check,
  CheckCircle2,
  Clock,
  Download,
  Dumbbell,
  ExternalLink,
  FileCheck,
  FileText,
  Gavel,
  Heart,
  Info,
  Landmark,
  Lock,
  MapPin,
  PlugZap,
  Printer,
  QrCode,
  ShieldCheck,
  ShoppingBag,
  Smartphone,
  Sofa,
  Sparkles,
  TrendingUp,
  Utensils,
  Watch,
  X,
  Zap,
} from 'lucide-react';
import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip as RechartsTooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { useAuctia } from '../context/AuctiaContext';
import {
  AuctionItem,
  AutomobileDetails,
  BankAggregatorId,
  GeneralProductDetails,
  ImmobilierDetails,
  ModeDetails,
  PaymentMethod,
  PaymentProvider,
  PaymentPurpose,
  PaymentTransaction,
} from '../types';
import {
  calculateTimeRemaining,
  formatCdf,
  formatUsd,
  getCategoryLabel,
  getSaleTypeLabel,
  getStatusLabel,
} from '../utils/formatters';
import { t } from '../utils/i18n';
import { BankingAggregatorSelector } from './BankingAggregatorSelector';
import { StarRating } from './StarRating';

interface AuctionDetailModalProps {
  item: AuctionItem;
  onClose: () => void;
  onOpenAuth: () => void;
}

export const AuctionDetailModal: React.FC<AuctionDetailModalProps> = ({
  item,
  onClose,
  onOpenAuth,
}) => {
  const {
    currentUser,
    placeBid,
    buyFixedPriceItem,
    watchlist,
    toggleWatchlist,
    bids,
    calculateMinBid,
    settings,
    latestBidEvent,
    auctions,
    isWsConnected,
    activeViewersMap,
    subscribeToAuctionRoom,
    unsubscribeFromAuctionRoom,
    processPayment,
    payments,
    language,
    submitAdCampaign,
    sellerProfiles,
  } = useAuctia();

  // Find latest state of this auction from context
  const currentAuctionItem = auctions.find((a) => a.id === item.id) || item;

  // Real-time room subscription
  useEffect(() => {
    subscribeToAuctionRoom(item.id);
    return () => {
      unsubscribeFromAuctionRoom(item.id);
    };
  }, [item.id]);

  const liveViewersCount = activeViewersMap[item.id] || 1;
  const isWatched = watchlist.includes(currentAuctionItem.id);
  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [sponsorMessage, setSponsorMessage] = useState<string | null>(null);
  const [isSponsoring, setIsSponsoring] = useState(false);

  // Active right column view: 'bid' | 'payment'
  const [activeTab, setActiveTab] = useState<'bid' | 'payment'>('bid');

  const isFixedPrice = currentAuctionItem.saleType === 'prix_fixe';
  const effectiveFixedPrice = currentAuctionItem.fixedPrice || currentAuctionItem.currentPrice || currentAuctionItem.startPrice;
  const buyerFeeUsd = isFixedPrice ? (settings.fixedPriceBuyerFeeUsd ?? 1) : 0;
  const fixedTotalAmount = effectiveFixedPrice + buyerFeeUsd;

  const minRequiredBid = calculateMinBid(currentAuctionItem);
  const [bidAmount, setBidAmount] = useState<number>(minRequiredBid);
  const [bidError, setBidError] = useState<string | null>(null);
  const [bidSuccess, setBidSuccess] = useState<string | null>(null);
  const [liveFlash, setLiveFlash] = useState<string | null>(null);

  // === PAYMENT STATE ===
  const depositDefaultAmount = isFixedPrice
    ? fixedTotalAmount
    : Math.max(
        currentAuctionItem.depositRequiredUsd || 0,
        Math.round(currentAuctionItem.currentPrice * 0.1) // 10% caution
      );

  const [paymentPurpose, setPaymentPurpose] = useState<PaymentPurpose>(
    isFixedPrice ? 'auction_settlement' : 'deposit_guarantee'
  );
  const [aggregatorGateway, setAggregatorGateway] = useState<BankAggregatorId>('ngolupay_hub');
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('mobile_money');
  const [paymentProvider, setPaymentProvider] = useState<PaymentProvider>('mpesa');
  const [paymentAmountUsd, setPaymentAmountUsd] = useState<number>(depositDefaultAmount);
  const [accountOrPhone, setAccountOrPhone] = useState<string>(
    currentUser?.phone || '+243 '
  );
  const [cardHolder, setCardHolder] = useState<string>(currentUser?.name || '');
  const [cardNumber, setCardNumber] = useState<string>('');
  const [cardExpiry, setCardExpiry] = useState<string>('');
  const [cardCvv, setCardCvv] = useState<string>('');
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  const [paymentError, setPaymentError] = useState<string | null>(null);
  const [completedTransaction, setCompletedTransaction] = useState<PaymentTransaction | null>(null);

  // Detect operator based on Congolese phone number prefix
  const getPhoneOperatorBadge = (phone: string) => {
    const clean = phone.replace(/\s+/g, '');
    if (clean.includes('81') || clean.includes('82')) return { name: 'Vodacom M-Pesa', color: 'text-red-600 bg-red-50 border-red-200' };
    if (clean.includes('97') || clean.includes('99')) return { name: 'Airtel Money', color: 'text-rose-600 bg-rose-50 border-rose-200' };
    if (clean.includes('84') || clean.includes('85') || clean.includes('89')) return { name: 'Orange Money', color: 'text-orange-600 bg-orange-50 border-orange-200' };
    if (clean.includes('90')) return { name: 'Africell Afrimoney', color: 'text-purple-600 bg-purple-50 border-purple-200' };
    return null;
  };

  // When a real-time bid arrives for this auction from anywhere
  useEffect(() => {
    if (latestBidEvent && latestBidEvent.auctionId === currentAuctionItem.id) {
      setLiveFlash(
        latestBidEvent.antiSnipingTriggered
          ? `Nouvelle offre en direct : ${formatUsd(latestBidEvent.newPrice)} · Temps prolongé (+${settings.antiSnipingMinutes} min) !`
          : `Nouvelle offre reçue en direct : ${formatUsd(latestBidEvent.newPrice)} (${currentAuctionItem.bidsCount} offres) !`
      );
      const timer = setTimeout(() => setLiveFlash(null), 5000);
      return () => clearTimeout(timer);
    }
  }, [latestBidEvent, currentAuctionItem.id, currentAuctionItem.bidsCount, settings.antiSnipingMinutes]);

  // Update min bid if item price changes
  useEffect(() => {
    setBidAmount(calculateMinBid(currentAuctionItem));
  }, [currentAuctionItem.currentPrice, currentAuctionItem.bidsCount]);

  // Live countdown timer synced to currentAuctionItem (updates automatically on anti-sniping / WS events)
  const [timeInfo, setTimeInfo] = useState(() =>
    calculateTimeRemaining(
      currentAuctionItem.endDate,
      currentAuctionItem.startDate,
      currentAuctionItem.status,
      language
    )
  );

  useEffect(() => {
    setTimeInfo(
      calculateTimeRemaining(
        currentAuctionItem.endDate,
        currentAuctionItem.startDate,
        currentAuctionItem.status,
        language
      )
    );
    const timer = setInterval(() => {
      setTimeInfo(
        calculateTimeRemaining(
          currentAuctionItem.endDate,
          currentAuctionItem.startDate,
          currentAuctionItem.status,
          language
        )
      );
    }, 1000);
    return () => clearInterval(timer);
  }, [currentAuctionItem.endDate, currentAuctionItem.startDate, currentAuctionItem.status, language]);

  // Dynamic seller verification lookup
  const sellerProfile = sellerProfiles.find((p) => p.userId === currentAuctionItem.sellerId);
  const sellerVerificationStatus = sellerProfile
    ? sellerProfile.verificationStatus
    : currentAuctionItem.sellerVerified
    ? 'verified'
    : 'unverified';
  const isSellerVerified = sellerVerificationStatus === 'verified';

  // Filter bids for this auction
  const itemBids = bids
    .filter((b) => b.auctionId === item.id)
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  // === RECHARTS TREND DATA ===
  // Chronological progression of prices from start price to highest bid
  const trendData = useMemo(() => {
    const sortedChronological = [...itemBids].sort(
      (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    );

    const basePoint = {
      label: 'Départ',
      time: new Date(currentAuctionItem.startDate).toLocaleTimeString('fr-FR', {
        hour: '2-digit',
        minute: '2-digit',
      }),
      amount: currentAuctionItem.startPrice,
      bidder: 'Prix de départ',
    };

    if (sortedChronological.length === 0) {
      return [
        basePoint,
        {
          label: 'Actuel',
          time: 'En cours',
          amount: currentAuctionItem.currentPrice,
          bidder: 'En attente d’offres',
        },
      ];
    }

    const bidPoints = sortedChronological.map((b, idx) => ({
      label: `Offre #${idx + 1}`,
      time: new Date(b.timestamp).toLocaleTimeString('fr-FR', {
        hour: '2-digit',
        minute: '2-digit',
      }),
      amount: b.amount,
      bidder: b.bidderId === currentUser?.id ? 'Vous' : b.bidderName,
    }));

    return [basePoint, ...bidPoints];
  }, [
    currentAuctionItem.startDate,
    currentAuctionItem.startPrice,
    currentAuctionItem.currentPrice,
    itemBids,
    currentUser?.id,
  ]);

  const priceIncrease = currentAuctionItem.currentPrice - currentAuctionItem.startPrice;
  const percentIncrease =
    currentAuctionItem.startPrice > 0
      ? ((priceIncrease / currentAuctionItem.startPrice) * 100).toFixed(1)
      : '0';

  // Existing payments for this user on this auction
  const userAuctionPayments = payments.filter(
    (p) => p.userId === currentUser?.id && p.auctionId === item.id
  );
  const hasUserActiveDeposit =
    userAuctionPayments.some(
      (p) => p.purpose === 'deposit_guarantee' && p.status === 'completed'
    ) ||
    (currentUser?.depositBalanceUsd &&
      currentUser.depositBalanceUsd >= depositDefaultAmount);

  const handlePlaceBid = (e: React.FormEvent) => {
    e.preventDefault();
    setBidError(null);
    setBidSuccess(null);

    if (!currentUser) {
      onOpenAuth();
      return;
    }

    const result = placeBid(item.id, Number(bidAmount));
    if (!result.success) {
      setBidError(result.error || "Impossible de placer l'offre.");
    } else {
      setBidSuccess(`Votre offre de ${formatUsd(bidAmount)} a été validée avec succès !`);
      setTimeout(() => setBidSuccess(null), 5000);
    }
  };

  // Direct purchase for Fixed Price items
  const handleBuyNow = () => {
    setBidError(null);
    setBidSuccess(null);

    if (!currentUser) {
      onOpenAuth();
      return;
    }

    // Direct purchase execution
    const result = buyFixedPriceItem(item.id);
    if (!result.success) {
      setBidError(result.error || 'Impossible de finaliser l’achat immédiat.');
    } else {
      setBidSuccess(
        `Félicitations ! Commande enregistrée : ${formatUsd(effectiveFixedPrice)} + ${buyerFeeUsd} USD frais NgoluMarket = ${formatUsd(fixedTotalAmount)}.`
      );
      // Switch to payment tab to complete transaction settlement
      setPaymentPurpose('auction_settlement');
      setPaymentAmountUsd(fixedTotalAmount);
      setActiveTab('payment');
    }
  };

  const handleIncrement = (increment: number) => {
    setBidAmount((prev) => Math.max(minRequiredBid, prev + increment));
  };

  // Submit real payment via backend API
  const handleExecutePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    setPaymentError(null);

    if (!currentUser) {
      onOpenAuth();
      return;
    }

    if (paymentAmountUsd <= 0) {
      setPaymentError('Veuillez spécifier un montant valide supérieur à 0 USD.');
      return;
    }

    if (paymentMethod === 'card') {
      if (!cardNumber || cardNumber.replace(/\s+/g, '').length < 15) {
        setPaymentError('Numéro de carte bancaire incomplet (16 chiffres requis).');
        return;
      }
      if (!cardExpiry || !cardCvv) {
        setPaymentError('Date d’expiration et code CVV obligatoires.');
        return;
      }
    } else {
      if (!accountOrPhone || accountOrPhone.trim().length < 8) {
        setPaymentError('Numéro de téléphone ou compte bancaire requis.');
        return;
      }
    }

    setIsProcessingPayment(true);

    try {
      const result = await processPayment({
        amountUsd: Number(paymentAmountUsd),
        purpose: paymentPurpose,
        method: paymentMethod,
        provider: paymentProvider,
        aggregatorGateway,
        accountOrPhone:
          paymentMethod === 'card'
            ? `**** **** **** ${cardNumber.slice(-4)}`
            : accountOrPhone,
        auctionId: item.id,
        auctionTitle: item.title,
        notes: `Règlement direct NgoluMarket RDC pour ${item.title} (${paymentPurpose})`,
      });

      if (!result.success || !result.transaction) {
        setPaymentError(result.error || 'Échec de la transaction bancaire.');
      } else {
        setCompletedTransaction(result.transaction);
        if (isFixedPrice && currentAuctionItem.status !== 'terminee') {
          buyFixedPriceItem(item.id);
        }
      }
    } catch (err: any) {
      setPaymentError(err.message || 'Erreur lors de la communication bancaire.');
    } finally {
      setIsProcessingPayment(false);
    }
  };

  const statusInfo = getStatusLabel(currentAuctionItem.status, language);
  const saleTypeInfo = getSaleTypeLabel(currentAuctionItem.saleType, language);

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/75 backdrop-blur-sm flex items-center justify-center p-2 sm:p-4 md:p-6">
      <div className="relative w-full max-w-5xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[94vh] flex flex-col">
        {/* Modal Top Bar */}
        <div className="flex items-center justify-between px-4 sm:px-6 py-3.5 border-b border-slate-200 bg-slate-50/90">
          <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
            <span className="text-xs font-bold uppercase tracking-wider text-[#0B1F3A] bg-slate-200/80 px-2 py-0.5 rounded">
              {getCategoryLabel(item.category, language)}
            </span>

            {/* Sale Type Badge: Enchères vs Prix Fixe */}
            <span
              className={`text-xs font-bold px-2 py-0.5 rounded border flex items-center gap-1 ${saleTypeInfo.badgeClass}`}
            >
              {isFixedPrice ? (
                <ShoppingBag className="w-3.5 h-3.5 text-emerald-600" />
              ) : (
                <Gavel className="w-3.5 h-3.5 text-amber-600" />
              )}
              <span>{saleTypeInfo.shortLabel}</span>
            </span>

            <span className="text-slate-300 hidden sm:inline">·</span>
            <span className="text-xs text-slate-600 flex items-center gap-1 font-medium">
              <MapPin className="w-3.5 h-3.5 text-amber-600" />
              {item.location.commune}, Kinshasa
            </span>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            {/* Real-time WebSocket Live Status */}
            <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 bg-emerald-50 border border-emerald-200 rounded-full text-[11px] font-semibold text-emerald-700">
              <span
                className={`w-2 h-2 rounded-full ${
                  isWsConnected ? 'bg-emerald-500 animate-pulse' : 'bg-amber-500'
                }`}
              ></span>
              <span>
                {isWsConnected
                  ? `En direct (${liveViewersCount} connectés)`
                  : 'Connexion...'}
              </span>
            </div>

            <button
              type="button"
              onClick={() => toggleWatchlist(item.id)}
              className={`p-2 rounded-lg border transition-colors flex items-center gap-1.5 text-xs font-medium ${
                isWatched
                  ? 'border-rose-200 bg-rose-50 text-rose-600'
                  : 'border-slate-200 hover:bg-slate-100 text-slate-600'
              }`}
            >
              <Heart className={`w-4 h-4 ${isWatched ? 'fill-current' : ''}`} />
              <span className="hidden md:inline">
                {isWatched ? 'Suivie' : 'Suivre'}
              </span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="overflow-y-auto p-4 sm:p-6 grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Visuals & Specifications (7 cols) */}
          <div className="lg:col-span-7 space-y-6">
            {/* Image Gallery */}
            <div>
              <div className="relative aspect-video rounded-xl overflow-hidden bg-slate-900 border border-slate-200 shadow-sm">
                <img
                  src={item.images[selectedImageIndex] || item.images[0]}
                  alt={item.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-3 left-3 bg-slate-900/80 backdrop-blur-md px-3 py-1 rounded-full text-xs font-semibold text-white border border-white/20 flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                  Lot Certifié NgoluMarket RDC
                </div>

                <div className="absolute bottom-3 right-3 bg-slate-950/80 backdrop-blur-md px-2.5 py-1 rounded-lg text-xs font-bold text-amber-300 border border-amber-500/30 flex items-center gap-1.5">
                  {isFixedPrice ? (
                    <>
                      <ShoppingBag className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Prix Fixe : {formatUsd(effectiveFixedPrice)}</span>
                    </>
                  ) : (
                    <>
                      <Gavel className="w-3.5 h-3.5 text-amber-400" />
                      <span>Adjudication aux Enchères</span>
                    </>
                  )}
                </div>
              </div>

              {item.images.length > 1 && (
                <div className="flex gap-2 mt-3 overflow-x-auto pb-1">
                  {item.images.map((img, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setSelectedImageIndex(idx)}
                      className={`relative w-16 h-12 rounded-lg overflow-hidden shrink-0 border-2 transition-all ${
                        selectedImageIndex === idx
                          ? 'border-amber-500 ring-2 ring-amber-500/30'
                          : 'border-transparent opacity-70 hover:opacity-100'
                      }`}
                    >
                      <img src={img} alt="" className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Title & Description */}
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className={`text-[11px] font-bold px-2 py-0.5 rounded border ${saleTypeInfo.badgeClass}`}>
                  {saleTypeInfo.label}
                </span>
                <span className="text-xs text-slate-400">· Réf. {item.id}</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900">{item.title}</h2>
              <p className="mt-2 text-sm text-slate-600 leading-relaxed whitespace-pre-line">
                {item.description}
              </p>
            </div>

            {/* Specific Attributes Accordion */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-[#0B1F3A] mb-3 flex items-center gap-2">
                {item.category === 'immobilier' && <Building className="w-4 h-4 text-amber-600" />}
                {item.category === 'automobile' && <Car className="w-4 h-4 text-amber-600" />}
                {item.category === 'mode' && <Watch className="w-4 h-4 text-amber-600" />}
                {item.category === 'sport' && <Dumbbell className="w-4 h-4 text-amber-600" />}
                {item.category === 'cosmetiques' && <Sparkles className="w-4 h-4 text-amber-600" />}
                {item.category === 'alimentaire' && <Utensils className="w-4 h-4 text-amber-600" />}
                {item.category === 'meuble' && <Sofa className="w-4 h-4 text-amber-600" />}
                {item.category === 'electronique' && <Smartphone className="w-4 h-4 text-amber-600" />}
                {item.category === 'electromenager' && <PlugZap className="w-4 h-4 text-amber-600" />}
                Fiche Technique & Caractéristiques ({item.location.city || 'Kinshasa'})
              </h3>

              {item.category === 'immobilier' && (
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <span className="text-slate-500 block">Type de bien</span>
                    <span className="font-semibold text-slate-900">
                      {(item.specificDetails as ImmobilierDetails).propertyType}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Superficie</span>
                    <span className="font-semibold text-slate-900">
                      {(item.specificDetails as ImmobilierDetails).surfaceM2} m²
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Titre foncier</span>
                    <span className="font-semibold text-emerald-700 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      {(item.specificDetails as ImmobilierDetails).landTitleType}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Visites sur place</span>
                    <span className="font-semibold text-slate-900">
                      {(item.specificDetails as ImmobilierDetails).visitSchedule || 'Sur rendez-vous'}
                    </span>
                  </div>
                </div>
              )}

              {item.category === 'automobile' && (
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <span className="text-slate-500 block">Marque & Modèle</span>
                    <span className="font-semibold text-slate-900">
                      {(item.specificDetails as AutomobileDetails).brand}{' '}
                      {(item.specificDetails as AutomobileDetails).model} (
                      {(item.specificDetails as AutomobileDetails).year})
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Kilométrage certifié</span>
                    <span className="font-semibold text-slate-900">
                      {(item.specificDetails as AutomobileDetails).mileageKm?.toLocaleString()} km
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Carte rose RDC</span>
                    <span className="font-semibold text-emerald-700 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Originale vérifiée
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Contrôle technique</span>
                    <span className="font-semibold text-emerald-700 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Conforme
                    </span>
                  </div>
                </div>
              )}

              {item.category === 'mode' && (
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <span className="text-slate-500 block">Type d’objet</span>
                    <span className="font-semibold text-slate-900">
                      {(item.specificDetails as ModeDetails).itemType}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Marque de prestige</span>
                    <span className="font-semibold text-slate-900">
                      {(item.specificDetails as ModeDetails).brand}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Certificat d’authenticité</span>
                    <span className="font-semibold text-emerald-700 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Expertise notariée
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Écrin & Papiers d’origine</span>
                    <span className="font-semibold text-slate-900">
                      {(item.specificDetails as ModeDetails).boxAndPapers ? 'Complet' : 'Seul'}
                    </span>
                  </div>
                </div>
              )}

              {!['immobilier', 'automobile', 'mode'].includes(item.category) && (
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <span className="text-slate-500 block">Type de produit</span>
                    <span className="font-semibold text-slate-900">
                      {(item.specificDetails as GeneralProductDetails)?.productType || getCategoryLabel(item.category, language)}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Marque / Fabricant</span>
                    <span className="font-semibold text-slate-900">
                      {(item.specificDetails as GeneralProductDetails)?.brand || 'Origine certifiée'}{' '}
                      {(item.specificDetails as GeneralProductDetails)?.model || ''}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">État & Garantie</span>
                    <span className="font-semibold text-emerald-700 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      {(item.specificDetails as GeneralProductDetails)?.condition || 'Neuf'} ·{' '}
                      {(item.specificDetails as GeneralProductDetails)?.warranty || 'Garantie vendeur'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Remise / Livraison</span>
                    <span className="font-semibold text-slate-900">
                      {(item.specificDetails as GeneralProductDetails)?.deliveryMethod || 'Livraison ou retrait Kinshasa'}
                    </span>
                  </div>
                </div>
              )}
            </div>

            {/* Enhanced Seller Reputation & Rating Display */}
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#0B1F3A] text-amber-400 font-bold flex items-center justify-center text-sm shrink-0 shadow-xs">
                    {item.sellerName.substring(0, 2).toUpperCase()}
                  </div>
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-bold text-slate-900 text-sm">{item.sellerName}</span>
                      {currentAuctionItem.sellerIsPremium && (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300 text-[10px] font-bold">
                          <Award className="w-3 h-3 text-amber-600" />
                          {t(language, 'premiumSeller')}
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <StarRating
                        rating={currentAuctionItem.sellerRating ?? 4.8}
                        reviewsCount={currentAuctionItem.sellerReviewsCount ?? 24}
                        size="sm"
                      />
                      <span className="text-slate-300">·</span>
                      <span className="text-slate-500 text-[11px]">
                        {item.location.commune}, {item.location.city}
                      </span>
                    </div>
                  </div>
                </div>

                {isSellerVerified ? (
                  <div className="flex items-center gap-1 text-emerald-700 font-semibold text-xs bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200 self-start sm:self-center shrink-0">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    {t(language, 'sellerVerified')}
                  </div>
                ) : sellerVerificationStatus === 'pending' ? (
                  <div className="flex items-center gap-1 text-amber-800 font-semibold text-xs bg-amber-50 px-2.5 py-1 rounded-full border border-amber-200 self-start sm:self-center shrink-0">
                    <Clock className="w-4 h-4 text-amber-600" />
                    Vérification en cours
                  </div>
                ) : (
                  <div className="flex items-center gap-1 text-slate-600 font-medium text-xs bg-slate-100 px-2.5 py-1 rounded-full border border-slate-200 self-start sm:self-center shrink-0">
                    <AlertCircle className="w-4 h-4 text-slate-400" />
                    Non certifié
                  </div>
                )}
              </div>

              {currentUser?.id === currentAuctionItem.sellerId && !currentAuctionItem.isSponsored && (
                <div className="pt-2.5 border-t border-slate-200 flex items-center justify-between gap-2">
                  <span className="text-[11px] text-slate-600">
                    Boostez la visibilité de ce produit en tête du catalogue NgoluMarket ({settings.sponsoredProductPriceUsd ?? 1} USD).
                  </span>
                  <button
                    type="button"
                    disabled={isSponsoring}
                    onClick={async () => {
                      setIsSponsoring(true);
                      const res = await submitAdCampaign({
                        type: 'sponsored_product',
                        title: currentAuctionItem.title,
                        auctionId: currentAuctionItem.id,
                        provider: 'mpesa',
                        accountOrPhone: currentUser.phone,
                      });
                      setIsSponsoring(false);
                      if (res.success) {
                        setSponsorMessage('Produit sponsorisé activé (1 USD réglé) !');
                      } else {
                        setSponsorMessage(res.error || 'Erreur lors du sponsoring.');
                      }
                    }}
                    className="px-3 py-1.5 bg-[#0B1F3A] hover:bg-[#14325C] text-amber-300 font-bold rounded-lg text-[11px] shrink-0 transition-colors"
                  >
                    {isSponsoring ? 'Activation...' : `Sponsoriser (${settings.sponsoredProductPriceUsd ?? 1} USD)`}
                  </button>
                </div>
              )}

              {sponsorMessage && (
                <div className="p-2 bg-emerald-50 border border-emerald-200 rounded text-emerald-800 text-[11px] font-medium">
                  {sponsorMessage}
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Interactive Bidding / Buy Now / Real Payment Interface (5 cols) */}
          <div className="lg:col-span-5 flex flex-col space-y-4">
            {/* View Switcher Tabs */}
            <div className="flex p-1 bg-slate-100 rounded-xl border border-slate-200">
              <button
                type="button"
                onClick={() => setActiveTab('bid')}
                className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                  activeTab === 'bid'
                    ? 'bg-[#0B1F3A] text-white shadow'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {isFixedPrice ? (
                  <>
                    <ShoppingBag className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Achat Immédiat</span>
                  </>
                ) : (
                  <>
                    <Zap className="w-3.5 h-3.5 text-amber-400" />
                    <span>Salle des Enchères</span>
                  </>
                )}
              </button>

              <button
                type="button"
                onClick={() => setActiveTab('payment')}
                className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                  activeTab === 'payment'
                    ? 'bg-amber-500 text-slate-950 shadow'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Landmark className="w-3.5 h-3.5" />
                <span>{isFixedPrice ? 'Paiement Séquestre' : 'Paiement & Caution'}</span>
                {hasUserActiveDeposit && (
                  <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                )}
              </button>
            </div>

            {/* TAB 1: BIDDING ROOM OR BUY NOW MODULE */}
            {activeTab === 'bid' && (
              <>
                <div className="bg-[#0B1F3A] text-white rounded-xl p-5 shadow-lg border border-[#163254]">
                  {/* Live Flash Alert for Real-time Bids */}
                  {liveFlash && (
                    <div className="mb-4 p-2.5 bg-amber-500/20 border border-amber-400 rounded-lg text-amber-300 text-xs font-bold flex items-center gap-2 animate-pulse">
                      <span className="w-2 h-2 rounded-full bg-amber-400"></span>
                      <span>{liveFlash}</span>
                    </div>
                  )}

                  <div className="flex items-center justify-between pb-4 border-b border-slate-800">
                    <div>
                      <span className="text-[11px] text-slate-400 uppercase tracking-wider block">
                        {isFixedPrice
                          ? 'Prix de vente ferme'
                          : currentAuctionItem.bidsCount > 0
                          ? 'Meilleure offre actuelle'
                          : 'Prix de départ'}
                      </span>
                      <div className="text-2xl sm:text-3xl font-extrabold font-mono tabular-nums text-white transition-all">
                        {formatUsd(isFixedPrice ? effectiveFixedPrice : currentAuctionItem.currentPrice)}
                      </div>
                      <div className="text-xs text-amber-300 font-mono tabular-nums">
                        ≈ {formatCdf(isFixedPrice ? effectiveFixedPrice : currentAuctionItem.currentPrice, settings.currencyRateCdf)}
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-[11px] text-slate-400 uppercase tracking-wider block">
                        {isFixedPrice ? 'Disponibilité' : 'Temps restant'}
                      </span>
                      <div
                        className={`text-base font-bold font-mono tabular-nums flex items-center gap-1 justify-end ${
                          timeInfo.isUrgent ? 'text-amber-400' : 'text-slate-200'
                        }`}
                      >
                        <Clock className="w-4 h-4" />
                        {isFixedPrice ? 'Achat direct' : timeInfo.text}
                      </div>
                      <div className="text-[11px] text-slate-400 flex items-center gap-2 justify-end mt-1">
                        {!isFixedPrice && (
                          <span className="font-mono text-amber-300 font-semibold tabular-nums">
                            {currentAuctionItem.bidsCount} {currentAuctionItem.bidsCount === 1 ? 'offre' : 'offres'}
                          </span>
                        )}
                        <span className="flex items-center gap-1">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
                          <span className="font-mono text-emerald-400 font-medium">
                            {liveViewersCount} en direct
                          </span>
                        </span>
                      </div>
                    </div>
                  </div>

                  {!isFixedPrice && currentAuctionItem.highestBidderName && (
                    <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between text-[11px]">
                      <span className="text-slate-400">Meilleur enchérisseur :</span>
                      <span className="font-semibold text-amber-300">
                        {currentAuctionItem.highestBidderId === currentUser?.id
                          ? `${currentAuctionItem.highestBidderName} (Vous)`
                          : currentAuctionItem.highestBidderName}
                      </span>
                    </div>
                  )}

                  {/* FIXED PRICE SALE SECTION */}
                  {isFixedPrice ? (
                    <div className="mt-5 space-y-4">
                      {currentAuctionItem.status === 'terminee' ? (
                        <div className="p-4 bg-slate-800 rounded-xl text-center border border-slate-700">
                          <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto mb-2" />
                          <div className="text-sm font-bold text-white">Cet article a été vendu</div>
                          <p className="text-xs text-slate-400 mt-1">
                            Adjugé à{' '}
                            <strong className="text-slate-200">
                              {currentAuctionItem.highestBidderName || 'un acheteur NgoluMarket'}
                            </strong>{' '}
                            au prix ferme de {formatUsd(effectiveFixedPrice)}.
                          </p>
                        </div>
                      ) : (
                        <div className="space-y-4">
                          <div className="p-3 bg-emerald-950/60 border border-emerald-800/80 rounded-xl text-xs text-emerald-200 space-y-2">
                            <div className="flex items-start gap-2.5">
                              <ShoppingBag className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                              <div className="leading-relaxed">
                                <span className="font-bold block text-white">Vente Directe à Prix Fixe (Section 6)</span>
                                Tarif transparent : les frais de plateforme NgoluMarket sont fixés à{' '}
                                <strong className="text-amber-300">{buyerFeeUsd} USD</strong> à la charge de l’acheteur.
                              </div>
                            </div>

                            <div className="pt-2 border-t border-emerald-800/70 space-y-1 font-mono text-[11px]">
                              <div className="flex justify-between text-slate-300">
                                <span>Prix du produit :</span>
                                <span className="font-bold text-white">{formatUsd(effectiveFixedPrice)}</span>
                              </div>
                              <div className="flex justify-between text-slate-300">
                                <span>Frais NgoluMarket (acheteur) :</span>
                                <span className="font-bold text-amber-300">+{buyerFeeUsd} USD</span>
                              </div>
                              <div className="flex justify-between pt-1 border-t border-emerald-800/60 text-xs font-extrabold text-emerald-300">
                                <span>Total payé par l’acheteur :</span>
                                <span>{formatUsd(fixedTotalAmount)}</span>
                              </div>
                            </div>
                          </div>

                          {bidError && (
                            <div className="p-2.5 bg-rose-950/80 border border-rose-800 rounded text-rose-200 text-xs flex items-start gap-2">
                              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                              <span>{bidError}</span>
                            </div>
                          )}

                          {bidSuccess && (
                            <div className="p-2.5 bg-emerald-950/80 border border-emerald-800 rounded text-emerald-200 text-xs flex items-start gap-2">
                              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                              <span>{bidSuccess}</span>
                            </div>
                          )}

                          <button
                            type="button"
                            onClick={handleBuyNow}
                            className="w-full py-3.5 px-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-extrabold rounded-xl transition-all text-sm shadow-lg flex items-center justify-center gap-2"
                          >
                            <ShoppingBag className="w-4 h-4" />
                            <span>Commander maintenant ({formatUsd(fixedTotalAmount)})</span>
                          </button>

                          <button
                            type="button"
                            onClick={() => {
                              setPaymentPurpose('auction_settlement');
                              setPaymentAmountUsd(fixedTotalAmount);
                              setActiveTab('payment');
                            }}
                            className="w-full py-2.5 px-4 bg-[#14325C] hover:bg-[#1B4075] text-slate-100 font-semibold rounded-lg transition-colors text-xs flex items-center justify-center gap-2 border border-[#244B82]"
                          >
                            <Landmark className="w-3.5 h-3.5 text-amber-400" />
                            <span>Régler par Mobile Money, Carte ou Virement Bancaire</span>
                          </button>
                        </div>
                      )}
                    </div>
                  ) : (
                    /* AUCTION SALE SECTION */
                    <>
                      {/* Caution Guarantee Status Alert */}
                      {hasUserActiveDeposit ? (
                        <div className="mt-3.5 p-2 bg-emerald-950/60 border border-emerald-800/80 rounded-lg flex items-center justify-between text-xs text-emerald-300">
                          <div className="flex items-center gap-1.5">
                            <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                            <span>Caution de garantie active (Séquestre Rawbank)</span>
                          </div>
                          <span className="text-[10px] font-bold text-emerald-400 uppercase bg-emerald-900/60 px-1.5 py-0.5 rounded">
                            Habilité
                          </span>
                        </div>
                      ) : (
                        <div className="mt-3.5 p-2.5 bg-amber-950/50 border border-amber-800/60 rounded-lg flex items-center justify-between text-xs text-amber-200">
                          <div className="flex items-center gap-2">
                            <Lock className="w-4 h-4 text-amber-400 shrink-0" />
                            <span>Caution recommandée : {formatUsd(depositDefaultAmount)}</span>
                          </div>
                          <button
                            type="button"
                            onClick={() => {
                              setPaymentAmountUsd(depositDefaultAmount);
                              setPaymentPurpose('deposit_guarantee');
                              setActiveTab('payment');
                            }}
                            className="text-[11px] font-bold text-slate-950 bg-amber-400 hover:bg-amber-300 px-2 py-1 rounded transition-colors"
                          >
                            Payer via API
                          </button>
                        </div>
                      )}

                      {/* Status information if not in progress */}
                      {currentAuctionItem.status !== 'en_cours' ? (
                        <div className="mt-4 p-3 bg-slate-800 rounded-lg text-center">
                          <span className="text-sm font-semibold text-slate-300">
                            {statusInfo.label}
                          </span>
                          <p className="text-xs text-slate-400 mt-1">
                            {currentAuctionItem.status === 'terminee'
                              ? currentAuctionItem.highestBidderName
                                ? `Adjugé à ${currentAuctionItem.highestBidderName}`
                                : 'Aucune offre valide reçue à la clôture.'
                              : currentAuctionItem.status === 'programmee'
                              ? 'Les offres débuteront dès l’heure programmée.'
                              : 'En attente de reprise par les administrateurs.'}
                          </p>
                        </div>
                      ) : (
                        /* Interactive Bidding Form */
                        <form onSubmit={handlePlaceBid} className="mt-5 space-y-4">
                          <div className="flex items-center justify-between text-xs text-slate-400">
                            <span>Pas minimum d’enchère :</span>
                            <span className="font-mono text-slate-200">
                              +
                              {item.category === 'immobilier'
                                ? '5 000 USD'
                                : item.category === 'automobile'
                                ? '1 000 USD'
                                : '100 USD'}
                            </span>
                          </div>

                          <div className="flex items-center justify-between text-xs text-slate-400">
                            <span>Offre minimale requise :</span>
                            <span className="font-mono text-emerald-400 font-bold">
                              {formatUsd(minRequiredBid)}
                            </span>
                          </div>

                          {/* Quick increment buttons */}
                          <div className="grid grid-cols-3 gap-2">
                            <button
                              type="button"
                              onClick={() =>
                                handleIncrement(
                                  item.category === 'mode'
                                    ? 100
                                    : item.category === 'automobile'
                                    ? 1000
                                    : 5000
                                )
                              }
                              className="py-1.5 px-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono rounded border border-slate-700 transition-colors"
                            >
                              +
                              {item.category === 'mode'
                                ? '$100'
                                : item.category === 'automobile'
                                ? '$1k'
                                : '$5k'}
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                handleIncrement(
                                  item.category === 'mode'
                                    ? 250
                                    : item.category === 'automobile'
                                    ? 2500
                                    : 10000
                                )
                              }
                              className="py-1.5 px-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono rounded border border-slate-700 transition-colors"
                            >
                              +
                              {item.category === 'mode'
                                ? '$250'
                                : item.category === 'automobile'
                                ? '$2.5k'
                                : '$10k'}
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                handleIncrement(
                                  item.category === 'mode'
                                    ? 500
                                    : item.category === 'automobile'
                                    ? 5000
                                    : 25000
                                )
                              }
                              className="py-1.5 px-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono rounded border border-slate-700 transition-colors"
                            >
                              +
                              {item.category === 'mode'
                                ? '$500'
                                : item.category === 'automobile'
                                ? '$5k'
                                : '$25k'}
                            </button>
                          </div>

                          {/* Input field */}
                          <div>
                            <label className="block text-xs text-slate-300 font-medium mb-1">
                              Votre montant d’offre (USD)
                            </label>
                            <div className="relative">
                              <span className="absolute left-3 top-2.5 text-slate-400 font-mono text-sm">
                                $
                              </span>
                              <input
                                type="number"
                                min={minRequiredBid}
                                step={100}
                                value={bidAmount}
                                onChange={(e) => setBidAmount(Number(e.target.value))}
                                className="w-full pl-8 pr-16 py-2 bg-slate-800 border border-slate-700 focus:border-amber-400 focus:outline-none rounded-lg text-white font-mono text-base font-semibold"
                              />
                              <span className="absolute right-3 top-2.5 text-slate-400 text-xs font-semibold">
                                USD
                              </span>
                            </div>
                          </div>

                          {/* Bid Error or Success */}
                          {bidError && (
                            <div className="p-2.5 bg-rose-950/80 border border-rose-800 rounded text-rose-200 text-xs flex items-start gap-2">
                              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                              <span>{bidError}</span>
                            </div>
                          )}

                          {bidSuccess && (
                            <div className="p-2.5 bg-emerald-950/80 border border-emerald-800 rounded text-emerald-200 text-xs flex items-start gap-2">
                              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                              <span>{bidSuccess}</span>
                            </div>
                          )}

                          {/* Submit Button */}
                          <button
                            type="submit"
                            className="w-full py-3 px-4 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg transition-colors text-sm shadow-md flex items-center justify-center gap-2"
                          >
                            <span>Confirmer l’offre de {formatUsd(bidAmount)}</span>
                            <ArrowRight className="w-4 h-4" />
                          </button>

                          <p className="text-[11px] text-slate-400 text-center leading-tight">
                            Toute offre est transmise en direct par WebSocket. Règle anti-sniping : prolongation de +2 minutes si offre dans les 2 dernières minutes.
                          </p>
                        </form>
                      )}
                    </>
                  )}
                </div>

                {/* RECHARTS 'BIDDING HISTORY' TREND CHART */}
                {!isFixedPrice && (
                  <div className="border border-slate-200 rounded-xl p-4 bg-white shadow-xs">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <TrendingUp className="w-4 h-4 text-amber-600" />
                        <span className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                          Courbe des Offres (Bidding History)
                        </span>
                      </div>
                      <span className="text-[11px] font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                        +{formatUsd(priceIncrease)} ({percentIncrease}%)
                      </span>
                    </div>

                    <p className="text-[11px] text-slate-500 mb-2">
                      Progression chronologique des montants depuis le prix de départ ({formatUsd(currentAuctionItem.startPrice)}).
                    </p>

                    <div className="w-full h-36">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart
                          data={trendData}
                          margin={{ top: 8, right: 8, left: 0, bottom: 0 }}
                        >
                          <defs>
                            <linearGradient id="bidTrendGradient" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.35} />
                              <stop offset="95%" stopColor="#f59e0b" stopOpacity={0.0} />
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                          <XAxis
                            dataKey="label"
                            tick={{ fontSize: 10, fill: '#64748b' }}
                            stroke="#cbd5e1"
                          />
                          <YAxis
                            tick={{ fontSize: 10, fill: '#64748b' }}
                            stroke="#cbd5e1"
                            domain={['auto', 'auto']}
                            tickFormatter={(v) => `$${v >= 1000 ? `${Math.round(v / 1000)}k` : v}`}
                            width={42}
                          />
                          <RechartsTooltip
                            content={({ active, payload }) => {
                              if (active && payload && payload.length) {
                                const data = payload[0].payload;
                                return (
                                  <div className="bg-slate-900 text-white p-2.5 rounded-lg border border-slate-700 text-xs shadow-xl font-sans">
                                    <div className="text-[10px] text-amber-400 font-bold uppercase tracking-wider">
                                      {data.label} · {data.time}
                                    </div>
                                    <div className="font-mono text-sm font-extrabold text-white mt-0.5">
                                      {formatUsd(data.amount)}
                                    </div>
                                    <div className="text-[10px] text-slate-400 mt-0.5">
                                      Enchérisseur : <span className="text-slate-200">{data.bidder}</span>
                                    </div>
                                    <div className="text-[10px] text-amber-300 font-mono mt-0.5">
                                      ≈ {formatCdf(data.amount, settings.currencyRateCdf)}
                                    </div>
                                  </div>
                                );
                              }
                              return null;
                            }}
                          />
                          <Area
                            type="monotone"
                            dataKey="amount"
                            stroke="#d97706"
                            strokeWidth={2.5}
                            fillOpacity={1}
                            fill="url(#bidTrendGradient)"
                            dot={{ r: 3, fill: '#b45309', stroke: '#ffffff', strokeWidth: 1.5 }}
                            activeDot={{ r: 5, fill: '#f59e0b', stroke: '#ffffff', strokeWidth: 2 }}
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </div>
                )}

                {/* Live Bid History List */}
                <div className="border border-slate-200 rounded-xl p-4 flex-1 bg-white">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                      Historique des offres ({itemBids.length})
                    </span>
                    <span className="text-[11px] text-emerald-700 font-mono font-medium flex items-center gap-1">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping"></span>
                      Temps réel actif
                    </span>
                  </div>

                  {itemBids.length === 0 ? (
                    <div className="text-center py-5 text-xs text-slate-500">
                      {isFixedPrice
                        ? 'Aucun achat effectué pour le moment.'
                        : 'Aucune offre enregistrée. Soyez le premier enchérisseur !'}
                    </div>
                  ) : (
                    <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                      {itemBids.map((b, idx) => (
                        <div
                          key={b.id}
                          className={`flex items-center justify-between p-2 rounded-lg text-xs ${
                            idx === 0
                              ? 'bg-amber-50/90 border border-amber-300 font-semibold text-slate-900 shadow-xs'
                              : 'bg-slate-50 border border-slate-100 text-slate-600'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            {idx === 0 ? (
                              <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                            ) : (
                              <span className="w-2 h-2 rounded-full bg-slate-300"></span>
                            )}
                            <div>
                              <span className="font-medium text-slate-900">
                                {b.bidderId === currentUser?.id ? 'Vous' : b.bidderName}
                              </span>
                              <span className="text-[10px] text-slate-400 ml-1.5">
                                {new Date(b.timestamp).toLocaleTimeString('fr-FR', {
                                  hour: '2-digit',
                                  minute: '2-digit',
                                  second: '2-digit',
                                })}
                              </span>
                            </div>
                          </div>

                          <div className="font-mono tabular-nums font-bold text-slate-900">
                            {formatUsd(b.amount)}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </>
            )}

            {/* TAB 2: REAL PAYMENT & BANKING AGGREGATOR GATEWAY INTERFACE */}
            {activeTab === 'payment' && (
              <div className="bg-[#0B1F3A] text-white rounded-xl p-5 shadow-lg border border-[#163254] space-y-4">
                {/* Header */}
                <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <div className="p-2 bg-amber-500/10 rounded-lg text-amber-400">
                      <Landmark className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">Agrégateur Bancaire NgoluMarket</h4>
                      <p className="text-[11px] text-slate-400">
                        Séquestre multi-banques RDC (Rawbank, Equity BCDC, Ecobank, TMB, FBN, Mobile Money)
                      </p>
                    </div>
                  </div>
                  <span className="text-[10px] font-bold text-amber-400 bg-amber-500/20 px-2 py-0.5 rounded border border-amber-500/30">
                    BCC {settings.currencyRateCdf.toLocaleString('fr-FR')} CDF
                  </span>
                </div>

                {completedTransaction ? (
                  /* Official Electronic Receipt Card */
                  <div className="bg-white text-slate-900 rounded-xl p-4 space-y-4 border border-amber-300 shadow-md">
                    <div className="flex items-start justify-between border-b border-slate-200 pb-3">
                      <div>
                        <div className="flex items-center gap-1.5 text-emerald-700 font-bold text-xs uppercase">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                          Paiement Réel Enregistré & Consigné
                        </div>
                        <h5 className="font-bold text-slate-900 text-sm mt-0.5">
                          {completedTransaction.receiptNumber}
                        </h5>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] font-mono text-slate-400 block">RÉFÉRENCE API</span>
                        <span className="font-mono text-xs font-bold text-slate-800">
                          {completedTransaction.reference}
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3 text-xs">
                      <div>
                        <span className="text-slate-500 block text-[11px]">Montant réglé (USD)</span>
                        <span className="font-mono text-base font-extrabold text-slate-900">
                          {formatUsd(completedTransaction.amountUsd)}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[11px]">Équivalent officiel (CDF)</span>
                        <span className="font-mono text-xs font-bold text-amber-700">
                          {completedTransaction.amountCdf.toLocaleString()} CDF
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[11px]">Agrégateur & Canal</span>
                        <span className="font-semibold text-slate-800 uppercase">
                          {completedTransaction.aggregatorName || 'NgoluPay Hub'} · {completedTransaction.provider}
                        </span>
                        {completedTransaction.bankSwiftCode && (
                          <span className="block text-[10px] font-mono text-slate-500">
                            SWIFT : {completedTransaction.bankSwiftCode}
                          </span>
                        )}
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[11px]">Code Autorisation BCC</span>
                        <span className="font-mono text-[11px] font-bold text-emerald-700">
                          {completedTransaction.authorisationCode || 'AUTH-BCC-VALIDÉ'}
                        </span>
                      </div>
                      <div className="col-span-2 bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                        <span className="text-slate-500 block text-[10px]">Compte Séquestre Notarié Partenaire</span>
                        <span className="font-semibold text-slate-800 text-[11px]">
                          {completedTransaction.escrowAccountNumber || '05100-01234567890-44 (Rawbank Kinshasa Gombe)'}
                        </span>
                      </div>
                    </div>

                    <div className="flex gap-2 pt-1">
                      <button
                        type="button"
                        onClick={() => window.print()}
                        className="flex-1 py-2 px-3 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5"
                      >
                        <Printer className="w-3.5 h-3.5" />
                        Imprimer le Reçu
                      </button>

                      <button
                        type="button"
                        onClick={() => {
                          setCompletedTransaction(null);
                          setActiveTab('bid');
                        }}
                        className="flex-1 py-2 px-3 bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5"
                      >
                        <span>Retour aux Lots</span>
                        <ArrowRight className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ) : (
                  /* Payment Form */
                  <form onSubmit={handleExecutePayment} className="space-y-4">
                    {/* Purpose selector */}
                    <div>
                      <label className="block text-xs text-slate-300 font-medium mb-1">
                        Motif du versement
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        {!isFixedPrice && (
                          <button
                            type="button"
                            onClick={() => {
                              setPaymentPurpose('deposit_guarantee');
                              setPaymentAmountUsd(depositDefaultAmount);
                            }}
                            className={`py-2 px-2.5 rounded-lg text-xs font-semibold border transition-all text-left ${
                              paymentPurpose === 'deposit_guarantee'
                                ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                                : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-750'
                            }`}
                          >
                            <span className="block font-bold">Caution de Garantie</span>
                            <span className="text-[10px] text-slate-400">10% requis pour enchérir</span>
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => {
                            setPaymentPurpose('auction_settlement');
                            setPaymentAmountUsd(isFixedPrice ? fixedTotalAmount : currentAuctionItem.currentPrice);
                          }}
                          className={`py-2 px-2.5 rounded-lg text-xs font-semibold border transition-all text-left ${
                            isFixedPrice ? 'col-span-2' : ''
                          } ${
                            paymentPurpose === 'auction_settlement'
                              ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                              : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-750'
                          }`}
                        >
                          <span className="block font-bold">
                            {isFixedPrice ? 'Règlement Intégral du Prix Fixe' : 'Règlement Adjudication'}
                          </span>
                          <span className="text-[10px] text-slate-400">
                            {isFixedPrice
                              ? 'Acquisition définitive immédiate'
                              : 'Paiement intégral du bien remporté'}
                          </span>
                        </button>
                      </div>
                    </div>

                    {/* Banking Aggregator & Channel / Provider Selector */}
                    <BankingAggregatorSelector
                      variant="dark"
                      aggregatorGateway={aggregatorGateway}
                      onChangeAggregator={setAggregatorGateway}
                      method={paymentMethod}
                      onChangeMethod={setPaymentMethod}
                      provider={paymentProvider}
                      onChangeProvider={setPaymentProvider}
                    />

                    {/* Amount Input with live CDF conversion */}
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <label className="text-xs text-slate-300 font-medium">
                          Montant à régler (USD)
                        </label>
                        <span className="text-xs font-mono text-amber-300 font-semibold">
                          ≈ {((paymentAmountUsd || 0) * 2850).toLocaleString()} CDF
                        </span>
                      </div>
                      <div className="relative">
                        <span className="absolute left-3 top-2.5 text-slate-400 font-mono text-sm">
                          $
                        </span>
                        <input
                          type="number"
                          min={1}
                          step={1}
                          value={paymentAmountUsd}
                          onChange={(e) => setPaymentAmountUsd(Number(e.target.value))}
                          className="w-full pl-8 pr-16 py-2 bg-slate-800 border border-slate-700 focus:border-amber-400 focus:outline-none rounded-lg text-white font-mono text-base font-semibold"
                        />
                        <span className="absolute right-3 top-2.5 text-slate-400 text-xs font-semibold">
                          USD
                        </span>
                      </div>
                    </div>

                    {/* Account or Phone / Card Details */}
                    {paymentMethod === 'card' ? (
                      <div className="space-y-3">
                        <div>
                          <label className="block text-xs text-slate-300 font-medium mb-1">
                            Titulaire de la carte
                          </label>
                          <input
                            type="text"
                            placeholder="Nom complet"
                            value={cardHolder}
                            onChange={(e) => setCardHolder(e.target.value)}
                            className="w-full px-3 py-2 bg-slate-800 border border-slate-700 focus:border-amber-400 focus:outline-none rounded-lg text-white text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-xs text-slate-300 font-medium mb-1">
                            Numéro de carte bancaire
                          </label>
                          <input
                            type="text"
                            placeholder="4000 1234 5678 9010"
                            maxLength={19}
                            value={cardNumber}
                            onChange={(e) => setCardNumber(e.target.value)}
                            className="w-full px-3 py-2 bg-slate-800 border border-slate-700 focus:border-amber-400 focus:outline-none rounded-lg text-white font-mono text-xs tracking-wider"
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="block text-xs text-slate-300 font-medium mb-1">
                              Expiration (MM/AA)
                            </label>
                            <input
                              type="text"
                              placeholder="12/28"
                              maxLength={5}
                              value={cardExpiry}
                              onChange={(e) => setCardExpiry(e.target.value)}
                              className="w-full px-3 py-2 bg-slate-800 border border-slate-700 focus:border-amber-400 focus:outline-none rounded-lg text-white font-mono text-xs"
                            />
                          </div>
                          <div>
                            <label className="block text-xs text-slate-300 font-medium mb-1">
                              CVV (3 chiffres)
                            </label>
                            <input
                              type="password"
                              placeholder="123"
                              maxLength={4}
                              value={cardCvv}
                              onChange={(e) => setCardCvv(e.target.value)}
                              className="w-full px-3 py-2 bg-slate-800 border border-slate-700 focus:border-amber-400 focus:outline-none rounded-lg text-white font-mono text-xs"
                            />
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="text-xs text-slate-300 font-medium">
                            {paymentMethod === 'mobile_money'
                              ? 'Numéro de téléphone émetteur (+243)'
                              : 'Votre compte bancaire / RIB'}
                          </label>
                          {paymentMethod === 'mobile_money' && getPhoneOperatorBadge(accountOrPhone) && (
                            <span
                              className={`text-[10px] font-bold px-1.5 py-0.5 rounded border ${
                                getPhoneOperatorBadge(accountOrPhone)?.color
                              }`}
                            >
                              {getPhoneOperatorBadge(accountOrPhone)?.name}
                            </span>
                          )}
                        </div>
                        <input
                          type="text"
                          placeholder={
                            paymentMethod === 'mobile_money'
                              ? '+243 81 000 0000'
                              : '05100-XXXXXXXX-XX'
                          }
                          value={accountOrPhone}
                          onChange={(e) => setAccountOrPhone(e.target.value)}
                          className="w-full px-3 py-2 bg-slate-800 border border-slate-700 focus:border-amber-400 focus:outline-none rounded-lg text-white font-mono text-xs"
                        />
                      </div>
                    )}

                    {paymentError && (
                      <div className="p-2.5 bg-rose-950/80 border border-rose-800 rounded text-rose-200 text-xs flex items-start gap-2">
                        <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                        <span>{paymentError}</span>
                      </div>
                    )}

                    {/* Submit Button */}
                    <button
                      type="submit"
                      disabled={isProcessingPayment}
                      className="w-full py-3 px-4 bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-slate-950 font-bold rounded-lg transition-colors text-sm shadow-md flex items-center justify-center gap-2"
                    >
                      {isProcessingPayment ? (
                        <>
                          <span className="w-4 h-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin"></span>
                          <span>Autorisation bancaire en cours...</span>
                        </>
                      ) : (
                        <>
                          <Lock className="w-4 h-4" />
                          <span>
                            Confirmer le paiement sécurisé ({formatUsd(paymentAmountUsd)})
                          </span>
                        </>
                      )}
                    </button>

                    <div className="p-2.5 bg-slate-800/80 rounded-lg text-[11px] text-slate-400 flex items-start gap-2 leading-relaxed">
                      <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                      <span>
                        Fonds consignés sous séquestre notarié (Compte Rawbank NgoluMarket SAS, agrément BCC). Validation avec reçu officiel et bordereau certifié.
                      </span>
                    </div>
                  </form>
                )}
              </div>
            )}

            {/* Financial Transparency Box */}
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-1.5 text-slate-600">
              <div className="font-bold text-[#0B1F3A] flex items-center gap-1.5">
                <Info className="w-3.5 h-3.5 text-[#0B1F3A]" />
                Règles Commerciales & Séquestre NgoluMarket
              </div>
              <p className="text-[11px] leading-relaxed">
                {isFixedPrice
                  ? `Vente à prix fixe : publication gratuite pour le vendeur, frais fixes NgoluMarket de ${settings.fixedPriceBuyerFeeUsd ?? 1} USD à la charge de l’acheteur. Paiement sécurisé sous séquestre Rawbank.`
                  : `Vente aux enchères : participation gratuite pour les acheteurs, commission de ${settings.commissionRatePercent}% du prix final à la charge du vendeur Premium.`}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
