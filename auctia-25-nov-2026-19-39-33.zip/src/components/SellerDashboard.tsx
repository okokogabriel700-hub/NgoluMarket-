import React, { useState } from 'react';
import {
  AlertCircle,
  Award,
  CheckCircle2,
  Clock,
  FileCheck,
  FileText,
  Megaphone,
  PlusCircle,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  Upload,
} from 'lucide-react';
import { useAuctia } from '../context/AuctiaContext';
import { AssetVerificationDocument, AuctionItem, DocumentVerificationStatus } from '../types';
import { calculateTimeRemaining, formatUsd, getCategoryLabel, getStatusLabel } from '../utils/formatters';

interface SellerDashboardProps {
  onOpenNewAuction: () => void;
  onSelectAuction: (item: AuctionItem) => void;
  onOpenVerification: () => void;
  onOpenPremium: () => void;
}

export const SellerDashboard: React.FC<SellerDashboardProps> = ({
  onOpenNewAuction,
  onSelectAuction,
  onOpenVerification,
  onOpenPremium,
}) => {
  const {
    currentUser,
    auctions,
    settlements,
    sellerProfiles,
    settings,
    language,
    adCampaigns,
    submitAdCampaign,
    uploadAssetVerificationDocuments,
  } = useAuctia();

  const [adTitle, setAdTitle] = useState('');
  const [adStatusMsg, setAdStatusMsg] = useState<string | null>(null);
  const [isSubmittingAd, setIsSubmittingAd] = useState(false);
  const [docUploadStatusMsg, setDocUploadStatusMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [uploadingAuctionId, setUploadingAuctionId] = useState<string | null>(null);

  if (!currentUser) return null;

  const myProfile = sellerProfiles.find((p) => p.userId === currentUser.id);
  const myAuctions = auctions.filter((a) => a.sellerId === currentUser.id);
  const myAds = adCampaigns.filter((c) => c.userId === currentUser.id);

  const activeAuctions = myAuctions.filter((a) => a.status === 'en_cours');
  const pendingAuctions = myAuctions.filter((a) => a.status === 'en_attente');
  const completedAuctions = myAuctions.filter((a) => a.status === 'terminee');

  const mySettlements = settlements.filter((s) => s.sellerId === currentUser.id);
  const totalGmv = completedAuctions.reduce((acc, a) => acc + a.currentPrice, 0);
  const totalNet = mySettlements.reduce((acc, s) => acc + s.netSellerAmount, 0);
  const totalCommission = mySettlements.reduce((acc, s) => acc + s.commissionAmount, 0);

  const handleSponsorProduct = async (item: AuctionItem) => {
    setIsSubmittingAd(true);
    const res = await submitAdCampaign({
      type: 'sponsored_product',
      title: item.title,
      auctionId: item.id,
      provider: 'mpesa',
      accountOrPhone: currentUser.phone,
    });
    setIsSubmittingAd(false);
    setAdStatusMsg(
      res.success
        ? `Produit "${item.title}" sponsorisé en tête du catalogue (${settings.sponsoredProductPriceUsd ?? 1} USD).`
        : res.error || 'Erreur lors du sponsoring.'
    );
  };

  const handleBannerAdSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!adTitle.trim()) return;
    setIsSubmittingAd(true);
    const res = await submitAdCampaign({
      type: 'banner_ad',
      title: adTitle.trim(),
      provider: 'mpesa',
      accountOrPhone: currentUser.phone,
    });
    setIsSubmittingAd(false);
    if (res.success) {
      setAdTitle('');
      setAdStatusMsg(`Publicité "${adTitle}" enregistrée (${settings.adMonthlyPriceUsd ?? 1} USD / mois).`);
    } else {
      setAdStatusMsg(res.error || 'Erreur lors de la création de la publicité.');
    }
  };

  const getDocStatusBadge = (status?: DocumentVerificationStatus) => {
    const s = status || 'pending';
    if (s === 'verified') {
      return {
        label: 'Document Verification : Verified',
        classes: 'bg-emerald-50 text-emerald-800 border-emerald-200',
      };
    }
    if (s === 'rejected') {
      return {
        label: 'Document Verification : Rejected',
        classes: 'bg-rose-50 text-rose-800 border-rose-200',
      };
    }
    return {
      label: 'Document Verification : Pending',
      classes: 'bg-amber-50 text-amber-800 border-amber-200',
    };
  };

  const handleUploadAssetDocs = async (auctionId: string, files: FileList | null) => {
    if (!files || files.length === 0) return;
    setDocUploadStatusMsg(null);
    const validFiles: File[] = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const lower = file.name.toLowerCase();
      const isValidType =
        file.type === 'application/pdf' ||
        file.type === 'image/jpeg' ||
        file.type === 'image/jpg' ||
        lower.endsWith('.pdf') ||
        lower.endsWith('.jpg') ||
        lower.endsWith('.jpeg');
      if (!isValidType) {
        setDocUploadStatusMsg({
          type: 'err',
          text: `Format invalide (${file.name}). Formats acceptés uniquement : PDF ou JPG.`,
        });
        return;
      }
      if (file.size > 5 * 1024 * 1024) {
        setDocUploadStatusMsg({
          type: 'err',
          text: `Fichier trop volumineux (${file.name}). Taille maximale : 5 Mo par fichier.`,
        });
        return;
      }
      validFiles.push(file);
    }

    setUploadingAuctionId(auctionId);
    try {
      const docs: AssetVerificationDocument[] = await Promise.all(
        validFiles.map(
          (file, idx) =>
            new Promise<AssetVerificationDocument>((resolve, reject) => {
              const reader = new FileReader();
              const resolvedType: AssetVerificationDocument['fileType'] =
                file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf')
                  ? 'application/pdf'
                  : 'image/jpeg';
              reader.onload = () => {
                resolve({
                  id: `adoc-${Date.now()}-${idx}`,
                  name: file.name.replace(/\.[^/.]+$/, ''),
                  fileName: file.name,
                  fileType: resolvedType,
                  fileSize: `${Math.max(1, Math.round(file.size / 1024))} Ko`,
                  fileUrl: String(reader.result || ''),
                  status: 'pending',
                  uploadedAt: new Date().toISOString(),
                });
              };
              reader.onerror = () => reject(new Error('Erreur de lecture du fichier'));
              reader.readAsDataURL(file);
            })
        )
      );

      const res = await uploadAssetVerificationDocuments(auctionId, docs);
      if (res.success) {
        setDocUploadStatusMsg({
          type: 'ok',
          text: `${docs.length} fichier(s) PDF/JPG transmis pour vérification documentaire (statut : Pending).`,
        });
      } else {
        setDocUploadStatusMsg({
          type: 'err',
          text: res.error || 'Échec du téléversement des documents.',
        });
      }
    } catch {
      setDocUploadStatusMsg({
        type: 'err',
        text: 'Impossible de lire les fichiers sélectionnés.',
      });
    } finally {
      setUploadingAuctionId(null);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-slate-200 gap-4">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            <h1 className="text-2xl font-bold text-[#0B1F3A]">
              {myProfile?.companyName || currentUser.companyName || currentUser.name}
            </h1>
            {myProfile?.verificationStatus === 'verified' ? (
              <span className="text-xs text-emerald-800 bg-emerald-50 px-2.5 py-0.5 rounded font-bold border border-emerald-200 flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                Vendeur Vérifié & Certifié
              </span>
            ) : myProfile?.verificationStatus === 'rejected' ? (
              <span className="text-xs text-rose-800 bg-rose-50 px-2.5 py-0.5 rounded font-bold border border-rose-200 flex items-center gap-1">
                <ShieldAlert className="w-3.5 h-3.5 text-rose-600" />
                Vérification Rejetée
              </span>
            ) : myProfile ? (
              <span className="text-xs text-amber-800 bg-amber-50 px-2.5 py-0.5 rounded font-bold border border-amber-200 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-amber-600" />
                Vérification en cours
              </span>
            ) : (
              <span className="text-xs text-slate-600 bg-slate-100 px-2.5 py-0.5 rounded font-semibold border border-slate-200 flex items-center gap-1">
                Non vérifié
              </span>
            )}
            {currentUser.isPremium ? (
              <span className="text-xs text-amber-900 bg-amber-100 px-2.5 py-0.5 rounded font-bold border border-amber-300 flex items-center gap-1">
                <Award className="w-3.5 h-3.5 text-amber-600" />
                Compte Premium Actif
              </span>
            ) : (
              <span className="text-xs text-slate-700 bg-slate-100 px-2.5 py-0.5 rounded font-semibold border border-slate-200">
                Compte Normal (Gratuit)
              </span>
            )}
          </div>
          <p className="text-xs text-slate-500 mt-1">
            RCCM : {myProfile?.rccmNumber || 'Non renseigné'} · Siège : {myProfile?.address || currentUser.city}
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={onOpenVerification}
            className="px-3.5 py-2.5 bg-white hover:bg-slate-50 text-[#0B1F3A] border border-slate-300 rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
          >
            <FileCheck className="w-4 h-4 text-[#0B1F3A]" />
            {myProfile ? 'Dossier KYC Vendeur' : 'Vérifier mon compte'}
          </button>
          {!currentUser.isPremium && (
            <button
              type="button"
              onClick={onOpenPremium}
              className="px-3.5 py-2.5 bg-amber-400 hover:bg-amber-300 text-[#0B1F3A] rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 shadow-sm cursor-pointer whitespace-nowrap"
            >
              <Award className="w-4 h-4" />
              Passer Premium ({settings.premiumSubscriptionPriceUsd ?? 50}$/trim.)
            </button>
          )}
          <button
            type="button"
            onClick={onOpenNewAuction}
            className="px-4 py-2.5 bg-[#0B1F3A] hover:bg-[#14325C] text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-2 shadow-sm cursor-pointer whitespace-nowrap"
          >
            <PlusCircle className="w-4 h-4 text-amber-400" />
            Publier un produit / enchère
          </button>
        </div>
      </div>

      {/* Seller Verification Status & Compliance Block */}
      <div className="bg-white rounded-xl border border-slate-200 p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          {myProfile?.verificationStatus === 'verified' ? (
            <div className="p-2.5 rounded-lg bg-emerald-50 text-emerald-600 shrink-0">
              <CheckCircle2 className="w-5 h-5" />
            </div>
          ) : myProfile?.verificationStatus === 'rejected' ? (
            <div className="p-2.5 rounded-lg bg-rose-50 text-rose-600 shrink-0">
              <ShieldAlert className="w-5 h-5" />
            </div>
          ) : (
            <div className="p-2.5 rounded-lg bg-amber-50 text-amber-600 shrink-0">
              <Clock className="w-5 h-5" />
            </div>
          )}

          <div className="space-y-1 text-xs">
            <div className="font-bold text-sm text-[#0B1F3A]">
              {myProfile?.verificationStatus === 'verified'
                ? 'Statut de Certification : Compte Vendeur Vérifié'
                : myProfile?.verificationStatus === 'rejected'
                ? 'Statut de Certification : Dossier Rejeté par l’administration'
                : myProfile
                ? 'Statut de Certification : Dossier en attente de validation'
                : 'Statut de Certification : Compte non vérifié'}
            </div>
            <p className="text-slate-600 max-w-2xl">
              {myProfile?.verificationStatus === 'verified'
                ? `Votre entreprise (${myProfile.companyName}) est certifiée conforme. Le badge "Vendeur vérifié" s'affiche sur toutes vos fiches produits.${myProfile.reviewedAt ? ` Validé le ${new Date(myProfile.reviewedAt).toLocaleDateString('fr-FR')}.` : ''}`
                : myProfile?.verificationStatus === 'rejected'
                ? `Motif de rejet : ${myProfile.verificationNotes || 'Documents incomplets ou illisibles. Veuillez mettre à jour vos pièces justificatives et resoumettre.'}`
                : myProfile
                ? `${myProfile.documents?.length || 0} pièce(s) justificative(s) transmise(s). L'équipe conformité NgoluMarket examine votre dossier.`
                : 'Soumettez votre numéro RCCM, Identification Nationale ou pièce d’identité officielle pour obtenir le badge Vendeur Vérifié et renforcer la confiance des acheteurs.'}
            </p>
            {myProfile?.documents && myProfile.documents.length > 0 && (
              <div className="flex flex-wrap items-center gap-2 pt-1">
                {myProfile.documents.map((doc) => (
                  <span
                    key={doc.id}
                    className={`text-[11px] font-medium px-2 py-0.5 rounded border ${
                      doc.status === 'verified'
                        ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                        : doc.status === 'rejected'
                        ? 'bg-rose-50 text-rose-800 border-rose-200'
                        : 'bg-slate-50 text-slate-700 border-slate-200'
                    }`}
                  >
                    {doc.name} · {doc.status === 'verified' ? 'Validé' : doc.status === 'rejected' ? 'Rejeté' : 'En attente'}
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>

        <button
          type="button"
          onClick={onOpenVerification}
          className={`px-4 py-2.5 rounded-lg text-xs font-bold transition-colors shrink-0 cursor-pointer whitespace-nowrap ${
            myProfile?.verificationStatus === 'rejected'
              ? 'bg-rose-600 hover:bg-rose-500 text-white'
              : myProfile?.verificationStatus === 'verified'
              ? 'bg-slate-100 hover:bg-slate-200 text-[#0B1F3A]'
              : 'bg-[#0B1F3A] hover:bg-[#14325C] text-white'
          }`}
        >
          {myProfile?.verificationStatus === 'rejected'
            ? 'Corriger et resoumettre mon dossier'
            : myProfile?.verificationStatus === 'verified'
            ? 'Gérer mes documents justificatifs'
            : myProfile
            ? 'Compléter / Modifier mon dossier'
            : 'Soumettre mes documents'}
        </button>
      </div>

      {adStatusMsg && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-semibold">
          {adStatusMsg}
        </div>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <span className="text-xs text-slate-500 block">Annonces actives</span>
          <span className="text-2xl font-bold text-[#0B1F3A] font-mono tabular-nums">
            {activeAuctions.length}
          </span>
          <span className="text-[11px] text-emerald-600 block mt-1 font-medium">En ligne à Kinshasa</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <span className="text-xs text-slate-500 block">En attente</span>
          <span className="text-2xl font-bold text-amber-600 font-mono tabular-nums">
            {pendingAuctions.length}
          </span>
          <span className="text-[11px] text-slate-400 block mt-1">Modération NgoluMarket</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <span className="text-xs text-slate-500 block">Volume vendu (GMV)</span>
          <span className="text-2xl font-bold text-[#0B1F3A] font-mono tabular-nums">
            {formatUsd(totalGmv)}
          </span>
          <span className="text-[11px] text-slate-400 block mt-1">Total ventes conclues</span>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200">
          <span className="text-xs text-slate-500 block">Net vendeur</span>
          <span className="text-2xl font-bold text-emerald-700 font-mono tabular-nums">
            {formatUsd(totalNet)}
          </span>
          <span className="text-[11px] text-slate-400 block mt-1 font-mono">
            Commissions ({settings.commissionRatePercent}%) : {formatUsd(totalCommission)}
          </span>
        </div>
      </div>

      {/* Section 9: Publicité & Produits Sponsorisés */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-base font-bold text-[#0B1F3A] flex items-center gap-2">
              <Megaphone className="w-5 h-5 text-amber-500" />
              Publicité ({settings.adMonthlyPriceUsd ?? 1} USD / mois) & Sponsoring ({settings.sponsoredProductPriceUsd ?? 1} USD / produit)
            </h2>
            <p className="text-xs text-slate-500">
              Demandez une mise en avant publicitaire pour votre boutique ou sponsorisez vos produits en tête du catalogue.
            </p>
          </div>
          <span className="text-xs font-mono text-[#0B1F3A] font-bold">
            {myAds.length} campagne(s)
          </span>
        </div>

        <form onSubmit={handleBannerAdSubmit} className="flex flex-col sm:flex-row gap-2">
          <input
            type="text"
            required
            placeholder="Titre de votre campagne publicitaire (ex: Promo Électronique Gombe -20%)"
            value={adTitle}
            onChange={(e) => setAdTitle(e.target.value)}
            className="flex-1 px-3 py-2 text-xs border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#0B1F3A]"
          />
          <button
            type="submit"
            disabled={isSubmittingAd}
            className="px-4 py-2 bg-[#0B1F3A] hover:bg-[#14325C] text-amber-300 font-bold text-xs rounded-lg cursor-pointer shrink-0"
          >
            Lancer une publicité ({settings.adMonthlyPriceUsd ?? 1} USD / mois)
          </button>
        </form>
      </div>

      {/* Listings Management */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-[#0B1F3A]">Vos produits publiés & dossiers d’actifs</h2>
            <p className="text-xs text-slate-500">
              Un actif ne peut être publié en ligne qu’une fois son statut Document Verification validé (Verified) par l’administrateur.
            </p>
          </div>
          <span className="text-xs text-slate-500 font-mono">{myAuctions.length} annonces</span>
        </div>

        {docUploadStatusMsg && (
          <div
            className={`p-3 rounded-lg border text-xs font-semibold flex items-center gap-2 ${
              docUploadStatusMsg.type === 'ok'
                ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                : 'bg-rose-50 border-rose-200 text-rose-800'
            }`}
          >
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{docUploadStatusMsg.text}</span>
          </div>
        )}

        {myAuctions.length === 0 ? (
          <div className="text-center py-8 text-xs text-slate-500">
            Vous n’avez publié aucun produit pour l’instant.
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {myAuctions.map((item) => {
              const statusInfo = getStatusLabel(item.status, language);
              const time = calculateTimeRemaining(item.endDate, item.startDate, item.status, language);
              const docBadge = getDocStatusBadge(item.documentVerificationStatus);
              const assetDocs = item.assetDocuments || [];

              return (
                <div
                  key={item.id}
                  className="py-4 flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div className="flex items-start gap-4">
                    <img
                      src={item.images[0]}
                      alt={item.title}
                      referrerPolicy="no-referrer"
                      className="w-16 h-14 object-cover rounded-lg border border-slate-200 shrink-0 mt-0.5"
                    />
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2 text-xs">
                        <span className="font-semibold text-slate-500">
                          {getCategoryLabel(item.category, language)}
                        </span>
                        <span className="text-slate-300">·</span>
                        <span className={statusInfo.textClass}>{statusInfo.label}</span>
                        <span
                          className={`px-2 py-0.5 rounded border text-[10px] font-bold ${docBadge.classes}`}
                        >
                          {docBadge.label}
                        </span>
                        {item.isSponsored && (
                          <span className="px-1.5 py-0.5 rounded bg-amber-100 text-amber-900 font-bold text-[10px]">
                            Sponsorisé
                          </span>
                        )}
                      </div>
                      <h3 className="text-sm font-semibold text-slate-900">{item.title}</h3>
                      <div className="text-xs text-slate-500 flex items-center gap-3 font-mono">
                        <span>{formatUsd(item.fixedPrice || item.currentPrice)}</span>
                        <span>·</span>
                        <span>{time.text}</span>
                        <span>·</span>
                        <span>{assetDocs.length} pièce(s) PDF/JPG</span>
                      </div>
                      {item.documentVerificationNotes && (
                        <p className="text-[11px] text-slate-600 bg-slate-50 border border-slate-200 rounded px-2 py-1">
                          Note admin : {item.documentVerificationNotes}
                        </p>
                      )}
                      {assetDocs.length > 0 && (
                        <div className="flex flex-wrap gap-1.5 pt-0.5">
                          {assetDocs.map((doc) => (
                            <a
                              key={doc.id}
                              href={doc.fileUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              download={doc.fileName}
                              className="inline-flex items-center gap-1 px-2 py-0.5 rounded border border-slate-200 bg-slate-50 hover:bg-slate-100 text-[10px] text-slate-700 font-medium"
                            >
                              <FileText className="w-3 h-3 text-[#0B1F3A]" />
                              <span className="truncate max-w-[140px]">{doc.fileName}</span>
                            </a>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 shrink-0">
                    <label className="px-3 py-2 text-xs font-bold text-[#0B1F3A] bg-white hover:bg-slate-50 border border-slate-300 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer">
                      <Upload className="w-3.5 h-3.5" />
                      {uploadingAuctionId === item.id ? 'Envoi...' : '+ PDF / JPG'}
                      <input
                        type="file"
                        accept=".pdf,.jpg,.jpeg,application/pdf,image/jpeg"
                        multiple
                        className="hidden"
                        disabled={uploadingAuctionId === item.id}
                        onChange={(e) => {
                          handleUploadAssetDocs(item.id, e.target.files);
                          e.currentTarget.value = '';
                        }}
                      />
                    </label>
                    {!item.isSponsored && item.status === 'en_cours' && (
                      <button
                        type="button"
                        disabled={isSubmittingAd}
                        onClick={() => handleSponsorProduct(item)}
                        className="px-3 py-2 text-xs font-bold text-[#0B1F3A] bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors flex items-center gap-1 cursor-pointer"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        Sponsoriser ({settings.sponsoredProductPriceUsd ?? 1}$)
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => onSelectAuction(item)}
                      className="px-3.5 py-2 text-xs font-semibold text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors cursor-pointer"
                    >
                      Consulter
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Accounting & Commissions Table */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
        <div>
          <h2 className="text-base font-bold text-[#0B1F3A]">
            Relevé des ventes & commissions NgoluMarket
          </h2>
          <p className="text-xs text-slate-500">
            Ventes à prix fixe : 0% commission vendeur (1 USD payé par l’acheteur) · Enchères : {settings.commissionRatePercent}% commission vendeur.
          </p>
        </div>

        {mySettlements.length === 0 ? (
          <div className="text-center py-6 text-xs text-slate-500">
            Aucune vente finalisée pour l’instant.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50 text-slate-500 uppercase font-semibold text-[10px] border-b border-slate-200">
                <tr>
                  <th className="py-2.5 px-3">N° Commande & Produit</th>
                  <th className="py-2.5 px-3">Mode</th>
                  <th className="py-2.5 px-3">Montant</th>
                  <th className="py-2.5 px-3">Commission</th>
                  <th className="py-2.5 px-3">Net vendeur</th>
                  <th className="py-2.5 px-3">Statut</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono">
                {mySettlements.map((s) => (
                  <tr key={s.id} className="hover:bg-slate-50">
                    <td className="py-3 px-3 font-sans">
                      <div className="font-bold text-slate-900">{s.auctionTitle}</div>
                      <div className="text-[10px] text-slate-400 font-mono">{s.orderNumber || s.id}</div>
                    </td>
                    <td className="py-3 px-3 font-sans">
                      {s.saleType === 'prix_fixe' ? 'Prix Fixe' : 'Enchères'}
                    </td>
                    <td className="py-3 px-3 font-bold text-slate-900">{formatUsd(s.winningBid)}</td>
                    <td className="py-3 px-3 text-rose-600">-{formatUsd(s.commissionAmount)}</td>
                    <td className="py-3 px-3 text-emerald-700 font-bold">
                      {formatUsd(s.netSellerAmount)}
                    </td>
                    <td className="py-3 px-3 font-sans">
                      <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                        {s.settlementStatus}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
