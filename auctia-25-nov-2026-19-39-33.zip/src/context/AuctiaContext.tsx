import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  INITIAL_AUCTIONS,
  INITIAL_AUDIT_LOGS,
  INITIAL_BIDS,
  INITIAL_NOTIFICATIONS,
  INITIAL_SELLER_PROFILES,
  INITIAL_SETTINGS,
  INITIAL_SETTLEMENTS,
  INITIAL_USERS,
} from '../data/mockData';
import {
  AdCampaign,
  AggregatorGatewayInfo,
  AssetVerificationDocument,
  AuctionItem,
  AuctionStatus,
  AuditLog,
  BankAggregatorId,
  Bid,
  BuyerVerificationProfile,
  Category,
  ConnectedBankInfo,
  DocumentVerificationStatus,
  EmailNotification,
  FinancialSettlement,
  Language,
  NotificationItem,
  NotificationPreferences,
  OrderStatus,
  PaymentMethod,
  PaymentProvider,
  PaymentPurpose,
  PaymentTransaction,
  PlatformSettings,
  SellerDocument,
  SellerProfile,
  User,
  VerificationTier,
  WsMessage,
} from '../types';
import { ALL_CATEGORIES } from '../utils/formatters';
import { wsService } from '../services/websocketService';

export interface RealtimeBidEvent {
  auctionId: string;
  bid: Bid;
  newPrice: number;
  newEndDate: string;
  antiSnipingTriggered?: boolean;
}

interface AuctiaContextType {
  currentUser: User | null;
  users: User[];
  sellerProfiles: SellerProfile[];
  auctions: AuctionItem[];
  bids: Bid[];
  settlements: FinancialSettlement[];
  auditLogs: AuditLog[];
  notifications: NotificationItem[];
  emailNotifications: EmailNotification[];
  notificationPreferences: NotificationPreferences;
  settings: PlatformSettings;
  watchlist: string[];
  recentlyViewedIds: string[];
  language: Language;
  setLanguage: (lang: Language) => void;
  recordProductView: (auctionId: string) => void;
  adCampaigns: AdCampaign[];
  submitAdCampaign: (params: {
    type: 'banner_ad' | 'sponsored_product';
    title: string;
    auctionId?: string;
    method?: PaymentMethod;
    provider: PaymentProvider;
    accountOrPhone: string;
  }) => Promise<{ success: boolean; error?: string }>;
  reviewAdCampaign: (campaignId: string, status: 'active' | 'rejected' | 'suspended') => void;
  activatePremiumSubscription: (params: {
    method: PaymentMethod;
    provider: PaymentProvider;
    aggregatorGateway?: BankAggregatorId;
    accountOrPhone: string;
    userOverride?: User;
  }) => Promise<{ success: boolean; transaction?: PaymentTransaction; error?: string }>;
  updateOrderStatus: (settlementId: string, orderStatus: OrderStatus) => void;
  toggleCategoryEnabled: (cat: Category) => void;
  updateUserProfile: (updates: Partial<Pick<User, 'name' | 'email' | 'phone' | 'city' | 'avatar'>>) => void;
  latestBidEvent: RealtimeBidEvent | null;
  // WebSocket state
  isWsConnected: boolean;
  wsState: 'connected' | 'connecting' | 'disconnected';
  activeViewersMap: Record<string, number>;
  subscribeToAuctionRoom: (auctionId: string) => void;
  unsubscribeFromAuctionRoom: (auctionId: string) => void;
  // Banking Aggregator & Payments state
  aggregatorGateways: AggregatorGatewayInfo[];
  connectedBanks: ConnectedBankInfo[];
  toggleAggregatorGateway: (gatewayId: BankAggregatorId) => Promise<void>;
  refreshAggregatorChannels: () => Promise<void>;
  payments: PaymentTransaction[];
  processPayment: (params: {
    amountUsd: number;
    purpose: PaymentPurpose;
    method?: PaymentMethod;
    provider: PaymentProvider;
    aggregatorGateway?: BankAggregatorId;
    accountOrPhone: string;
    auctionId?: string;
    auctionTitle?: string;
    notes?: string;
    userOverride?: User;
  }) => Promise<{ success: boolean; transaction?: PaymentTransaction; error?: string }>;
  // User Verification state
  buyerVerifications: BuyerVerificationProfile[];
  requestBuyerPhoneOtp: (phone: string) => Promise<{ success: boolean; mockCode?: string; error?: string }>;
  verifyBuyerPhoneOtp: (code: string) => { success: boolean; error?: string };
  submitBuyerEnhancedVerification: (params: {
    documentType: 'ceni_voter_card' | 'passport' | 'driving_license';
    documentNumber: string;
    bankName: string;
    bankAttestationNumber?: string;
    residenceCommune: string;
    residenceQuarter?: string;
  }) => Promise<{ success: boolean; error?: string }>;
  adminReviewBuyerVerification: (
    userId: string,
    action: 'approve' | 'reject',
    reason?: string
  ) => Promise<{ success: boolean; error?: string }>;
  loginAs: (userId: string | null) => void;
  login: (identifier: string, password?: string) => { success: boolean; error?: string };
  logout: () => void;
  registerUser: (userData: Omit<User, 'id' | 'createdAt'>) => User;
  registerSellerProfile: (profile: Omit<SellerProfile, 'submittedAt' | 'verificationStatus'>) => void;
  uploadSellerDocument: (userId: string, doc: Omit<SellerDocument, 'id' | 'uploadedAt' | 'status'>) => void;
  removeSellerDocument: (userId: string, docId: string) => void;
  placeBid: (auctionId: string, amount: number) => { success: boolean; error?: string };
  buyFixedPriceItem: (auctionId: string) => { success: boolean; error?: string };
  toggleWatchlist: (auctionId: string) => void;
  submitAuction: (itemData: Partial<AuctionItem>) => { success: boolean; error?: string };
  uploadAssetVerificationDocuments: (
    auctionId: string,
    docs: AssetVerificationDocument[]
  ) => { success: boolean; error?: string };
  updateAssetDocumentVerification: (
    auctionId: string,
    status: DocumentVerificationStatus,
    notes?: string,
    publishIfVerified?: boolean
  ) => { success: boolean; error?: string };
  approveAuction: (auctionId: string, notes?: string) => { success: boolean; error?: string };
  rejectAuction: (auctionId: string, reason: string) => void;
  suspendAuction: (auctionId: string, reason: string) => void;
  resumeAuction: (auctionId: string) => void;
  closeAuction: (auctionId: string) => void;
  updateSettings: (newSettings: Partial<PlatformSettings>) => void;
  updateNotificationPreferences: (prefs: Partial<NotificationPreferences>) => void;
  updateSettlementStatus: (
    settlementId: string,
    status: FinancialSettlement['settlementStatus'],
    notes?: string
  ) => void;
  verifySeller: (
    userId: string,
    approve: boolean,
    notes?: string,
    documentStatuses?: Record<string, 'verified' | 'rejected'>
  ) => void;
  markNotificationAsRead: (id: string) => void;
  clearAllNotifications: () => void;
  calculateMinBid: (item: AuctionItem) => number;
}


const AuctiaContext = createContext<AuctiaContextType | undefined>(undefined);

const LOCAL_STORAGE_KEY_PREFIX = 'auctia_platform_v2_';

const MOCK_AUCTION_IDS = [
  'auc-001',
  'auc-002',
  'auc-003',
  'auc-004',
  'auc-005',
  'auc-006',
  'auc-1792701874820',
];

const ZERO_SALES_MIGRATION_KEY = 'ngolumarket_zero_sales_init_v3';

// One-time cleanup of any leftover test/demo listings & sales so only real customer sales exist
if (typeof window !== 'undefined' && !localStorage.getItem(ZERO_SALES_MIGRATION_KEY)) {
  const keysToClear = [
    'auctions',
    'bids',
    'settlements',
    'payments',
    'ad_campaigns',
    'watchlist',
    'recent_views',
    'notifications',
    'audit_logs',
  ];
  keysToClear.forEach((k) => {
    localStorage.removeItem(`${LOCAL_STORAGE_KEY_PREFIX}${k}`);
    localStorage.removeItem(`auctia_data_v1_${k}`);
  });
  localStorage.setItem(ZERO_SALES_MIGRATION_KEY, '1');
}

export const AuctiaProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Try to load persisted data or fall back to clean user data
  const [users, setUsers] = useState<User[]>(() => {
    try {
      const saved =
        localStorage.getItem(`${LOCAL_STORAGE_KEY_PREFIX}users`) ||
        localStorage.getItem('auctia_data_v1_users');
      if (saved) {
        const parsed: User[] = JSON.parse(saved);
        return parsed.filter(
          (u) =>
            u.id !== 'user_buyer_1' &&
            !u.name.toLowerCase().includes('gabriel okoko')
        );
      }
    } catch {
      // fallback
    }
    return INITIAL_USERS;
  });

  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    // Ensure no account is directly connected by default; visitors arrive unauthenticated
    try {
      localStorage.removeItem('auctia_data_v1_current_user_id');
      const savedId = localStorage.getItem(`${LOCAL_STORAGE_KEY_PREFIX}current_user_id`);
      if (!savedId || savedId === 'null' || savedId === 'user_buyer_1') {
        localStorage.removeItem(`${LOCAL_STORAGE_KEY_PREFIX}current_user_id`);
        return null;
      }
      const savedUsers = localStorage.getItem(`${LOCAL_STORAGE_KEY_PREFIX}users`);
      if (savedUsers) {
        const userList: User[] = JSON.parse(savedUsers);
        const found = userList.find(
          (u) =>
            u.id === savedId &&
            u.id !== 'user_buyer_1' &&
            !u.name.toLowerCase().includes('gabriel okoko')
        );
        return found || null;
      }
    } catch {
      // fallback
    }
    return null;
  });

  const [sellerProfiles, setSellerProfiles] = useState<SellerProfile[]>(() => {
    const saved =
      localStorage.getItem(`${LOCAL_STORAGE_KEY_PREFIX}seller_profiles`) ||
      localStorage.getItem('auctia_data_v1_seller_profiles');
    return saved ? JSON.parse(saved) : INITIAL_SELLER_PROFILES;
  });

  const [auctions, setAuctions] = useState<AuctionItem[]>(() => {
    const saved =
      localStorage.getItem(`${LOCAL_STORAGE_KEY_PREFIX}auctions`) ||
      localStorage.getItem('auctia_data_v1_auctions');
    if (saved) {
      try {
        const parsed: AuctionItem[] = JSON.parse(saved);
        // Exclude all mock auctions added previously, keep only real user auctions
        return parsed.filter((a) => !MOCK_AUCTION_IDS.includes(a.id));
      } catch {
        return [];
      }
    }
    return INITIAL_AUCTIONS;
  });

  const [bids, setBids] = useState<Bid[]>(() => {
    const saved =
      localStorage.getItem(`${LOCAL_STORAGE_KEY_PREFIX}bids`) ||
      localStorage.getItem('auctia_data_v1_bids');
    if (saved) {
      try {
        const parsed: Bid[] = JSON.parse(saved);
        return parsed.filter(
          (b) =>
            !MOCK_AUCTION_IDS.includes(b.auctionId) &&
            !['bid-101', 'bid-102', 'bid-103', 'bid-104', 'bid-201', 'bid-202'].includes(b.id)
        );
      } catch {
        return [];
      }
    }
    return INITIAL_BIDS;
  });

  const [settlements, setSettlements] = useState<FinancialSettlement[]>(() => {
    const saved =
      localStorage.getItem(`${LOCAL_STORAGE_KEY_PREFIX}settlements`) ||
      localStorage.getItem('auctia_data_v1_settlements');
    if (saved) {
      try {
        const parsed: FinancialSettlement[] = JSON.parse(saved);
        return parsed.filter((s) => !MOCK_AUCTION_IDS.includes(s.auctionId) && s.id !== 'stl-001');
      } catch {
        return [];
      }
    }
    return INITIAL_SETTLEMENTS;
  });

  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(() => {
    const saved =
      localStorage.getItem(`${LOCAL_STORAGE_KEY_PREFIX}audit_logs`) ||
      localStorage.getItem('auctia_data_v1_audit_logs');
    if (saved) {
      try {
        const parsed: AuditLog[] = JSON.parse(saved);
        return parsed.filter(
          (l) =>
            !MOCK_AUCTION_IDS.includes(l.targetId) &&
            !['log-001', 'log-002', 'log-003'].includes(l.id)
        );
      } catch {
        return [];
      }
    }
    return INITIAL_AUDIT_LOGS;
  });

  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    const saved =
      localStorage.getItem(`${LOCAL_STORAGE_KEY_PREFIX}notifications`) ||
      localStorage.getItem('auctia_data_v1_notifications');
    if (saved) {
      try {
        const parsed: NotificationItem[] = JSON.parse(saved);
        return parsed.filter(
          (n) =>
            !MOCK_AUCTION_IDS.includes(n.linkAuctionId || '') &&
            !['notif-001', 'notif-002', 'notif-003'].includes(n.id)
        );
      } catch {
        return [];
      }
    }
    return INITIAL_NOTIFICATIONS;
  });

  const [emailNotifications, setEmailNotifications] = useState<EmailNotification[]>(() => {
    const saved =
      localStorage.getItem(`${LOCAL_STORAGE_KEY_PREFIX}email_notifications`) ||
      localStorage.getItem('auctia_data_v1_email_notifications');
    return saved ? JSON.parse(saved) : [];
  });

  const [notificationPreferences, setNotificationPreferences] = useState<NotificationPreferences>(() => {
    const saved =
      localStorage.getItem(`${LOCAL_STORAGE_KEY_PREFIX}notif_prefs`) ||
      localStorage.getItem('auctia_data_v1_notif_prefs');
    return saved
      ? JSON.parse(saved)
      : {
          smsNotifications: true,
          inAppNotifications: true,
          notifyOnOutbid: true,
          notifyOnEndingSoon: true,
          notifyOnWon: true,
          notifyOnNewBidOnMyItem: true,
          audioChimeEnabled: true,
        };
  });

  const [settings, setSettings] = useState<PlatformSettings>(() => {
    const saved =
      localStorage.getItem(`${LOCAL_STORAGE_KEY_PREFIX}settings`) ||
      localStorage.getItem('auctia_data_v1_settings');
    if (saved) {
      try {
        return { ...INITIAL_SETTINGS, ...JSON.parse(saved) };
      } catch {
        return INITIAL_SETTINGS;
      }
    }
    return INITIAL_SETTINGS;
  });

  const [language, setLanguage] = useState<Language>(() => {
    const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY_PREFIX}lang`);
    return (saved as Language) || 'fr';
  });

  const [recentlyViewedIds, setRecentlyViewedIds] = useState<string[]>(() => {
    const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY_PREFIX}recent_views`);
    return saved ? JSON.parse(saved) : [];
  });

  const [adCampaigns, setAdCampaigns] = useState<AdCampaign[]>(() => {
    const saved = localStorage.getItem(`${LOCAL_STORAGE_KEY_PREFIX}ad_campaigns`);
    return saved ? JSON.parse(saved) : [];
  });

  const [watchlist, setWatchlist] = useState<string[]>(() => {
    const saved =
      localStorage.getItem(`${LOCAL_STORAGE_KEY_PREFIX}watchlist`) ||
      localStorage.getItem('auctia_data_v1_watchlist');
    if (saved) {
      try {
        const parsed: string[] = JSON.parse(saved);
        return parsed.filter((id) => !MOCK_AUCTION_IDS.includes(id));
      } catch {
        return [];
      }
    }
    return [];
  });

  const [latestBidEvent, setLatestBidEvent] = useState<RealtimeBidEvent | null>(null);

  // WebSocket connection & room state
  const [wsState, setWsState] = useState<'connected' | 'connecting' | 'disconnected'>('connecting');
  const [activeViewersMap, setActiveViewersMap] = useState<Record<string, number>>({});
  const isWsConnected = wsState === 'connected';

  // Banking Aggregator Channels & Real Payments ledger state
  const [aggregatorGateways, setAggregatorGateways] = useState<AggregatorGatewayInfo[]>([
    {
      id: 'ngolupay_hub',
      name: 'NgoluPay Hub (Agrégateur Central)',
      subtitle: 'Routeur bancaire multi-banques RDC, Mobile Money & Séquestre BCC',
      settlementRail: 'RTGS BCC · Multi-Banques · Mobile Money API',
      clearingDelay: 'Instantané (< 5s)',
      feePercent: 0,
      supportedMethods: ['bank_transfer', 'mobile_money', 'card'],
      supportedCurrencies: ['USD', 'CDF'],
      connectedBanks: [
        'rawbank_illicocash',
        'rawbank_virement',
        'equity_bcdc',
        'ecobank',
        'tmb_pepele',
        'fbnbank_rdc',
        'sofibanque',
        'access_bank_rdc',
      ],
      enabled: true,
      status: 'online',
    },
    {
      id: 'rawbank_direct',
      name: 'Rawbank Direct & Illicocash Gateway',
      subtitle: 'Passerelle directe compte séquestre Rawbank Kinshasa Gombe',
      settlementRail: 'Rawbank API · Illicocash · SWIFT RAWBCDKI',
      clearingDelay: 'Instantané (< 3s)',
      feePercent: 0,
      supportedMethods: ['bank_transfer', 'mobile_money'],
      supportedCurrencies: ['USD', 'CDF'],
      connectedBanks: ['rawbank_illicocash', 'rawbank_virement'],
      enabled: true,
      status: 'online',
    },
    {
      id: 'cinetpay_rdc',
      name: 'CinetPay Agrégateur RDC',
      subtitle: 'Collecte unifiée M-Pesa, Orange Money, Airtel, Afrimoney & Banques',
      settlementRail: 'Switch Opérateurs Télécoms RDC & Cartes',
      clearingDelay: 'Instantané (< 10s)',
      feePercent: 0,
      supportedMethods: ['mobile_money', 'card', 'bank_transfer'],
      supportedCurrencies: ['USD', 'CDF'],
      connectedBanks: ['rawbank_illicocash', 'equity_bcdc', 'ecobank', 'tmb_pepele'],
      enabled: true,
      status: 'online',
    },
    {
      id: 'flutterwave_africa',
      name: 'Flutterwave Africa & Diaspora',
      subtitle: 'Cartes Visa/Mastercard internationales & virements panafricains',
      settlementRail: '3D-Secure Visa/MC · Pan-African Clearing',
      clearingDelay: 'Instantané (< 10s)',
      feePercent: 0,
      supportedMethods: ['card', 'bank_transfer'],
      supportedCurrencies: ['USD', 'CDF'],
      connectedBanks: ['equity_bcdc', 'ecobank', 'access_bank_rdc', 'fbnbank_rdc'],
      enabled: true,
      status: 'online',
    },
  ]);
  const [connectedBanks, setConnectedBanks] = useState<ConnectedBankInfo[]>([
    {
      id: 'rawbank_illicocash',
      name: 'Rawbank (Illicocash & RTGS)',
      shortName: 'Rawbank',
      swiftCode: 'RAWBCDKI',
      clearingCode: '05100',
      rails: ['RTGS BCC', 'Illicocash API', 'SWIFT'],
      settlementDelay: 'Instantané (< 5s)',
      supportedCurrencies: ['USD', 'CDF'],
    },
    {
      id: 'rawbank_virement',
      name: 'Rawbank Virement Bancaire Direct',
      shortName: 'Rawbank RIB',
      swiftCode: 'RAWBCDKI',
      clearingCode: '05100',
      rails: ['Virement Interne', 'RTGS BCC'],
      settlementDelay: 'Temps réel (0–10 min)',
      supportedCurrencies: ['USD', 'CDF'],
    },
    {
      id: 'equity_bcdc',
      name: 'Equity BCDC Kinshasa',
      shortName: 'Equity BCDC',
      swiftCode: 'PRCBCDKI',
      clearingCode: '05110',
      rails: ['EazzyPay API', 'RTGS BCC', 'SWIFT'],
      settlementDelay: 'Instantané (< 15s)',
      supportedCurrencies: ['USD', 'CDF'],
    },
    {
      id: 'ecobank',
      name: 'Ecobank RDC',
      shortName: 'Ecobank',
      swiftCode: 'ECOCDDKI',
      clearingCode: '05120',
      rails: ['Rapidtransfer', 'Omni Plus API', 'RTGS BCC'],
      settlementDelay: 'Instantané (< 30s)',
      supportedCurrencies: ['USD', 'CDF'],
    },
    {
      id: 'tmb_pepele',
      name: 'Trust Merchant Bank (Pepele Mobile)',
      shortName: 'TMB Pepele',
      swiftCode: 'TRMBCD3L',
      clearingCode: '05130',
      rails: ['Pepele Mobile', 'RTGS BCC'],
      settlementDelay: 'Instantané (< 15s)',
      supportedCurrencies: ['USD', 'CDF'],
    },
    {
      id: 'fbnbank_rdc',
      name: 'FBNBank DRC',
      shortName: 'FBNBank',
      swiftCode: 'FIINCDKI',
      clearingCode: '05140',
      rails: ['RTGS BCC', 'SWIFT'],
      settlementDelay: 'Temps réel (5–15 min)',
      supportedCurrencies: ['USD', 'CDF'],
    },
    {
      id: 'sofibanque',
      name: 'Sofibanque RDC',
      shortName: 'Sofibanque',
      swiftCode: 'SOFICDKI',
      clearingCode: '05150',
      rails: ['RTGS BCC', 'SWIFT'],
      settlementDelay: 'Temps réel (5–15 min)',
      supportedCurrencies: ['USD', 'CDF'],
    },
    {
      id: 'access_bank_rdc',
      name: 'Access Bank RDC',
      shortName: 'Access Bank',
      swiftCode: 'ABNGCDKI',
      clearingCode: '05160',
      rails: ['AccessMore API', 'RTGS BCC'],
      settlementDelay: 'Instantané (< 30s)',
      supportedCurrencies: ['USD', 'CDF'],
    },
  ]);

  const [payments, setPayments] = useState<PaymentTransaction[]>(() => {
    const saved =
      localStorage.getItem(`${LOCAL_STORAGE_KEY_PREFIX}payments`) ||
      localStorage.getItem('auctia_data_v1_payments');
    return saved ? JSON.parse(saved) : [];
  });

  // Buyer Verification (KYC) state
  const [buyerVerifications, setBuyerVerifications] = useState<BuyerVerificationProfile[]>(() => {
    const saved =
      localStorage.getItem(`${LOCAL_STORAGE_KEY_PREFIX}buyer_verifications`) ||
      localStorage.getItem('auctia_data_v1_buyer_verifications');
    return saved ? JSON.parse(saved) : [];
  });

  // Save payments and buyerVerifications to localStorage
  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY_PREFIX}payments`, JSON.stringify(payments));
  }, [payments]);

  useEffect(() => {
    localStorage.setItem(
      `${LOCAL_STORAGE_KEY_PREFIX}buyer_verifications`,
      JSON.stringify(buyerVerifications)
    );
  }, [buyerVerifications]);

  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY_PREFIX}lang`, language);
  }, [language]);

  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY_PREFIX}recent_views`, JSON.stringify(recentlyViewedIds));
  }, [recentlyViewedIds]);

  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY_PREFIX}ad_campaigns`, JSON.stringify(adCampaigns));
  }, [adCampaigns]);

  // Web Audio Chime synthesizer for real-time bid sound
  const playBidChime = () => {
    if (!notificationPreferences.audioChimeEnabled) return;
    try {
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioContextClass) return;
      const ctx = new AudioContextClass();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
      osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.15); // A5
      gain.gain.setValueAtTime(0.12, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.35);
    } catch {
      // Ignore if user hasn't interacted with page yet
    }
  };

  // Subscribe/Unsubscribe auction rooms via WS + fetch latest authoritative state
  const subscribeToAuctionRoom = (auctionId: string) => {
    wsService.subscribeAuction(auctionId);
    fetch(`/api/auctions/${auctionId}`)
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (!data?.success || !data.auction) return;
        const srvAuction: AuctionItem = data.auction;
        setAuctions((prev) =>
          prev.some((a) => a.id === srvAuction.id)
            ? prev.map((a) => (a.id === srvAuction.id ? { ...a, ...srvAuction } : a))
            : [srvAuction, ...prev]
        );
        if (Array.isArray(data.bids) && data.bids.length > 0) {
          setBids((prev) => {
            const existingIds = new Set(prev.map((b) => b.id));
            const fresh = data.bids.filter((b: Bid) => !existingIds.has(b.id));
            return fresh.length > 0 ? [...fresh, ...prev] : prev;
          });
        }
        if (typeof data.activeViewersCount === 'number') {
          setActiveViewersMap((prev) => ({ ...prev, [auctionId]: data.activeViewersCount }));
        }
      })
      .catch(() => {
        // Offline / local fallback
      });
  };

  const unsubscribeFromAuctionRoom = (auctionId: string) => {
    wsService.unsubscribeAuction(auctionId);
  };

  // Sync local auctions & seller profiles with server on mount & reconnect
  const syncStateWithServer = (serverAuctions: AuctionItem[], serverBids: Bid[], serverSellers: SellerProfile[]) => {
    if (Array.isArray(serverAuctions)) {
      setAuctions((prevLocal) => {
        const mergedMap = new Map<string, AuctionItem>();
        prevLocal.forEach((a) => mergedMap.set(a.id, a));
        serverAuctions.forEach((sa) => {
          const local = mergedMap.get(sa.id);
          if (!local || (sa.bidsCount ?? 0) >= (local.bidsCount ?? 0)) {
            mergedMap.set(sa.id, local ? { ...local, ...sa } : sa);
          }
        });
        // Push any local-only auctions up to server so all connected browsers see them
        const serverIds = new Set(serverAuctions.map((a) => a.id));
        prevLocal.forEach((la) => {
          if (!serverIds.has(la.id)) {
            fetch('/api/auctions', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(la),
            }).catch(() => {});
          }
        });
        return Array.from(mergedMap.values()).sort(
          (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
      });
    }

    if (Array.isArray(serverBids) && serverBids.length > 0) {
      setBids((prev) => {
        const existingIds = new Set(prev.map((b) => b.id));
        const fresh = serverBids.filter((b) => !existingIds.has(b.id));
        return fresh.length > 0 ? [...fresh, ...prev] : prev;
      });
    }

    if (Array.isArray(serverSellers) && serverSellers.length > 0) {
      setSellerProfiles((prev) => {
        const map = new Map<string, SellerProfile>();
        prev.forEach((p) => map.set(p.userId, p));
        serverSellers.forEach((sp) => map.set(sp.userId, sp));
        return Array.from(map.values());
      });
    }
  };

  const refreshAggregatorChannels = async () => {
    try {
      const res = await fetch('/api/aggregator/channels');
      if (!res.ok) return;
      const data = await res.json();
      if (data?.success) {
        if (Array.isArray(data.gateways)) setAggregatorGateways(data.gateways);
        if (Array.isArray(data.connectedBanks)) setConnectedBanks(data.connectedBanks);
      }
    } catch {
      // keep local fallback
    }
  };

  const toggleAggregatorGateway = async (gatewayId: BankAggregatorId) => {
    const current = aggregatorGateways.find((g) => g.id === gatewayId);
    const nextEnabled = current ? !current.enabled : true;
    setAggregatorGateways((prev) =>
      prev.map((g) =>
        g.id === gatewayId
          ? { ...g, enabled: nextEnabled, status: nextEnabled ? 'online' : 'maintenance' }
          : g
      )
    );
    try {
      await fetch('/api/aggregator/toggle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ gatewayId, enabled: nextEnabled }),
      });
    } catch {
      // ignore network fallback
    }
  };

  // Hydrate initial state from REST API on mount
  useEffect(() => {
    Promise.all([
      fetch('/api/auctions').then((r) => (r.ok ? r.json() : null)).catch(() => null),
      fetch('/api/bids').then((r) => (r.ok ? r.json() : null)).catch(() => null),
      fetch('/api/verification/sellers').then((r) => (r.ok ? r.json() : null)).catch(() => null),
      fetch('/api/aggregator/channels').then((r) => (r.ok ? r.json() : null)).catch(() => null),
    ]).then(([aucRes, bidRes, selRes, aggRes]) => {
      syncStateWithServer(
        aucRes?.auctions || [],
        bidRes?.bids || [],
        selRes?.profiles || []
      );
      if (aggRes?.success) {
        if (Array.isArray(aggRes.gateways)) setAggregatorGateways(aggRes.gateways);
        if (Array.isArray(aggRes.connectedBanks)) setConnectedBanks(aggRes.connectedBanks);
      }
    });
  }, []);

  // Initialize WebSocket listeners and presence
  useEffect(() => {
    if (currentUser) {
      wsService.setUser(currentUser.id, currentUser.name);
    }

    const unsubStatus = wsService.addStatusListener((status) => {
      setWsState(status);
    });

    const unsubMessages = wsService.addListener((message: WsMessage) => {
      if (message.type === 'init' && message.payload) {
        const { auctions: srvAuctions, bids: srvBids, sellerVerifications: srvSellers } = message.payload;
        syncStateWithServer(srvAuctions || [], srvBids || [], srvSellers || []);
      } else if (message.type === 'bid:placed' && message.payload) {
        const { auction: updatedAuction, bid: newBid, antiSnipingTriggered } = message.payload;
        if (newBid && updatedAuction) {
          setBids((prev) => {
            if (prev.some((b) => b.id === newBid.id)) return prev;
            return [
              newBid,
              ...prev.map((b) =>
                b.auctionId === updatedAuction.id ? { ...b, status: 'outbid' as const } : b
              ),
            ];
          });
          setAuctions((prev) =>
            prev.some((a) => a.id === updatedAuction.id)
              ? prev.map((a) => (a.id === updatedAuction.id ? { ...a, ...updatedAuction } : a))
              : [updatedAuction, ...prev]
          );
          playBidChime();
          setLatestBidEvent({
            auctionId: updatedAuction.id,
            bid: newBid,
            newPrice: updatedAuction.currentPrice,
            newEndDate: updatedAuction.endDate,
            antiSnipingTriggered: Boolean(antiSnipingTriggered),
          });
        }
      } else if (message.type === 'presence:update' && message.payload) {
        const { auctionId, activeViewersCount } = message.payload;
        if (auctionId) {
          setActiveViewersMap((prev) => ({ ...prev, [auctionId]: activeViewersCount }));
        }
      } else if (message.type === 'auction:created' && message.payload) {
        const createdAuction = message.payload;
        setAuctions((prev) => {
          if (prev.some((a) => a.id === createdAuction.id)) return prev;
          return [createdAuction, ...prev];
        });
      } else if (message.type === 'auction:updated' && message.payload) {
        const updatedAuction = message.payload;
        setAuctions((prev) =>
          prev.some((a) => a.id === updatedAuction.id)
            ? prev.map((a) => (a.id === updatedAuction.id ? { ...a, ...updatedAuction } : a))
            : [updatedAuction, ...prev]
        );
      } else if (message.type === 'seller:verification_updated' && message.payload) {
        const updatedProfile: SellerProfile = message.payload;
        setSellerProfiles((prev) => [
          updatedProfile,
          ...prev.filter((p) => p.userId !== updatedProfile.userId),
        ]);
        const isCertified = updatedProfile.verificationStatus === 'verified';
        setAuctions((prev) =>
          prev.map((a) =>
            a.sellerId === updatedProfile.userId ? { ...a, sellerVerified: isCertified } : a
          )
        );
      } else if (message.type === 'payment:confirmed' && message.payload) {
        const tx = message.payload;
        setPayments((prev) => {
          if (prev.some((p) => p.id === tx.id)) return prev;
          return [tx, ...prev];
        });
      } else if (message.type === 'notification:pushed' && message.payload) {
        const notif = message.payload;
        setNotifications((prev) => [
          {
            id: `notif-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
            userId: currentUser?.id || '',
            title: notif.title,
            message: notif.message,
            type: notif.type,
            timestamp: new Date().toISOString(),
            read: false,
            linkAuctionId: notif.auctionId,
          },
          ...prev,
        ]);
      }
    });

    return () => {
      unsubStatus();
      unsubMessages();
    };
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY_PREFIX}users`, JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY_PREFIX}auctions`, JSON.stringify(auctions));
  }, [auctions]);

  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY_PREFIX}bids`, JSON.stringify(bids));
  }, [bids]);

  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY_PREFIX}settlements`, JSON.stringify(settlements));
  }, [settlements]);

  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY_PREFIX}audit_logs`, JSON.stringify(auditLogs));
  }, [auditLogs]);

  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY_PREFIX}notifications`, JSON.stringify(notifications));
  }, [notifications]);

  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY_PREFIX}email_notifications`, JSON.stringify(emailNotifications));
  }, [emailNotifications]);

  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY_PREFIX}notif_prefs`, JSON.stringify(notificationPreferences));
  }, [notificationPreferences]);

  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY_PREFIX}seller_profiles`, JSON.stringify(sellerProfiles));
  }, [sellerProfiles]);

  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY_PREFIX}settings`, JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem(`${LOCAL_STORAGE_KEY_PREFIX}watchlist`, JSON.stringify(watchlist));
  }, [watchlist]);

  useEffect(() => {
    localStorage.setItem(
      `${LOCAL_STORAGE_KEY_PREFIX}current_user_id`,
      currentUser ? currentUser.id : 'null'
    );
  }, [currentUser]);

  // Periodic automatic auction clock checker:
  // Transitions programmed -> en_cours when start time passes,
  // Transitions en_cours -> terminee when end time passes and creates settlement
  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date().getTime();
      let hasChanges = false;

      const updated = auctions.map((auction) => {
        if (auction.status === 'programmee') {
          const start = new Date(auction.startDate).getTime();
          if (now >= start) {
            hasChanges = true;
            return { ...auction, status: 'en_cours' as AuctionStatus };
          }
        }
        if (auction.status === 'en_cours') {
          const end = new Date(auction.endDate).getTime();
          if (now >= end) {
            hasChanges = true;
            // Generate settlement automatically
            if (auction.highestBidderId) {
              const commissionAmount = (auction.currentPrice * settings.commissionRatePercent) / 100;
              const netSeller =
                settings.fixedFeePayer === 'seller'
                  ? auction.currentPrice - commissionAmount - settings.fixedListingFee
                  : auction.currentPrice - commissionAmount;

              const newSettlement: FinancialSettlement = {
                id: `stl-${Date.now()}-${auction.id}`,
                auctionId: auction.id,
                auctionTitle: auction.title,
                winningBid: auction.currentPrice,
                commissionRate: settings.commissionRatePercent,
                commissionAmount,
                fixedFee: settings.fixedListingFee,
                feePayer: settings.fixedFeePayer,
                netSellerAmount: Math.max(0, netSeller),
                sellerId: auction.sellerId,
                winnerId: auction.highestBidderId,
                settlementStatus: 'en_attente_paiement',
                closedAt: new Date().toISOString(),
                notes: `Adjudication automatique au gagnant ${auction.highestBidderName}.`,
              };

              setSettlements((prev) => [newSettlement, ...prev]);

              // Notify winner
              setNotifications((prev) => [
                {
                  id: `notif-${Date.now()}-win`,
                  userId: auction.highestBidderId!,
                  title: 'Enchère remportée !',
                  message: `Vous avez remporté l'enchère "${auction.title}" à ${auction.currentPrice.toLocaleString()} USD.`,
                  type: 'won',
                  timestamp: new Date().toISOString(),
                  read: false,
                  linkAuctionId: auction.id,
                },
                ...prev,
              ]);
            }
            return { ...auction, status: 'terminee' as AuctionStatus };
          }
        }
        return auction;
      });

      if (hasChanges) {
        setAuctions(updated);
      }
    }, 5000);

    return () => clearInterval(interval);
  }, [auctions, settings]);

  const loginAs = (userId: string | null) => {
    if (!userId) {
      setCurrentUser(null);
      localStorage.removeItem(`${LOCAL_STORAGE_KEY_PREFIX}current_user_id`);
      return;
    }
    const found = users.find((u) => u.id === userId);
    if (found) {
      setCurrentUser(found);
      localStorage.setItem(`${LOCAL_STORAGE_KEY_PREFIX}current_user_id`, found.id);
    }
  };

  const login = (identifier: string, password?: string): { success: boolean; error?: string } => {
    const clean = identifier.trim().toLowerCase();
    if (!clean) {
      return { success: false, error: 'Veuillez saisir votre numéro de téléphone ou votre nom.' };
    }
    const cleanDigits = identifier.replace(/\D/g, '');

    const found = users.find((u) => {
      const uPhoneDigits = u.phone.replace(/\D/g, '');
      const matchDigits =
        cleanDigits.length >= 6 &&
        (uPhoneDigits.includes(cleanDigits) || cleanDigits.includes(uPhoneDigits));
      const matchExact = u.phone.replace(/\s+/g, '') === clean.replace(/\s+/g, '');
      const matchName =
        u.name.toLowerCase() === clean ||
        u.name.toLowerCase().includes(clean) ||
        (clean.length >= 3 && clean.includes(u.name.toLowerCase()));
      const matchEmail = u.email ? u.email.toLowerCase() === clean : false;
      return matchDigits || matchExact || matchName || matchEmail;
    });

    if (found) {
      setCurrentUser(found);
      localStorage.setItem(`${LOCAL_STORAGE_KEY_PREFIX}current_user_id`, found.id);
      return { success: true };
    }

    // Auto-create account if user enters their phone number for the first time
    const isPhoneNumber = clean.startsWith('+') || /^\d[\d\s-]{6,}$/.test(clean);
    const generatedName = isPhoneNumber ? `Utilisateur Kinshasa (${clean})` : clean;

    const newUser: User = {
      id: `user_${Date.now()}`,
      name: generatedName,
      phone: clean.startsWith('+') ? clean : '+243 ' + clean,
      role: 'seller', // Allows user to post auctions and bid immediately
      status: 'active',
      city: 'Kinshasa',
      createdAt: new Date().toISOString(),
    };

    setUsers((prev) => [...prev, newUser]);
    setCurrentUser(newUser);
    localStorage.setItem(`${LOCAL_STORAGE_KEY_PREFIX}current_user_id`, newUser.id);
    return { success: true };
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem(`${LOCAL_STORAGE_KEY_PREFIX}current_user_id`);
  };

  const registerUser = (userData: Omit<User, 'id' | 'createdAt'>): User => {
    const newUser: User = {
      ...userData,
      id: `user_${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setUsers((prev) => [...prev, newUser]);
    setCurrentUser(newUser);
    localStorage.setItem(`${LOCAL_STORAGE_KEY_PREFIX}current_user_id`, newUser.id);

    // Audit log
    setAuditLogs((prev) => [
      {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        actorId: newUser.id,
        actorName: newUser.name,
        actorRole: newUser.role,
        action: 'INSCRIPTION_UTILISATEUR',
        targetType: 'user',
        targetId: newUser.id,
        details: `Création de compte ${newUser.role.toUpperCase()} pour ${newUser.name} (${newUser.phone}).`,
      },
      ...prev,
    ]);

    return newUser;
  };

  const registerSellerProfile = (
    profile: Omit<SellerProfile, 'submittedAt' | 'verificationStatus'>
  ) => {
    const existing = sellerProfiles.find((p) => p.userId === profile.userId);
    const mergedDocuments = profile.documents ?? existing?.documents ?? [];
    const newProfile: SellerProfile = {
      ...existing,
      ...profile,
      documents: mergedDocuments,
      verificationStatus: 'pending',
      verificationNotes: 'Dossier soumis pour vérification par l’équipe conformité NgoluMarket.',
      submittedAt: new Date().toISOString(),
    };
    setSellerProfiles((prev) => [
      newProfile,
      ...prev.filter((p) => p.userId !== profile.userId),
    ]);

    // Sync seller verification submission to server
    fetch('/api/verification/seller/submit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newProfile),
    }).catch(() => {});

    // Audit log
    setAuditLogs((prev) => [
      {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        actorId: profile.userId,
        actorName: profile.companyName,
        actorRole: 'seller',
        action: 'SOUMISSION_DOSSIER_VENDEUR',
        targetType: 'user',
        targetId: profile.userId,
        details: `Dossier Vendeur Pro soumis pour ${profile.companyName} (RCCM: ${profile.rccmNumber}). En attente de validation NgoluMarket.`,
      },
      ...prev,
    ]);
  };

  const calculateMinBid = (item: AuctionItem): number => {
    if (item.bidsCount === 0) {
      return item.startPrice;
    }
    if (settings.minBidStepMode === 'tiered') {
      if (item.currentPrice < 5000) return item.currentPrice + 50;
      if (item.currentPrice < 20000) return item.currentPrice + 250;
      if (item.currentPrice < 100000) return item.currentPrice + 1000;
      return item.currentPrice + 2500;
    }
    return item.currentPrice + item.minBidStep;
  };

  const placeBid = (
    auctionId: string,
    amount: number
  ): { success: boolean; error?: string } => {
    if (!currentUser) {
      return { success: false, error: 'Vous devez être connecté pour participer aux enchères.' };
    }
    if (currentUser.role === 'seller' || currentUser.role === 'admin') {
      // Allow testing but give friendly notice
    }
    const auction = auctions.find((a) => a.id === auctionId);
    if (!auction) {
      return { success: false, error: 'Annonce introuvable.' };
    }
    if (auction.status !== 'en_cours') {
      return { success: false, error: `Cette enchère est actuellement "${auction.status}". Aucune offre acceptée.` };
    }

    const minRequired = calculateMinBid(auction);
    if (amount < minRequired) {
      return {
        success: false,
        error: `L'offre doit être au minimum de ${minRequired.toLocaleString()} USD (offre actuelle: ${auction.currentPrice.toLocaleString()} USD).`,
      };
    }

    const previousHighestBidderId = auction.highestBidderId;
    const nowTime = new Date().getTime();
    const endDateTime = new Date(auction.endDate).getTime();
    const remainingMs = endDateTime - nowTime;

    let newEndDate = auction.endDate;
    let antiSnipingTriggered = false;

    // Anti-sniping rule check: if within configured threshold (e.g., 2 minutes)
    if (settings.antiSnipingEnabled && remainingMs > 0 && remainingMs <= settings.antiSnipingMinutes * 60 * 1000) {
      // Extend by settings.antiSnipingMinutes from now
      newEndDate = new Date(nowTime + settings.antiSnipingMinutes * 60 * 1000).toISOString();
      antiSnipingTriggered = true;
    }

    // Create Bid record with unique ID for idempotent WS + HTTP sync
    const bidId = `bid-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
    const newBid: Bid = {
      id: bidId,
      auctionId,
      bidderId: currentUser.id,
      bidderName: currentUser.name,
      amount,
      timestamp: new Date().toISOString(),
      status: 'valid',
    };

    // Update existing bids status for this auction
    setBids((prev) => [
      newBid,
      ...prev.map((b) => (b.auctionId === auctionId ? { ...b, status: 'outbid' as const } : b)),
    ]);

    // Update Auction
    setAuctions((prev) =>
      prev.map((a) => {
        if (a.id === auctionId) {
          return {
            ...a,
            currentPrice: amount,
            bidsCount: a.bidsCount + 1,
            highestBidderId: currentUser.id,
            highestBidderName: currentUser.name,
            endDate: newEndDate,
          };
        }
        return a;
      })
    );

    // Audit Log
    setAuditLogs((prev) => [
      {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        actorId: currentUser.id,
        actorName: currentUser.name,
        actorRole: currentUser.role,
        action: 'OFFRE_VALIDEE',
        targetType: 'bid',
        targetId: newBid.id,
        details: `Offre enregistrée de ${amount.toLocaleString()} USD sur "${auction.title}".${
          antiSnipingTriggered ? ` [Anti-sniping activé: fin repoussée de +${settings.antiSnipingMinutes} min]` : ''
        }`,
      },
      ...prev,
    ]);

    // Play real-time chime
    playBidChime();

    // Broadcast real-time event for local viewer
    setLatestBidEvent({
      auctionId,
      bid: newBid,
      newPrice: amount,
      newEndDate,
      antiSnipingTriggered,
    });

    // Sync via REST endpoint (server broadcasts idempotently over WebSocket to all connected clients)
    fetch(`/api/auctions/${auctionId}/bids`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        bidId,
        amount,
        bidderId: currentUser.id,
        bidderName: currentUser.name,
        bidderPhone: currentUser.phone,
      }),
    }).catch(() => {
      // Fallback to direct WS message if REST failed
      wsService.placeBid(auctionId, amount, currentUser.id, currentUser.name, currentUser.phone, bidId);
    });

    // If previous highest bidder exists and is different, notify them they are outbid!
    if (previousHighestBidderId && previousHighestBidderId !== currentUser.id) {
      if (notificationPreferences.inAppNotifications && notificationPreferences.notifyOnOutbid) {
        setNotifications((prev) => [
          {
            id: `notif-${Date.now()}-outbid`,
            userId: previousHighestBidderId,
            title: 'Surenchère sur votre offre !',
            message: `Une nouvelle offre de ${amount.toLocaleString()} USD a dépassé la vôtre sur "${auction.title}". Répliquez avant la fin !`,
            type: 'outbid',
            timestamp: new Date().toISOString(),
            read: false,
            linkAuctionId: auction.id,
          },
          ...prev,
        ]);
      }

      if (notificationPreferences.notifyOnOutbid) {
        const outbidUser = users.find((u) => u.id === previousHighestBidderId);
        if (outbidUser) {
          setEmailNotifications((prev) => [
            {
              id: `email-${Date.now()}-outbid`,
              userId: outbidUser.id,
              toEmail: outbidUser.email || `${outbidUser.phone}@ngolumarket.cd`,
              toName: outbidUser.name,
              subject: `NgoluMarket Alerte Surenchère : ${auction.title}`,
              body: `Bonjour ${outbidUser.name},\n\nUne nouvelle offre de ${amount.toLocaleString()} USD vient d'être placée par un autre participant sur le bien "${auction.title}".\n\nVous n'êtes plus le meilleur enchérisseur. Pour reprendre l'avantage avant la clôture, accédez directement à la salle des ventes sur NgoluMarket.\n\nCordialement,\nL'équipe NgoluMarket Kinshasa`,
              sentAt: new Date().toISOString(),
              trigger: 'outbid',
              read: false,
            },
            ...prev,
          ]);
        }
      }
    }

    // Notify seller
    if (notificationPreferences.notifyOnNewBidOnMyItem) {
      setNotifications((prev) => [
        {
          id: `notif-${Date.now()}-seller-bid`,
          userId: auction.sellerId,
          title: 'Nouvelle offre reçue',
          message: `Nouvelle offre de ${amount.toLocaleString()} USD par ${currentUser.name} sur votre bien "${auction.title}".`,
          type: 'new_bid',
          timestamp: new Date().toISOString(),
          read: false,
          linkAuctionId: auction.id,
        },
        ...prev,
      ]);
    }

    return { success: true };
  };

  // Direct purchase for Fixed Price items (Achat immédiat)
  const buyFixedPriceItem = (auctionId: string): { success: boolean; error?: string } => {
    if (!currentUser) {
      return { success: false, error: 'Veuillez vous connecter pour acheter cet article.' };
    }

    const auction = auctions.find((a) => a.id === auctionId);
    if (!auction) {
      return { success: false, error: 'Article introuvable.' };
    }

    if (auction.status !== 'en_cours') {
      return { success: false, error: 'Cet article n’est plus disponible à la vente.' };
    }

    if (auction.sellerId === currentUser.id) {
      return { success: false, error: 'Vous ne pouvez pas acheter votre propre bien.' };
    }

    const price = auction.fixedPrice || auction.currentPrice;

    const buyTimestamp = new Date().toISOString();

    // Transition auction to 'terminee'
    setAuctions((prev) =>
      prev.map((a) => {
        if (a.id === auctionId) {
          return {
            ...a,
            status: 'terminee',
            highestBidderId: currentUser.id,
            highestBidderName: currentUser.name,
            currentPrice: price,
            bidsCount: a.bidsCount + 1,
            endDate: buyTimestamp,
          };
        }
        return a;
      })
    );

    fetch(`/api/auctions/${auctionId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        status: 'terminee',
        highestBidderId: currentUser.id,
        highestBidderName: currentUser.name,
        currentPrice: price,
        bidsCount: auction.bidsCount + 1,
        endDate: buyTimestamp,
      }),
    }).catch(() => {});

    // Create a winning bid record for accounting
    const newBid: Bid = {
      id: `bid-${Date.now()}-fixed`,
      auctionId,
      bidderId: currentUser.id,
      bidderName: currentUser.name,
      amount: price,
      timestamp: new Date().toISOString(),
      status: 'won',
    };
    setBids((prev) => [newBid, ...prev]);

    // Generate settlement & Order record (Fiche Technique Sections 6 & 11)
    const buyerFee = settings.fixedPriceBuyerFeeUsd ?? 1;
    const commissionAmount = 0; // Section 6: vente à prix fixe gratuite pour le vendeur, frais 1 USD payé par l'acheteur
    const netSeller = price;
    const orderNum = `CMD-${new Date().getFullYear()}-${String(Math.floor(10000 + Math.random() * 90000))}`;

    const newSettlement: FinancialSettlement = {
      id: `stl-${Date.now()}-${auction.id}`,
      orderNumber: orderNum,
      auctionId: auction.id,
      auctionTitle: auction.title,
      saleType: 'prix_fixe',
      winningBid: price,
      buyerFeeUsd: buyerFee,
      commissionRate: 0,
      commissionAmount,
      fixedFee: buyerFee,
      feePayer: 'buyer',
      netSellerAmount: Math.max(0, netSeller),
      sellerId: auction.sellerId,
      winnerId: currentUser.id,
      settlementStatus: 'en_attente_paiement',
      orderStatus: 'en_attente_paiement',
      closedAt: new Date().toISOString(),
      notes: `Commande à prix fixe ${orderNum} : Produit ${price} USD + Frais NgoluMarket ${buyerFee} USD = Total ${price + buyerFee} USD.`,
    };
    setSettlements((prev) => [newSettlement, ...prev]);

    // Audit log
    setAuditLogs((prev) => [
      {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        actorId: currentUser.id,
        actorName: currentUser.name,
        actorRole: currentUser.role,
        action: 'ACHAT_PRIX_FIXE_CONCLU',
        targetType: 'auction',
        targetId: auction.id,
        details: `Achat immédiat à prix fixe de ${price.toLocaleString()} USD par ${currentUser.name} sur "${auction.title}".`,
      },
      ...prev,
    ]);

    // Notify buyer
    setNotifications((prev) => [
      {
        id: `notif-${Date.now()}-buy-fixed`,
        userId: currentUser.id,
        title: 'Achat confirmé !',
        message: `Félicitations ! Vous avez acquis "${auction.title}" au prix fixe de ${price.toLocaleString()} USD. Votre bordereau est disponible.`,
        type: 'won',
        timestamp: new Date().toISOString(),
        read: false,
        linkAuctionId: auction.id,
      },
      {
        id: `notif-${Date.now()}-seller-fixed`,
        userId: auction.sellerId,
        title: 'Bien vendu à prix fixe !',
        message: `${currentUser.name} a acheté votre bien "${auction.title}" au prix de ${price.toLocaleString()} USD.`,
        type: 'approval',
        timestamp: new Date().toISOString(),
        read: false,
        linkAuctionId: auction.id,
      },
      ...prev,
    ]);

    playBidChime();

    return { success: true };
  };

  // ==========================================
  // REAL PAYMENT PROCESSING METHOD (RDC API)
  // ==========================================
  const processPayment = async (params: {
    amountUsd: number;
    purpose: PaymentPurpose;
    method?: PaymentMethod;
    provider: PaymentProvider;
    aggregatorGateway?: BankAggregatorId;
    accountOrPhone: string;
    auctionId?: string;
    auctionTitle?: string;
    notes?: string;
    userOverride?: User;
  }): Promise<{ success: boolean; transaction?: PaymentTransaction; error?: string }> => {
    const actingUser = params.userOverride || currentUser;
    if (!actingUser) {
      return { success: false, error: 'Veuillez vous connecter pour valider ce paiement.' };
    }

    try {
      const res = await fetch('/api/payments/initialize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: actingUser.id,
          userName: actingUser.name,
          userPhone: actingUser.phone,
          amountUsd: params.amountUsd,
          purpose: params.purpose,
          method: params.method,
          provider: params.provider,
          aggregatorGateway: params.aggregatorGateway || 'ngolupay_hub',
          accountOrPhone: params.accountOrPhone,
          auctionId: params.auctionId,
          auctionTitle: params.auctionTitle,
          notes: params.notes,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Erreur lors du traitement bancaire.');
      }

      const tx: PaymentTransaction = data.transaction;

      // Update state & refresh aggregator metrics
      setPayments((prev) => [tx, ...prev.filter((p) => p.id !== tx.id)]);
      refreshAggregatorChannels();

      // If caution deposit, credit the user's guarantee balance & unlock bidding
      if (params.purpose === 'deposit_guarantee') {
        setCurrentUser((prev) => {
          if (!prev) return null;
          const newBal = (prev.depositBalanceUsd || 0) + params.amountUsd;
          return {
            ...prev,
            depositBalanceUsd: newBal,
            hasActiveDeposit: true,
          };
        });

        setUsers((prev) =>
          prev.map((u) => {
            if (u.id === actingUser.id) {
              const newBal = (u.depositBalanceUsd || 0) + params.amountUsd;
              return {
                ...u,
                depositBalanceUsd: newBal,
                hasActiveDeposit: true,
              };
            }
            return u;
          })
        );
      }

      // Record Audit Log
      setAuditLogs((prev) => [
        {
          id: `log-${Date.now()}`,
          timestamp: new Date().toISOString(),
          actorId: actingUser.id,
          actorName: actingUser.name,
          actorRole: actingUser.role,
          action: 'PAIEMENT_VALIDE_BANQUE',
          targetType: 'auction',
          targetId: params.auctionId || tx.id,
          details: `Paiement réel validé: ${params.amountUsd.toLocaleString()} USD (${tx.amountCdf.toLocaleString()} CDF) via ${params.provider.toUpperCase()}. Réf: ${tx.reference}. Séquestre: ${tx.escrowAccountNumber || 'Rawbank Kinshasa'}.`,
        },
        ...prev,
      ]);

      // Push notification
      setNotifications((prev) => [
        {
          id: `notif-${Date.now()}-pay`,
          userId: actingUser.id,
          title: 'Paiement confirmé par la banque',
          message: `Votre paiement de ${params.amountUsd.toLocaleString()} USD via ${params.provider.toUpperCase()} est validé et consigné sous séquestre notarié.`,
          type: 'approval',
          timestamp: new Date().toISOString(),
          read: false,
          linkAuctionId: params.auctionId,
        },
        ...prev,
      ]);

      return { success: true, transaction: tx };
    } catch (err: any) {
      return { success: false, error: err.message || 'Échec de connexion avec le serveur bancaire.' };
    }
  };

  // ==========================================
  // BUYER VERIFICATION (KYC) METHODS
  // ==========================================
  const requestBuyerPhoneOtp = async (phone: string): Promise<{ success: boolean; mockCode?: string; error?: string }> => {
    try {
      const res = await fetch('/api/verification/buyer/phone-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone }),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Erreur lors de l’envoi du SMS.');
      }
      return { success: true, mockCode: data.mockOtpCode };
    } catch (err: any) {
      return { success: false, error: err.message || 'Impossible de joindre le service SMS.' };
    }
  };

  const verifyBuyerPhoneOtp = (code: string): { success: boolean; error?: string } => {
    if (!currentUser) return { success: false, error: 'Non connecté.' };
    if (!code || code.trim().length !== 6) {
      return { success: false, error: 'Le code OTP doit comporter 6 chiffres.' };
    }

    setCurrentUser((prev) => {
      if (!prev) return null;
      return {
        ...prev,
        phoneVerified: true,
        verificationTier: prev.verificationTier === 'enhanced_kyc' ? 'enhanced_kyc' : 'phone_verified',
      };
    });

    setUsers((prev) =>
      prev.map((u) => {
        if (u.id === currentUser.id) {
          return {
            ...u,
            phoneVerified: true,
            verificationTier: u.verificationTier === 'enhanced_kyc' ? 'enhanced_kyc' : 'phone_verified',
          };
        }
        return u;
      })
    );

    setAuditLogs((prev) => [
      {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        actorId: currentUser.id,
        actorName: currentUser.name,
        actorRole: currentUser.role,
        action: 'ACHETEUR_TELEPHONE_VERIFIE',
        targetType: 'user',
        targetId: currentUser.id,
        details: `Numéro de téléphone ${currentUser.phone} certifié par code OTP.`,
      },
      ...prev,
    ]);

    return { success: true };
  };

  const submitBuyerEnhancedVerification = async (params: {
    documentType: 'ceni_voter_card' | 'passport' | 'driving_license';
    documentNumber: string;
    bankName: string;
    bankAttestationNumber?: string;
    residenceCommune: string;
    residenceQuarter?: string;
  }): Promise<{ success: boolean; error?: string }> => {
    if (!currentUser) return { success: false, error: 'Non connecté.' };

    try {
      const res = await fetch('/api/verification/buyer/enhanced', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: currentUser.id,
          userName: currentUser.name,
          phone: currentUser.phone,
          documentType: params.documentType,
          documentNumber: params.documentNumber,
          bankName: params.bankName,
          bankAttestationNumber: params.bankAttestationNumber,
          residenceCommune: params.residenceCommune,
          residenceQuarter: params.residenceQuarter,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Erreur lors de la transmission du dossier KYC.');
      }

      const profile: BuyerVerificationProfile = data.profile;
      setBuyerVerifications((prev) => [profile, ...prev.filter((p) => p.userId !== currentUser.id)]);

      setNotifications((prev) => [
        {
          id: `notif-${Date.now()}-kyc-sub`,
          userId: currentUser.id,
          title: 'Dossier Acheteur Certifié soumis',
          message: 'Vos pièces d’identité et attestations bancaires ont été transmises à la conformité NgoluMarket pour agrément des plafonds supérieurs (jusqu’à 150 000 USD).',
          type: 'approval',
          timestamp: new Date().toISOString(),
          read: false,
        },
        ...prev,
      ]);

      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Erreur lors de la soumission.' };
    }
  };

  const adminReviewBuyerVerification = async (
    userId: string,
    action: 'approve' | 'reject',
    reason?: string
  ): Promise<{ success: boolean; error?: string }> => {
    try {
      const res = await fetch('/api/verification/admin/action', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, action, reason }),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Action impossible.');
      }

      setBuyerVerifications((prev) =>
        prev.map((p) => {
          if (p.userId === userId) {
            return {
              ...p,
              status: action === 'approve' ? 'verified' : 'rejected',
              tier: action === 'approve' ? 'enhanced_kyc' : p.tier,
              maxTransactionLimitUsd: action === 'approve' ? 150000 : p.maxTransactionLimitUsd,
              rejectionReason: reason,
              reviewedAt: new Date().toISOString(),
              reviewedBy: currentUser?.name || 'Direction de la Conformité',
            };
          }
          return p;
        })
      );

      // If approved, update user tier
      if (action === 'approve') {
        setUsers((prev) =>
          prev.map((u) => (u.id === userId ? { ...u, verificationTier: 'enhanced_kyc' } : u))
        );
        if (currentUser?.id === userId) {
          setCurrentUser((prev) => (prev ? { ...prev, verificationTier: 'enhanced_kyc' } : null));
        }
      }

      return { success: true };
    } catch (err: any) {
      return { success: false, error: err.message || 'Erreur lors de la revue.' };
    }
  };

  const uploadSellerDocument = (
    userId: string,
    doc: Omit<SellerDocument, 'id' | 'uploadedAt' | 'status'>
  ) => {
    const newDoc: SellerDocument = {
      ...doc,
      id: `doc-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
      uploadedAt: new Date().toISOString(),
      status: 'uploaded',
    };

    const existing = sellerProfiles.find((p) => p.userId === userId);
    const updatedProfile: SellerProfile = existing
      ? {
          ...existing,
          documents: [...(existing.documents || []).filter((d) => d.name !== doc.name), newDoc],
          verificationStatus: existing.verificationStatus === 'verified' ? 'pending' : existing.verificationStatus === 'rejected' ? 'pending' : 'pending',
          submittedAt: new Date().toISOString(),
        }
      : {
          userId,
          companyName: currentUser?.companyName || currentUser?.name || 'Vendeur NgoluMarket',
          rccmNumber: 'En attente de saisie',
          idNat: '',
          taxNumber: '',
          address: `${currentUser?.city || 'Kinshasa'}, RDC`,
          city: currentUser?.city || 'Kinshasa',
          phone: currentUser?.phone || '+243 ...',
          documents: [newDoc],
          verificationStatus: 'pending',
          submittedAt: new Date().toISOString(),
        };

    setSellerProfiles((prev) => [
      updatedProfile,
      ...prev.filter((p) => p.userId !== userId),
    ]);

    fetch('/api/verification/seller/submit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updatedProfile),
    }).catch(() => {});

    setAuditLogs((prev) => [
      {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        actorId: userId,
        actorName: currentUser?.name || 'Vendeur Pro',
        actorRole: 'seller',
        action: 'DEPOT_DOCUMENT_KYC',
        targetType: 'user',
        targetId: userId,
        details: `Téléversement du document de conformité : "${doc.name}" (${doc.fileName}, ${doc.fileSize}).`,
      },
      ...prev,
    ]);
  };

  const removeSellerDocument = (userId: string, docId: string) => {
    const existing = sellerProfiles.find((p) => p.userId === userId);
    if (!existing) return;
    const updatedProfile: SellerProfile = {
      ...existing,
      documents: (existing.documents || []).filter((d) => d.id !== docId),
    };
    setSellerProfiles((prev) => [
      updatedProfile,
      ...prev.filter((p) => p.userId !== userId),
    ]);
    fetch('/api/verification/seller/submit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(updatedProfile),
    }).catch(() => {});
  };

  const toggleWatchlist = (auctionId: string) => {
    setWatchlist((prev) =>
      prev.includes(auctionId) ? prev.filter((id) => id !== auctionId) : [...prev, auctionId]
    );
  };

  const submitAuction = (itemData: Partial<AuctionItem>): { success: boolean; error?: string } => {
    if (!currentUser) {
      return {
        success: false,
        error: 'Vous devez créer un compte ou vous connecter pour mettre un bien aux enchères.',
      };
    }

    const sellerProfile = sellerProfiles.find((p) => p.userId === currentUser.id);
    const isSellerVerified = sellerProfile?.verificationStatus === 'verified';

    const newItem: AuctionItem = {
      id: `auc-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
      title: itemData.title || 'Nouvelle annonce NgoluMarket',
      category: itemData.category || 'immobilier',
      description: itemData.description || '',
      images:
        itemData.images && itemData.images.length > 0
          ? itemData.images
          : ['/src/assets/images/hero_auctia_kinshasa_1792177621511.jpg'],
      startPrice: itemData.startPrice || 1000,
      currentPrice: itemData.startPrice || 1000,
      currency: 'USD',
      minBidStep: itemData.minBidStep || 100,
      reservePrice: itemData.reservePrice,
      depositRequiredUsd: itemData.depositRequiredUsd || 0,
      sellerId: currentUser.id,
      sellerName: currentUser.name || currentUser.companyName || 'Membre NgoluMarket',
      sellerVerified: isSellerVerified,
      sellerIsPremium: Boolean(currentUser.isPremium),
      sellerRating: itemData.sellerRating ?? 4.8,
      sellerReviewsCount: itemData.sellerReviewsCount ?? 24,
      isSponsored: itemData.isSponsored ?? false,
      startDate: itemData.startDate || new Date().toISOString(),
      endDate: itemData.endDate || new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(),
      createdAt: new Date().toISOString(),
      status: 'en_attente',
      assetDocuments: itemData.assetDocuments || [],
      documentVerificationStatus: 'pending',
      saleType: itemData.saleType || 'enchere',
      fixedPrice: itemData.fixedPrice,
      location: itemData.location || {
        city: 'Kinshasa',
        commune: 'Gombe',
        neighborhood: 'Kinshasa',
      },
      specificDetails: itemData.specificDetails || ({} as any),
      bidsCount: 0,
      viewsCount: 1,
    };

    setAuctions((prev) => [newItem, ...prev]);

    // Publish to Node/WebSocket backend so admins receive the pending listing immediately
    fetch('/api/auctions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newItem),
    }).catch(() => {});

    setAuditLogs((prev) => [
      {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        actorId: currentUser.id,
        actorName: currentUser.name,
        actorRole: currentUser.role,
        action: 'SOUMISSION_ANNONCE',
        targetType: 'auction',
        targetId: newItem.id,
        details: `Nouvelle annonce "${newItem.title}" soumise avec ${newItem.assetDocuments?.length || 0} document(s) PDF/JPG par ${currentUser.name}. En attente de vérification documentaire.`,
      },
      ...prev,
    ]);

    // Send in-app notification to the seller
    setNotifications((prev) => [
      {
        id: `notif-${Date.now()}-publish`,
        userId: currentUser.id,
        title: 'Annonce soumise pour vérification documentaire',
        message: `Votre produit "${newItem.title}" a été enregistré (Statut Document Verification : Pending). Un administrateur doit passer ce statut à Verified avant sa publication publique.`,
        type: 'approval',
        timestamp: new Date().toISOString(),
        read: false,
        linkAuctionId: newItem.id,
      },
      ...prev,
    ]);

    return { success: true };
  };

  const uploadAssetVerificationDocuments = (
    auctionId: string,
    docs: AssetVerificationDocument[]
  ): { success: boolean; error?: string } => {
    if (!currentUser) {
      return { success: false, error: 'Connexion requise.' };
    }
    const target = auctions.find((a) => a.id === auctionId);
    if (!target) {
      return { success: false, error: 'Annonce introuvable.' };
    }
    const mergedDocs = [...(target.assetDocuments || []), ...docs];
    const nextDocStatus: DocumentVerificationStatus =
      target.documentVerificationStatus === 'rejected' ? 'pending' : (target.documentVerificationStatus || 'pending');
    const nextAuctionStatus =
      target.status === 'annulee' ? ('en_attente' as const) : target.status;

    setAuctions((prev) =>
      prev.map((a) =>
        a.id === auctionId
          ? {
              ...a,
              assetDocuments: mergedDocs,
              documentVerificationStatus: nextDocStatus,
              status: nextAuctionStatus,
            }
          : a
      )
    );

    fetch(`/api/auctions/${auctionId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        assetDocuments: mergedDocs,
        documentVerificationStatus: nextDocStatus,
        status: nextAuctionStatus,
      }),
    }).catch(() => {});

    setAuditLogs((prev) => [
      {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        actorId: currentUser.id,
        actorName: currentUser.name,
        actorRole: currentUser.role,
        action: 'AJOUT_DOCUMENTS_ACTIF',
        targetType: 'auction',
        targetId: auctionId,
        details: `${docs.length} document(s) PDF/JPG ajouté(s) sur "${target.title}".`,
      },
      ...prev,
    ]);

    return { success: true };
  };

  const updateAssetDocumentVerification = (
    auctionId: string,
    docStatus: DocumentVerificationStatus,
    notes?: string,
    publishIfVerified: boolean = true
  ): { success: boolean; error?: string } => {
    const target = auctions.find((a) => a.id === auctionId);
    if (!target) {
      return { success: false, error: 'Annonce introuvable.' };
    }

    const nowIso = new Date().toISOString();
    const reviewer = currentUser?.name || 'Administrateur NgoluMarket';
    const nextAuctionStatus =
      docStatus === 'verified'
        ? publishIfVerified
          ? ('en_cours' as const)
          : target.status
        : docStatus === 'rejected'
        ? ('annulee' as const)
        : ('en_attente' as const);

    const updatedDocs = (target.assetDocuments || []).map((d) => ({
      ...d,
      status: docStatus,
    }));

    setAuctions((prev) =>
      prev.map((a) =>
        a.id === auctionId
          ? {
              ...a,
              documentVerificationStatus: docStatus,
              documentVerificationNotes: notes ?? a.documentVerificationNotes,
              documentReviewedAt: nowIso,
              documentReviewedBy: reviewer,
              assetDocuments: updatedDocs,
              status: nextAuctionStatus,
              adminNotes: docStatus === 'verified' && publishIfVerified ? notes || a.adminNotes : a.adminNotes,
              rejectionReason: docStatus === 'rejected' ? notes || a.rejectionReason : undefined,
            }
          : a
      )
    );

    fetch(`/api/auctions/${auctionId}/document-verification`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        status: docStatus,
        notes,
        reviewedBy: reviewer,
        publishOnVerify: publishIfVerified,
      }),
    }).catch(() => {});

    setNotifications((prev) => [
      {
        id: `notif-${Date.now()}-docverif`,
        userId: target.sellerId,
        title:
          docStatus === 'verified'
            ? 'Documents vérifiés & annonce publiée !'
            : docStatus === 'rejected'
            ? 'Vérification documentaire refusée'
            : 'Documents replacés en attente',
        message:
          docStatus === 'verified'
            ? `Les documents de "${target.title}" ont été validés (Verified)${publishIfVerified ? ' et votre annonce est désormais publiée en ligne.' : '.'}`
            : docStatus === 'rejected'
            ? `Les documents de "${target.title}" ont été rejetés (Rejected). Motif : ${notes || 'Pièces non conformes.'}`
            : `Le statut Document Verification de "${target.title}" a été remis sur Pending.`,
        type: docStatus === 'rejected' ? 'rejection' : 'approval',
        timestamp: nowIso,
        read: false,
        linkAuctionId: target.id,
      },
      ...prev,
    ]);

    setAuditLogs((prev) => [
      {
        id: `log-${Date.now()}`,
        timestamp: nowIso,
        actorId: currentUser?.id || 'admin',
        actorName: reviewer,
        actorRole: currentUser?.role || 'admin',
        action: `DOC_VERIFICATION_${docStatus.toUpperCase()}`,
        targetType: 'auction',
        targetId: target.id,
        details: `Statut Document Verification de "${target.title}" défini sur "${docStatus}". Notes : ${notes || 'Aucune'}.`,
      },
      ...prev,
    ]);

    return { success: true };
  };

  const approveAuction = (
    auctionId: string,
    notes?: string
  ): { success: boolean; error?: string } => {
    const target = auctions.find((a) => a.id === auctionId);
    if (!target) {
      return { success: false, error: 'Annonce introuvable.' };
    }
    if (target.documentVerificationStatus !== 'verified') {
      return {
        success: false,
        error:
          'Publication bloquée : le statut "Document Verification" doit d’abord être réglé sur "Verified" par un administrateur.',
      };
    }

    setAuctions((prev) =>
      prev.map((a) =>
        a.id === auctionId
          ? {
              ...a,
              status: 'en_cours' as const,
              adminNotes: notes,
            }
          : a
      )
    );
    fetch(`/api/auctions/${auctionId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'en_cours', adminNotes: notes }),
    }).catch(() => {});

    setNotifications((prev) => [
      {
        id: `notif-${Date.now()}-approval`,
        userId: target.sellerId,
        title: 'Annonce approuvée !',
        message: `Votre annonce "${target.title}" a été validée par la modération NgoluMarket et est désormais en ligne.`,
        type: 'approval',
        timestamp: new Date().toISOString(),
        read: false,
        linkAuctionId: target.id,
      },
      ...prev,
    ]);

    setAuditLogs((prev) => [
      {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        actorId: currentUser ? currentUser.id : 'admin',
        actorName: currentUser ? currentUser.name : 'Modérateur NgoluMarket',
        actorRole: 'admin',
        action: 'APPROBATION_ANNONCE',
        targetType: 'auction',
        targetId: target.id,
        details: `Annonce "${target.title}" validée et publiée en ligne. Note: ${notes || 'Aucune note'}.`,
      },
      ...prev,
    ]);

    return { success: true };
  };

  const rejectAuction = (auctionId: string, reason: string) => {
    setAuctions((prev) =>
      prev.map((a) =>
        a.id === auctionId
          ? {
              ...a,
              status: 'annulee' as const,
              rejectionReason: reason,
            }
          : a
      )
    );
    fetch(`/api/auctions/${auctionId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'annulee', rejectionReason: reason }),
    }).catch(() => {});

    const target = auctions.find((a) => a.id === auctionId);
    if (target) {
      setNotifications((prev) => [
        {
          id: `notif-${Date.now()}-rejection`,
          userId: target.sellerId,
          title: 'Annonce refusée',
          message: `Votre annonce "${target.title}" a été refusée pour le motif: ${reason}.`,
          type: 'rejection',
          timestamp: new Date().toISOString(),
          read: false,
          linkAuctionId: target.id,
        },
        ...prev,
      ]);

      setAuditLogs((prev) => [
        {
          id: `log-${Date.now()}`,
          timestamp: new Date().toISOString(),
          actorId: currentUser ? currentUser.id : 'admin',
          actorName: currentUser ? currentUser.name : 'Modérateur NgoluMarket',
          actorRole: 'admin',
          action: 'REFUS_ANNONCE',
          targetType: 'auction',
          targetId: target.id,
          details: `Annonce "${target.title}" refusée. Motif: ${reason}.`,
        },
        ...prev,
      ]);
    }
  };

  const suspendAuction = (auctionId: string, reason: string) => {
    setAuctions((prev) =>
      prev.map((a) => (a.id === auctionId ? { ...a, status: 'suspendue' as const, adminNotes: reason } : a))
    );
    fetch(`/api/auctions/${auctionId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'suspendue', adminNotes: reason }),
    }).catch(() => {});
    setAuditLogs((prev) => [
      {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        actorId: currentUser?.id || 'admin',
        actorName: currentUser?.name || 'Admin',
        actorRole: 'admin',
        action: 'SUSPENSION_ENCHERE',
        targetType: 'auction',
        targetId: auctionId,
        details: `Enchère suspendue. Motif: ${reason}`,
      },
      ...prev,
    ]);
  };

  const resumeAuction = (auctionId: string) => {
    setAuctions((prev) =>
      prev.map((a) => (a.id === auctionId ? { ...a, status: 'en_cours' as const } : a))
    );
    fetch(`/api/auctions/${auctionId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'en_cours' }),
    }).catch(() => {});
  };

  const closeAuction = (auctionId: string) => {
    const target = auctions.find((a) => a.id === auctionId);
    if (!target) return;

    setAuctions((prev) =>
      prev.map((a) => (a.id === auctionId ? { ...a, status: 'terminee' as const } : a))
    );
    fetch(`/api/auctions/${auctionId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'terminee' }),
    }).catch(() => {});

    if (target.highestBidderId) {
      const commissionAmount = (target.currentPrice * settings.commissionRatePercent) / 100;
      const netSeller =
        settings.fixedFeePayer === 'seller'
          ? target.currentPrice - commissionAmount - settings.fixedListingFee
          : target.currentPrice - commissionAmount;

      const newSettlement: FinancialSettlement = {
        id: `stl-${Date.now()}-${target.id}`,
        auctionId: target.id,
        auctionTitle: target.title,
        winningBid: target.currentPrice,
        commissionRate: settings.commissionRatePercent,
        commissionAmount,
        fixedFee: settings.fixedListingFee,
        feePayer: settings.fixedFeePayer,
        netSellerAmount: Math.max(0, netSeller),
        sellerId: target.sellerId,
        winnerId: target.highestBidderId,
        settlementStatus: 'en_attente_paiement',
        closedAt: new Date().toISOString(),
        notes: `Clôture manuelle effectuée par l'administrateur.`,
      };

      setSettlements((prev) => [newSettlement, ...prev]);

      // Trigger Won notification & email
      if (notificationPreferences.inAppNotifications && notificationPreferences.notifyOnWon) {
        setNotifications((prev) => [
          {
            id: `notif-${Date.now()}-won-manual`,
            userId: target.highestBidderId!,
            title: 'Félicitations, adjudication remportée !',
            message: `Vous êtes le gagnant officiel de "${target.title}" à ${target.currentPrice.toLocaleString()} USD.`,
            type: 'won',
            timestamp: new Date().toISOString(),
            read: false,
            linkAuctionId: target.id,
          },
          ...prev,
        ]);
      }

      if (notificationPreferences.notifyOnWon) {
        const winner = users.find((u) => u.id === target.highestBidderId);
        if (winner) {
          setEmailNotifications((prev) => [
            {
              id: `email-${Date.now()}-won`,
              userId: winner.id,
              toEmail: winner.email || `${winner.phone}@ngolumarket.cd`,
              toName: winner.name,
              subject: `NgoluMarket Kinshasa : Vous avez remporté "${target.title}" !`,
              body: `Félicitations ${winner.name},\n\nL'adjudication pour "${target.title}" s'est clôturée et vous êtes déclaré acquéreur avec l'offre retenue de ${target.currentPrice.toLocaleString()} USD.\n\nVotre bordereau officiel certifié est disponible dans votre Espace Acheteur NgoluMarket. Les instructions pour le compte séquestre bancaire à Kinshasa vous ont été communiquées.\n\nFélicitations pour votre acquisition !`,
              sentAt: new Date().toISOString(),
              trigger: 'won',
              read: false,
            },
            ...prev,
          ]);
        }
      }
    }
  };

  const updateSettings = (newSettings: Partial<PlatformSettings>) => {
    setSettings((prev) => {
      const updated = { ...prev, ...newSettings };
      return updated;
    });

    setAuditLogs((prev) => [
      {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        actorId: currentUser ? currentUser.id : 'admin',
        actorName: currentUser ? currentUser.name : 'Administrateur NgoluMarket',
        actorRole: 'admin',
        action: 'MODIFICATION_PARAMETRES_PLATEFORME',
        targetType: 'settings',
        targetId: 'platform_settings',
        details: `Mise à jour des règles économiques: Frais fixes=${newSettings.fixedListingFee ?? settings.fixedListingFee} USD, Commission=${newSettings.commissionRatePercent ?? settings.commissionRatePercent}%, Payeur=${newSettings.fixedFeePayer ?? settings.fixedFeePayer}.`,
      },
      ...prev,
    ]);
  };

  const updateNotificationPreferences = (prefs: Partial<NotificationPreferences>) => {
    setNotificationPreferences((prev) => ({ ...prev, ...prefs }));
  };

  const updateSettlementStatus = (
    settlementId: string,
    status: FinancialSettlement['settlementStatus'],
    notes?: string
  ) => {
    setSettlements((prev) =>
      prev.map((s) => (s.id === settlementId ? { ...s, settlementStatus: status, notes: notes || s.notes } : s))
    );

    setAuditLogs((prev) => [
      {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        actorId: currentUser ? currentUser.id : 'admin',
        actorName: currentUser ? currentUser.name : 'Gestionnaire Financier',
        actorRole: 'admin',
        action: 'REGLEMENT_STATUT_CHANGE',
        targetType: 'settlement',
        targetId: settlementId,
        details: `Statut de règlement mis à jour vers: "${status}". Note: ${notes || 'N/A'}.`,
      },
      ...prev,
    ]);
  };

  const verifySeller = (
    userId: string,
    approve: boolean,
    notes?: string,
    documentStatuses?: Record<string, 'verified' | 'rejected'>
  ) => {
    setSellerProfiles((prev) =>
      prev.map((p) => {
        if (p.userId === userId) {
          const updatedDocs = (p.documents || []).map((doc) => {
            if (documentStatuses && documentStatuses[doc.id]) {
              return { ...doc, status: documentStatuses[doc.id] };
            }
            return { ...doc, status: approve ? ('verified' as const) : ('rejected' as const) };
          });

          return {
            ...p,
            verificationStatus: approve ? 'verified' : 'rejected',
            verificationNotes: notes || p.verificationNotes,
            reviewedAt: new Date().toISOString(),
            reviewedBy: currentUser?.name || 'Direction NgoluMarket',
            documents: updatedDocs,
          };
        }
        return p;
      })
    );

    // Reflect verified status immediately across all listings owned by this seller
    setAuctions((prev) =>
      prev.map((a) => (a.sellerId === userId ? { ...a, sellerVerified: approve } : a))
    );

    // Sync to server & broadcast over WebSocket
    fetch('/api/verification/admin/action', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        userId,
        type: 'seller',
        action: approve ? 'approve' : 'reject',
        reason: notes,
        documentStatuses,
        reviewedBy: currentUser?.name || 'Direction NgoluMarket',
      }),
    }).catch(() => {});

    // Notify seller
    setNotifications((prev) => [
      {
        id: `notif-${Date.now()}-kyc`,
        userId,
        title: approve ? 'Dossier Vendeur Pro Approuvé !' : 'Dossier Vendeur Pro Rejeté',
        message: approve
          ? 'Votre dossier professionnel (RCCM, Id. Nat) a été validé par NgoluMarket. Vos annonces affichent désormais le badge Vendeur Vérifié.'
          : `Votre dossier de vendeur professionnel a été refusé : ${notes || 'Documents non conformes'}.`,
        type: approve ? 'approval' : 'rejection',
        timestamp: new Date().toISOString(),
        read: false,
      },
      ...prev,
    ]);

    setAuditLogs((prev) => [
      {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        actorId: currentUser?.id || 'admin',
        actorName: currentUser?.name || 'Direction NgoluMarket',
        actorRole: 'admin',
        action: approve ? 'VENDEUR_CERTIFIE' : 'VENDEUR_REJETE',
        targetType: 'user',
        targetId: userId,
        details: `Examen du dossier KYC vendeur. Décision: ${approve ? 'Approuvé' : 'Rejeté'}. Note: ${notes || 'N/A'}.`,
      },
      ...prev,
    ]);
  };

  const markNotificationAsRead = (id: string) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)));
  };

  const clearAllNotifications = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  };

  // Record consultation history & view count (Section 10)
  const recordProductView = (auctionId: string) => {
    setRecentlyViewedIds((prev) => [auctionId, ...prev.filter((id) => id !== auctionId)].slice(0, 12));
    setAuctions((prev) =>
      prev.map((a) => (a.id === auctionId ? { ...a, viewsCount: (a.viewsCount || 0) + 1 } : a))
    );
  };

  // Activate Seller Premium Subscription: 50 USD / trimestre (Section 7 & 8)
  const activatePremiumSubscription = async (params: {
    method: PaymentMethod;
    provider: PaymentProvider;
    aggregatorGateway?: BankAggregatorId;
    accountOrPhone: string;
    userOverride?: User;
  }): Promise<{ success: boolean; transaction?: PaymentTransaction; error?: string }> => {
    const actingUser = params.userOverride || currentUser;
    if (!actingUser) {
      return { success: false, error: 'Veuillez vous connecter pour souscrire à l’abonnement Premium.' };
    }
    const priceUsd = settings.premiumSubscriptionPriceUsd ?? 50;
    const payRes = await processPayment({
      amountUsd: priceUsd,
      purpose: 'premium_subscription',
      method: params.method,
      provider: params.provider,
      aggregatorGateway: params.aggregatorGateway || 'ngolupay_hub',
      accountOrPhone: params.accountOrPhone,
      notes: `Abonnement Vendeur Premium NgoluMarket (Trimestriel - ${priceUsd} USD)`,
      userOverride: actingUser,
    });

    if (!payRes.success) {
      return { success: false, error: payRes.error };
    }

    const baseTime =
      actingUser.isPremium && actingUser.premiumExpiresAt && new Date(actingUser.premiumExpiresAt).getTime() > Date.now()
        ? new Date(actingUser.premiumExpiresAt)
        : new Date();
    const start = actingUser.isPremium && actingUser.premiumStartedAt ? new Date(actingUser.premiumStartedAt) : new Date();
    const expires = new Date(baseTime.getTime() + 90 * 24 * 60 * 60 * 1000); // +1 trimestre (90 jours)

    setCurrentUser((prev) =>
      prev && prev.id === actingUser.id
        ? {
            ...prev,
            isPremium: true,
            premiumStartedAt: start.toISOString(),
            premiumExpiresAt: expires.toISOString(),
          }
        : prev
    );

    setUsers((prev) =>
      prev.map((u) =>
        u.id === actingUser.id
          ? {
              ...u,
              isPremium: true,
              premiumStartedAt: start.toISOString(),
              premiumExpiresAt: expires.toISOString(),
            }
          : u
      )
    );

    setAuctions((prev) =>
      prev.map((a) => (a.sellerId === actingUser.id ? { ...a, sellerIsPremium: true } : a))
    );

    setAuditLogs((prev) => [
      {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        actorId: actingUser.id,
        actorName: actingUser.name,
        actorRole: actingUser.role,
        action: 'ACTIVATION_ABONNEMENT_PREMIUM',
        targetType: 'subscription',
        targetId: actingUser.id,
        details: `Abonnement Vendeur Premium activé pour ${actingUser.name} (${priceUsd} USD/trimestre, expire le ${expires.toLocaleDateString('fr-FR')}).`,
      },
      ...prev,
    ]);

    setNotifications((prev) => [
      {
        id: `notif-${Date.now()}-prem`,
        userId: actingUser.id,
        title: 'Abonnement Vendeur Premium Activé !',
        message: `Vos droits Vendeur Premium NgoluMarket sont actifs jusqu'au ${expires.toLocaleDateString('fr-FR')}. Vous pouvez publier des enchères en ligne.`,
        type: 'approval',
        timestamp: new Date().toISOString(),
        read: false,
      },
      ...prev,
    ]);

    return { success: true, transaction: payRes.transaction };
  };

  // Submit Ad or Sponsored Product campaign: 1 USD/mois or 1 USD/produit (Section 9)
  const submitAdCampaign = async (params: {
    type: 'banner_ad' | 'sponsored_product';
    title: string;
    auctionId?: string;
    method?: PaymentMethod;
    provider: PaymentProvider;
    accountOrPhone: string;
  }): Promise<{ success: boolean; error?: string }> => {
    if (!currentUser) {
      return { success: false, error: 'Connexion requise pour promouvoir une annonce.' };
    }
    const amountUsd =
      params.type === 'banner_ad'
        ? settings.adMonthlyPriceUsd ?? 1
        : settings.sponsoredProductPriceUsd ?? 1;

    const payRes = await processPayment({
      amountUsd,
      purpose: 'ad_promotion',
      method: params.method || 'mobile_money',
      provider: params.provider,
      accountOrPhone: params.accountOrPhone,
      auctionId: params.auctionId,
      auctionTitle: params.title,
      notes:
        params.type === 'banner_ad'
          ? `Campagne Publicité Mensuelle NgoluMarket (${amountUsd} USD)`
          : `Produit Sponsorisé NgoluMarket (${amountUsd} USD)`,
    });

    if (!payRes.success) {
      return { success: false, error: payRes.error };
    }

    const campaign: AdCampaign = {
      id: `ad-${Date.now()}`,
      userId: currentUser.id,
      userName: currentUser.name,
      type: params.type,
      title: params.title,
      auctionId: params.auctionId,
      amountUsd,
      durationLabel: params.type === 'banner_ad' ? '1 mois' : 'Mise en avant produit',
      status: 'active',
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
    };

    setAdCampaigns((prev) => [campaign, ...prev]);

    if (params.auctionId) {
      setAuctions((prev) =>
        prev.map((a) =>
          a.id === params.auctionId
            ? { ...a, isSponsored: true, sponsoredUntil: campaign.expiresAt }
            : a
        )
      );
    }

    setAuditLogs((prev) => [
      {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        actorId: currentUser.id,
        actorName: currentUser.name,
        actorRole: currentUser.role,
        action: 'CAMPAGNE_PUBLICITE_CREEE',
        targetType: 'ad',
        targetId: campaign.id,
        details: `${params.type === 'banner_ad' ? 'Publicité 1$/mois' : 'Produit Sponsorisé 1$'} activé pour "${params.title}".`,
      },
      ...prev,
    ]);

    return { success: true };
  };

  const reviewAdCampaign = (campaignId: string, status: 'active' | 'rejected' | 'suspended') => {
    const target = adCampaigns.find((c) => c.id === campaignId);
    setAdCampaigns((prev) =>
      prev.map((c) => (c.id === campaignId ? { ...c, status } : c))
    );
    if (target?.auctionId) {
      setAuctions((prev) =>
        prev.map((a) =>
          a.id === target.auctionId ? { ...a, isSponsored: status === 'active' } : a
        )
      );
    }
  };

  const updateOrderStatus = (settlementId: string, orderStatus: OrderStatus) => {
    setSettlements((prev) =>
      prev.map((s) => (s.id === settlementId ? { ...s, orderStatus } : s))
    );
    setAuditLogs((prev) => [
      {
        id: `log-${Date.now()}`,
        timestamp: new Date().toISOString(),
        actorId: currentUser?.id || 'admin',
        actorName: currentUser?.name || 'Admin NgoluMarket',
        actorRole: currentUser?.role || 'admin',
        action: 'COMMANDE_STATUT_MAJ',
        targetType: 'settlement',
        targetId: settlementId,
        details: `Statut de commande mis à jour vers : "${orderStatus}".`,
      },
      ...prev,
    ]);
  };

  const toggleCategoryEnabled = (cat: Category) => {
    setSettings((prev) => {
      const current = prev.enabledCategories || ALL_CATEGORIES;
      const exists = current.includes(cat);
      const next = exists ? current.filter((c) => c !== cat) : [...current, cat];
      return { ...prev, enabledCategories: next.length > 0 ? next : [cat] };
    });
  };

  const updateUserProfile = (
    updates: Partial<Pick<User, 'name' | 'email' | 'phone' | 'city' | 'avatar'>>
  ) => {
    if (!currentUser) return;
    setCurrentUser((prev) => (prev ? { ...prev, ...updates } : null));
    setUsers((prev) =>
      prev.map((u) => (u.id === currentUser.id ? { ...u, ...updates } : u))
    );
  };

  return (
    <AuctiaContext.Provider
      value={{
        currentUser,
        users,
        sellerProfiles,
        auctions,
        bids,
        settlements,
        auditLogs,
        notifications,
        emailNotifications,
        notificationPreferences,
        settings,
        watchlist,
        recentlyViewedIds,
        language,
        setLanguage,
        recordProductView,
        adCampaigns,
        submitAdCampaign,
        reviewAdCampaign,
        activatePremiumSubscription,
        updateOrderStatus,
        toggleCategoryEnabled,
        updateUserProfile,
        latestBidEvent,
        // WebSocket state
        isWsConnected,
        wsState,
        activeViewersMap,
        subscribeToAuctionRoom,
        unsubscribeFromAuctionRoom,
        // Banking Aggregator & Real Payments state & methods
        aggregatorGateways,
        connectedBanks,
        toggleAggregatorGateway,
        refreshAggregatorChannels,
        payments,
        processPayment,
        // Buyer KYC Verification state & methods
        buyerVerifications,
        requestBuyerPhoneOtp,
        verifyBuyerPhoneOtp,
        submitBuyerEnhancedVerification,
        adminReviewBuyerVerification,
        loginAs,
        login,
        logout,
        registerUser,
        registerSellerProfile,
        uploadSellerDocument,
        removeSellerDocument,
        placeBid,
        buyFixedPriceItem,
        toggleWatchlist,
        submitAuction,
        uploadAssetVerificationDocuments,
        updateAssetDocumentVerification,
        approveAuction,
        rejectAuction,
        suspendAuction,
        resumeAuction,
        closeAuction,
        updateSettings,
        updateNotificationPreferences,
        updateSettlementStatus,
        verifySeller,
        markNotificationAsRead,
        clearAllNotifications,
        calculateMinBid,
      }}
    >
      {children}
    </AuctiaContext.Provider>
  );
};

export const useAuctia = () => {
  const context = useContext(AuctiaContext);
  if (!context) {
    throw new Error('useAuctia must be used within an AuctiaProvider');
  }
  return context;
};
