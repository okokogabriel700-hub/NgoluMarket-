export type UserRole = 'visitor' | 'buyer' | 'verified_buyer' | 'seller' | 'admin' | 'super_admin';

export type Language = 'fr' | 'en' | 'ln';

export type Category =
  | 'immobilier'
  | 'automobile'
  | 'mode'
  | 'sport'
  | 'cosmetiques'
  | 'alimentaire'
  | 'meuble'
  | 'electronique'
  | 'electromenager';

export type SaleType = 'enchere' | 'prix_fixe';

export type AuctionStatus =
  | 'brouillon'
  | 'en_attente'
  | 'programmee'
  | 'en_cours'
  | 'terminee'
  | 'annulee'
  | 'suspendue';

export type OrderStatus =
  | 'en_attente_paiement'
  | 'paiement_confirme'
  | 'commande_acceptee'
  | 'en_preparation'
  | 'expediee'
  | 'terminee'
  | 'annulee'
  | 'litige';

export type VerificationTier = 'baseline' | 'phone_verified' | 'enhanced_kyc';

export interface User {
  id: string;
  name: string;
  firstName?: string;
  lastName?: string;
  email?: string;
  phone: string;
  password?: string;
  role: UserRole;
  status: 'active' | 'suspended';
  companyName?: string;
  city: string;
  country?: string;
  avatar?: string;
  isPremium?: boolean;
  premiumStartedAt?: string;
  premiumExpiresAt?: string;
  verificationTier?: VerificationTier;
  phoneVerified?: boolean;
  emailVerified?: boolean;
  depositBalanceUsd?: number;
  hasActiveDeposit?: boolean;
  createdAt: string;
}

export interface NotificationPreferences {
  smsNotifications: boolean;
  inAppNotifications: boolean;
  notifyOnOutbid: boolean;
  notifyOnEndingSoon: boolean;
  notifyOnWon: boolean;
  notifyOnNewBidOnMyItem: boolean;
  audioChimeEnabled: boolean;
  emailNotifications?: boolean;
}

export interface SellerDocument {
  id: string;
  name: string;
  type: 'rccm' | 'id_nat' | 'tax_cert' | 'bank_rib' | 'identity_card' | 'office_lease';
  fileName: string;
  fileSize: string;
  fileUrl: string;
  status: 'uploaded' | 'verified' | 'rejected';
  uploadedAt: string;
}

export interface SellerProfile {
  userId: string;
  companyName: string;
  rccmNumber: string; // Registre du Commerce et du Crédit Mobilier (RDC)
  idNat: string; // Numéro d'Identification Nationale
  taxNumber: string; // Numéro Impôt
  address: string;
  city: string;
  phone: string;
  bankRib?: string;
  documents?: SellerDocument[];
  verificationStatus: 'pending' | 'verified' | 'rejected';
  verificationNotes?: string;
  submittedAt: string;
  reviewedAt?: string;
  reviewedBy?: string;
}

export interface ImmobilierDetails {
  propertyType: 'Villa' | 'Appartement' | 'Terrain' | 'Immeuble commercial' | 'Duplex';
  surfaceM2: number;
  rooms?: number;
  bedrooms?: number;
  landTitleType: 'Certificat d’enregistrement' | 'Contrat de concession perpétuelle' | 'Livret de logeur' | 'Titre foncier en cours';
  titleNumber?: string;
  visitSchedule: string;
  documentsVerified: boolean;
}

export interface AutomobileDetails {
  brand: string;
  model: string;
  year: number;
  mileageKm: number;
  transmission: 'Automatique' | 'Manuelle';
  fuel: 'Essence' | 'Diesel' | 'Hybride' | 'Électrique';
  condition: 'Excellent' | 'Très bon' | 'Bon état' | 'À réviser';
  technicalInspectionOk: boolean;
  pinkCardOk: boolean; // Carte rose RDC
  chassisVin?: string;
}

export interface ModeDetails {
  itemType: 'Montre de prestige' | 'Maroquinerie de luxe' | 'Haute couture' | 'Bijou & Joaillerie';
  brand: string;
  model?: string;
  size?: string;
  color: string;
  condition: 'Neuf avec étiquette' | 'État impeccable' | 'Très bon état';
  authenticityCertificate: boolean;
  boxAndPapers: boolean;
  deliveryMethod: 'Retrait sécurisé à Gombe' | 'Livraison sécurisée Kinshasa';
}

export interface GeneralProductDetails {
  productType: string;
  brand: string;
  model?: string;
  condition: 'Neuf scellé' | 'Neuf' | 'Très bon état' | 'Bon état';
  warranty?: string;
  originOrSpec?: string;
  deliveryMethod: string;
}

export type SpecificDetails =
  | ImmobilierDetails
  | AutomobileDetails
  | ModeDetails
  | GeneralProductDetails;

export interface Bid {
  id: string;
  auctionId: string;
  bidderId: string;
  bidderName: string;
  amount: number;
  timestamp: string; // ISO
  status: 'valid' | 'outbid' | 'won' | 'rejected';
}

export type DocumentVerificationStatus = 'pending' | 'verified' | 'rejected';

export interface AssetVerificationDocument {
  id: string;
  name: string;
  fileName: string;
  fileType: 'application/pdf' | 'image/jpeg' | 'image/png' | 'image/webp';
  fileSize: string;
  fileUrl: string;
  status: DocumentVerificationStatus;
  uploadedAt: string;
}

export interface AuctionItem {
  id: string;
  title: string;
  category: Category;
  saleType?: SaleType; // 'enchere' | 'prix_fixe'
  description: string;
  images: string[];
  startPrice: number;
  currentPrice: number;
  fixedPrice?: number;
  currency: 'USD';
  minBidStep: number;
  reservePrice?: number;
  depositRequiredUsd?: number;
  sellerId: string;
  sellerName: string;
  sellerVerified: boolean;
  sellerIsPremium?: boolean;
  sellerRating?: number; // Note moyenne sur 5 (ex: 4.8)
  sellerReviewsCount?: number; // Nombre d'avis clients (ex: 24)
  isSponsored?: boolean;
  sponsoredUntil?: string;
  startDate: string; // ISO
  endDate: string; // ISO
  createdAt: string;
  status: AuctionStatus;
  assetDocuments?: AssetVerificationDocument[];
  documentVerificationStatus?: DocumentVerificationStatus;
  documentVerificationNotes?: string;
  documentReviewedAt?: string;
  documentReviewedBy?: string;
  location: {
    city: string;
    commune: string;
    neighborhood?: string;
    visitAddress?: string;
  };
  specificDetails: SpecificDetails;
  bidsCount: number;
  highestBidderId?: string;
  highestBidderName?: string;
  adminNotes?: string;
  rejectionReason?: string;
  viewsCount: number;
}

export interface PlatformSettings {
  fixedListingFee: number; // 0 USD publication gratuite (Fiche Technique Sections 6 & 7)
  fixedPriceBuyerFeeUsd: number; // 1 USD payé par l'acheteur sur vente à prix fixe (Section 6)
  commissionRatePercent: number; // 5% sur enchères (Section 7)
  premiumSubscriptionPriceUsd: number; // 50 USD / trimestre (Section 8)
  adMonthlyPriceUsd: number; // 1 USD / mois (Section 9)
  sponsoredProductPriceUsd: number; // 1 USD / produit (Section 9)
  fixedFeePayer: 'seller' | 'buyer' | 'winner';
  antiSnipingMinutes: number; // e.g. 2 min extension if bid received within 2 min
  antiSnipingEnabled: boolean;
  autoApproveSellers: boolean;
  minBidStepMode: 'fixed' | 'tiered';
  targetCity: string;
  contactVisibility: 'hidden_until_won' | 'verified_only' | 'public';
  currencyRateCdf: number; // Taux indicatif Franc Congolais (ex. 2850 CDF/USD)
  enabledCategories?: Category[];
  activeCountries?: string[];
}

export interface FinancialSettlement {
  id: string;
  orderNumber?: string;
  auctionId: string;
  auctionTitle: string;
  saleType?: SaleType;
  winningBid: number;
  buyerFeeUsd?: number; // e.g. 1 USD for fixed price
  commissionRate: number;
  commissionAmount: number;
  fixedFee: number;
  feePayer: 'seller' | 'buyer' | 'winner';
  netSellerAmount: number;
  sellerId: string;
  winnerId: string;
  settlementStatus: 'en_attente_paiement' | 'fonds_sequestres' | 'paye_au_vendeur' | 'litige';
  orderStatus?: OrderStatus;
  closedAt: string;
  paymentProofUrl?: string;
  notes?: string;
}

export interface AdCampaign {
  id: string;
  userId: string;
  userName: string;
  type: 'banner_ad' | 'sponsored_product';
  title: string;
  auctionId?: string;
  amountUsd: number;
  durationLabel: string;
  status: 'pending' | 'active' | 'rejected' | 'suspended';
  createdAt: string;
  expiresAt?: string;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  actorId: string;
  actorName: string;
  actorRole: UserRole;
  action: string;
  targetType: 'auction' | 'user' | 'bid' | 'settings' | 'settlement' | 'ad' | 'subscription';
  targetId: string;
  details: string;
}

export interface EmailNotification {
  id: string;
  userId: string;
  toEmail: string;
  toName: string;
  subject: string;
  body: string;
  sentAt: string;
  trigger: 'outbid' | 'ending_soon' | 'won' | 'verification' | 'approval';
  read: boolean;
}

export interface NotificationItem {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'outbid' | 'ending_soon' | 'won' | 'approval' | 'rejection' | 'new_bid';
  timestamp: string;
  read: boolean;
  linkAuctionId?: string;
}

// === BUYER VERIFICATION TYPES ===
export interface BuyerDocument {
  id: string;
  name: string;
  type: 'ceni_voter_card' | 'passport' | 'driving_license' | 'residence_proof' | 'bank_solvency_proof';
  fileName: string;
  fileSize: string;
  fileUrl: string;
  uploadedAt: string;
  status: 'uploaded' | 'verified' | 'rejected';
}

export interface BuyerVerificationProfile {
  userId: string;
  userName: string;
  phone: string;
  tier: VerificationTier;
  phoneVerified: boolean;
  phoneVerificationCode?: string;
  documentType?: 'ceni_voter_card' | 'passport' | 'driving_license';
  documentNumber?: string;
  bankName?: string;
  bankAttestationNumber?: string;
  residenceCommune?: string;
  residenceQuarter?: string;
  documents: BuyerDocument[];
  maxTransactionLimitUsd: number;
  status: 'unverified' | 'pending' | 'verified' | 'rejected';
  rejectionReason?: string;
  submittedAt?: string;
  reviewedAt?: string;
  reviewedBy?: string;
}

// === REAL PAYMENT & BANKING AGGREGATOR TYPES (RDC) ===
export type MobileMoneyProvider = 'mpesa' | 'airtel_money' | 'orange_money' | 'afrimoney';

export type BankProvider =
  | 'rawbank_illicocash'
  | 'rawbank_virement'
  | 'equity_bcdc'
  | 'ecobank'
  | 'tmb_pepele'
  | 'fbnbank_rdc'
  | 'sofibanque'
  | 'access_bank_rdc';

export type CardProvider = 'visa_mastercard';

export type PaymentProvider = MobileMoneyProvider | BankProvider | CardProvider;

export type PaymentMethod = 'mobile_money' | 'bank_transfer' | 'card';

export type BankAggregatorId =
  | 'ngolupay_hub'
  | 'rawbank_direct'
  | 'cinetpay_rdc'
  | 'flutterwave_africa';

export interface ConnectedBankInfo {
  id: BankProvider;
  name: string;
  shortName: string;
  swiftCode: string;
  clearingCode: string;
  rails: string[];
  settlementDelay: string;
  supportedCurrencies: ('USD' | 'CDF')[];
}

export interface AggregatorGatewayInfo {
  id: BankAggregatorId;
  name: string;
  subtitle: string;
  settlementRail: string;
  clearingDelay: string;
  feePercent: number;
  supportedMethods: PaymentMethod[];
  supportedCurrencies: ('USD' | 'CDF')[];
  connectedBanks: BankProvider[];
  enabled: boolean;
  status: 'online' | 'maintenance';
  routedVolumeUsd?: number;
  transactionsCount?: number;
}

export type PaymentPurpose =
  | 'deposit_guarantee'
  | 'auction_settlement'
  | 'listing_fee'
  | 'premium_subscription'
  | 'ad_promotion';

export interface PaymentTransaction {
  id: string;
  reference: string;
  auctionId?: string;
  auctionTitle?: string;
  userId: string;
  userName: string;
  userPhone: string;
  amountUsd: number;
  amountCdf: number;
  exchangeRate: number;
  purpose: PaymentPurpose;
  method: PaymentMethod;
  provider: PaymentProvider;
  aggregatorGateway?: BankAggregatorId;
  aggregatorName?: string;
  bankSwiftCode?: string;
  settlementRail?: string;
  aggregatorFeeUsd?: number;
  accountOrPhone: string;
  providerTransactionId?: string;
  authorisationCode?: string;
  escrowAccountNumber?: string;
  notaryReference?: string;
  status: 'pending' | 'processing' | 'completed' | 'failed' | 'refunded';
  notes?: string;
  receiptNumber: string;
  timestamp: string;
  completedAt?: string;
}

// === REAL-TIME & WEBSOCKET TYPES ===
export type WsMessageType =
  | 'init'
  | 'subscribe'
  | 'unsubscribe'
  | 'bid:placed'
  | 'auction:created'
  | 'auction:updated'
  | 'seller:verification_updated'
  | 'notification:pushed'
  | 'presence:update'
  | 'payment:confirmed'
  | 'ping'
  | 'pong';

export interface WsMessage<T = any> {
  type: WsMessageType;
  auctionId?: string;
  userId?: string;
  payload?: T;
  timestamp: string;
}

export interface PresenceUpdatePayload {
  auctionId: string;
  activeViewersCount: number;
}
