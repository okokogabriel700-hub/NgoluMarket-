import { WsMessage } from '../types';

type MessageHandler = (message: WsMessage) => void;
type ConnectionState = 'connected' | 'connecting' | 'disconnected';

class WebSocketService {
  private ws: WebSocket | null = null;
  private listeners: Set<MessageHandler> = new Set();
  private stateListeners: Set<(state: ConnectionState) => void> = new Set();
  private connectionState: ConnectionState = 'disconnected';
  private reconnectAttempts = 0;
  private maxReconnectAttempts = 15;
  private reconnectTimer: any = null;
  private subscribedRooms: Set<string> = new Set();
  private pingInterval: any = null;
  private currentUserId?: string;
  private currentUserName?: string;

  constructor() {
    this.connect();
  }

  public connect() {
    if (typeof window === 'undefined') return;
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) {
      return;
    }

    this.setConnectionState('connecting');

    try {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const wsUrl = `${protocol}//${window.location.host}/ws`;

      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        this.reconnectAttempts = 0;
        this.setConnectionState('connected');

        // Identify user if logged in
        if (this.currentUserId) {
          this.send({
            type: 'identify',
            userId: this.currentUserId,
            userName: this.currentUserName,
            timestamp: new Date().toISOString(),
          });
        }

        // Re-subscribe to rooms
        this.subscribedRooms.forEach((auctionId) => {
          this.send({
            type: 'subscribe',
            auctionId,
            userId: this.currentUserId,
            userName: this.currentUserName,
            timestamp: new Date().toISOString(),
          });
        });

        // Setup client-side ping keep-alive
        this.startKeepAlive();
      };

      this.ws.onmessage = (event) => {
        try {
          const message: WsMessage = JSON.parse(event.data);
          this.notifyListeners(message);
        } catch (e) {
          console.warn('[WS Client] Failed to parse message:', e);
        }
      };

      this.ws.onclose = () => {
        this.setConnectionState('disconnected');
        this.stopKeepAlive();
        this.scheduleReconnect();
      };

      this.ws.onerror = (err) => {
        console.warn('[WS Client] WebSocket connection error, will reconnect...', err);
        this.setConnectionState('disconnected');
      };
    } catch (e) {
      console.warn('[WS Client] Connection initialization error:', e);
      this.scheduleReconnect();
    }
  }

  private startKeepAlive() {
    this.stopKeepAlive();
    this.pingInterval = setInterval(() => {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.ws.send(JSON.stringify({ type: 'ping', timestamp: new Date().toISOString() }));
      }
    }, 25000);
  }

  private stopKeepAlive() {
    if (this.pingInterval) {
      clearInterval(this.pingInterval);
      this.pingInterval = null;
    }
  }

  private scheduleReconnect() {
    if (this.reconnectTimer) clearTimeout(this.reconnectTimer);
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      // Keep trying with a 10s cooldown
      this.reconnectTimer = setTimeout(() => {
        this.reconnectAttempts = 5;
        this.connect();
      }, 10000);
      return;
    }

    const delay = Math.min(1000 * Math.pow(1.5, this.reconnectAttempts), 10000);
    this.reconnectAttempts++;
    this.reconnectTimer = setTimeout(() => {
      this.connect();
    }, delay);
  }

  public setIdentity(userId?: string, userName?: string) {
    this.currentUserId = userId;
    this.currentUserName = userName;
    if (this.isConnected() && userId) {
      this.send({
        type: 'identify',
        userId,
        userName,
        timestamp: new Date().toISOString(),
      });
    }
  }

  public subscribe(auctionId: string) {
    this.subscribedRooms.add(auctionId);
    if (this.isConnected()) {
      this.send({
        type: 'subscribe',
        auctionId,
        userId: this.currentUserId,
        userName: this.currentUserName,
        timestamp: new Date().toISOString(),
      });
    }
  }

  public setUser(userId?: string, userName?: string) {
    this.setIdentity(userId, userName);
  }

  public subscribeAuction(auctionId: string) {
    this.subscribe(auctionId);
  }

  public unsubscribe(auctionId: string) {
    this.subscribedRooms.delete(auctionId);
    if (this.isConnected()) {
      this.send({
        type: 'unsubscribe',
        auctionId,
        timestamp: new Date().toISOString(),
      });
    }
  }

  public unsubscribeAuction(auctionId: string) {
    this.unsubscribe(auctionId);
  }

  public addStatusListener(handler: (state: ConnectionState) => void): () => void {
    return this.addStateListener(handler);
  }

  public placeBid(
    auctionId: string,
    amount: number,
    bidderId?: string,
    bidderName?: string,
    bidderPhone?: string,
    bidId?: string
  ) {
    this.send({
      type: 'bid:place',
      auctionId,
      bidId,
      amount,
      bidderId,
      bidderName: bidderName || 'Enchérisseur Kinshasa',
      bidderPhone: bidderPhone || '+243 ...',
      timestamp: new Date().toISOString(),
    });
  }

  public send(data: any) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(data));
    }
  }

  public addListener(handler: MessageHandler): () => void {
    this.listeners.add(handler);
    return () => this.listeners.delete(handler);
  }

  public addStateListener(handler: (state: ConnectionState) => void): () => void {
    this.stateListeners.add(handler);
    handler(this.connectionState);
    return () => this.stateListeners.delete(handler);
  }

  private notifyListeners(message: WsMessage) {
    this.listeners.forEach((listener) => {
      try {
        listener(message);
      } catch (err) {
        console.error('[WS Listener Error]', err);
      }
    });
  }

  private setConnectionState(state: ConnectionState) {
    this.connectionState = state;
    this.stateListeners.forEach((listener) => {
      try {
        listener(state);
      } catch (err) {
        console.error('[WS State Listener Error]', err);
      }
    });
  }

  public isConnected(): boolean {
    return this.ws !== null && this.ws.readyState === WebSocket.OPEN;
  }

  public getState(): ConnectionState {
    return this.connectionState;
  }
}

export const wsService = new WebSocketService();
